﻿/************************************************* ************************************************** **********
 * File name: A7139.c
 * Function: STM32 A7139 driver
 * Author: cp1300@139.com
 * Creation time: 2015-07-19
 * Last modified time: 2015-07-19
 * Details: A7139 driver
************************************************** ************************************************** *********/
#include "SYSTEM.H"
#include "GPIO_INIT.H"
#include "a7139.H"




//Device hardware ID
#define A7139_DEVER_ID 0xAA71

//Crystal register, used to set crystal and PAGE address
//Used to cache the value of register 7
static u16 A7139_CRYSTAL_REG = 0x18;

//Single packet data sending timeout
#define A7139_SEND_TIME_OUT 5//Unit 10ms

//Receive interrupt callback function
void (*pRxCallBack) () = NULL;

//Debug switch
#define A7193_DBUG 1
#if A7193_DBUG
#include "system.h"
#define A7193_debug (format, ...) uart_printf (format, ## __ VA_ARGS__)
#else
#define A7193_debug (format, ...)/\
/
#endif//A7193_DBUG


//Register configuration
typedef struct
{
	u16 SCLOCK;//System clock register
	u16 PLL1;//PLL1
	u16 PLL2;//PLL2
	u16 PLL3;//PLL3
	u16 PLL4;//PLL4
	u16 PLL5;//PLL5
	u16 PLL6;//PLL6
	u16 CRYSTAL;//Crystal settings
	u16 PREG8S;//Register group, switched by CRYSTAL control
	u16 PREG9S;//Register group, switched by CRYSTAL control
	u16 RX1;//Receive setting 1
	u16 RX2;//Receive setting 2
	u16 ADC;//ADC
	u16 PIN;//PIN
	u16 CALIB;//Calibration
	u16 MODE;//Mode control
} A7139_CONFIG_YPTE;



const u16 A7139Config[] =
{
	0x0021,//SYSTEM CLOCK register,
		0x0A21,//PLL1 register,
		0xDA05,//PLL2 register, 433.301MHz
		0x0000,//PLL3 register,
		0x0A20,//PLL4 register,
		0x0024,//PLL5 register,
		0x0000,//PLL6 register,
		0x0001,//CRYSTAL register,
		0x0000,//PAGEA,
		0x0000,//PAGEB,
		0x18D4,//RX1 register, IFBW = 100KHz, ETH = 1	
		0x7009,//RX2 register, by preamble
		0x4400,//ADC register,
		0x0800,//PIN CONTROL register, Use Strobe CMD
		0x4845,//CALIBRATION register,
		0x20C0//MODE CONTROL register, Use FIFO mode
};

const u16 A7139Config_PageA[] =
{
	0xF706,//TX1 register, Fdev = 37.5kHz
		0x0000,//WOR1 register,
		0xF800,//WOR2 register,
		0x1107,//RFI register, Enable Tx Ramp up/down
		0x0170,//PM register,
		0x0201,//RTH register,
		0x400F,//AGC1 register,
		0x2AC0,//AGC2 register,
		0x0041,//GIO register GIO1-> WTR GIO2-> WTR 
		0xD281,//CKO register
		0x0004,//VCB register,
		0x0A21,//CHG1 register, 430MHz
		0x0022,//CHG2 register, 435MHz
		0x003F,//FIFO register, FEP = 63 + 1 = 64bytes
		0x1507,//CODE register, Preamble = 4bytes, ID = 4bytes
		0x0000//WCAL register,
};

const u16 A7139Config_PageB[] =
{
	0x0337,//TX2 register, 	
		0x8400,//IF1 register, Enable Auto-IF, IF = 200KHz
		0x0000,//IF2 register,
		0x0000,//ACK register,
		0x0000//ART register,
};


/* Command selection
Address format
BIT7 BIT6-BIT4 BIT3-BIT0
R/W Command Address
0: write 000 read and write control register
1: read 010 read and write ID
			100 read and write FIFO
			110 Reset FIFO
			111 RF reset

*/



/************************************************* ************************************************** **********************
* Function: bool A7139_Init (u32 RF_ID, void (* p) ())
* Function: A7139 initialization
* Parameter: RF_ID: RF ID; * p: callback function
* Return: TRUE: success; FALSE: failure
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: None
************************************************** ************************************************** *********************/
bool A7139_Init(u32 RF_ID, void (*p) ())
{
	u32 ID;

	A7139_DisableRxInt();//Close receive interrupt
	pRxCallBack = NULL;//Invalid callback function
	A7139_IO_INIT();//Initialize IO
	A7139_CS_H();
	A7139_CLK_L();
	A7139_DIO_H();

	A7139_CRYSTAL_REG = 0x0001;
	A7139_SoftReset();//Soft reset
	if (A7139_ReadID()!= 0)
	{
		A7139_SoftReset();//Soft reset
	}
	nop; nop;
	A7139_WriteID(RF_ID);//Write ID
	if (A7139_ReadID()!= RF_ID)//Read ID
	{
		A7139_WriteID(RF_ID);
	}

	ID = A7139_ReadID();//Read user ID
	if (ID!= RF_ID)
	{
		A7193_debug("A7139 initialization failed, chip detection error!\R\n");
		return FALSE;
	}
	A7193_debug("A7139 User ID:% X\tHardware ID:% X\r\n", ID, A7139_ReadDeverID());

	A7139_Config();//Initialize the register

	Delay_MS(10);
	if (A7139_Cal())
	{
		A7193_debug("A7139 failed to initialize!\R\n", ID, A7139_ReadDeverID());
		return FALSE;
	}
	A7193_debug("A7139 initialized successfully!\R\n", ID, A7139_ReadDeverID());


	A7139_WriteReg(A7139_PLL1, 0x0A21);
	A7139_WriteReg(A7139_PLL2, 0xDE05);//Frequency = 433.501MHz

	A7139_WritePageB(A7139_REG9_TX2, 0x035F);//TX power = 18.3dBm
	pRxCallBack = p;//Record callback function
	A7139_EnableInt();//Turn on the total interrupt

	return TRUE;
}







/************************************************* ************************************************** **********************
* Function: void A7139_WriteByte (u8 data)
* Function: A7139 write one byte
* Parameter: data: data to be written
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: Without chip selection, the bottom layer writes 1B
************************************************** ************************************************** *********************/
void A7139_WriteByte(u8 data)
{
	u8 i;

	for (i = 0; i < 8; i++)
	{
		if (data & 0x80)
		{
			A7139_DIO_H();
		}
		else
		{
			A7139_DIO_L();
		}
		nop;
		A7139_CLK_H();
		data << = 1;
		nop;
		A7139_CLK_L();
	}
}



/************************************************* ************************************************** **********************
* Function: u8 A7139_ReadByte (void)
* Function: A7139 read one byte
* Parameter: None
* Back: read data
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: Without chip selection, the bottom layer reads 1B
************************************************** ************************************************** *********************/
u8 A7139_ReadByte(void)
{
	u8 i;
	u8 data = 0;

	for (i = 0; i < 8; i++)
	{
		A7139_CLK_H();
		data << = 1;
		if (A7139_DIO_IN())
		{
			data | = 1;
		}
		nop;
		A7139_CLK_L();
		nop; nop;
	}

	return data;
}



/************************************************* ************************************************** **********************
* Function: u16 A7139_ReadReg (A7139_CREG RegAddr)
* Function: Read control register
* Parameter: RegAddr: register address
* Returns: register value
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description:
************************************************** ************************************************** *********************/
u16 A7139_ReadReg(A7139_CREG RegAddr)
{
	u16 data;

	RegAddr & = 0x0f;//Address is limited to BIT0-BIT3
	RegAddr | = A7139_RCR_CMD;//Read command
	A7139_CS_L();
	A7139_OutMode();
	A7139_WriteByte(RegAddr);
	A7139_InMode();//Enter
	data = A7139_ReadByte();
	data << = 8;
	data | = A7139_ReadByte();
	A7139_CS_H();

	return data;
}



/************************************************* ************************************************** **********************
* Function: void A7139_WriteReg (u8 RegAddr, u16 data)
* Function: Write to control register
* Parameters: RegAddr: register address, data: value to be written
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description:
************************************************** ************************************************** *********************/
void A7139_WriteReg(A7139_CREG RegAddr, u16 data)
{
	RegAddr & = 0x0f;//Address is limited to BIT0-BIT3
	RegAddr | = A7139_WCR_CMD;//Write command
	A7139_CS_L();
	A7139_OutMode();
	A7139_WriteByte(RegAddr);
	A7139_WriteByte(data >> 8);
	A7139_WriteByte(data);
	A7139_CS_H();
}



/************************************************* ************************************************** **********************
* Function: u16 A7139_ReadPageA (A7139_PAGE_A RegAddr)
* Function: Read control register set register A
* Parameter: RegAddr: Register group address
* Returns: register value
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: Register group 8
************************************************** ************************************************** *********************/
u16 A7139_ReadPageA(A7139_PAGE_A RegAddr)
{
	u16 data;

	//Select the group first
	if ((A7139_CRYSTAL_REG >> 12)!= RegAddr)//08 register set is not correct, need to reset
	{
		A7139_CRYSTAL_REG & = ~(0xf << 12);//Clear register group 8 address
		A7139_CRYSTAL_REG | = (RegAddr << 12);//Store register group 8 address
		A7139_WriteReg(A7139_CRYSTAL, A7139_CRYSTAL_REG);//Reset this register group 8 address
	}
	data = A7139_ReadReg(A7139_PREG8S);//Read register group data

	return data;
}



/************************************************* ************************************************** **********************
* Function: void A7139_WritePageA (A7139_PAGE_A RegAddr, u16 data)
* Function: Write to control register bank register
* Parameters: RegAddr: register group address, data: register value
* Returns: register value
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: Register group 8
************************************************** ************************************************** *********************/
void A7139_WritePageA(A7139_PAGE_A RegAddr, u16 data)
{
	u8 temp;

	//Select the group first
	if ((A7139_CRYSTAL_REG >> 12)!= RegAddr)//08 register set is not correct, need to reset
	{
		A7139_CRYSTAL_REG & = ~(0xf << 12);//Clear register group 8 address
		A7139_CRYSTAL_REG | = (RegAddr << 12);//Store register group 8 address
		A7139_WriteReg(A7139_CRYSTAL, A7139_CRYSTAL_REG);//Reset this register group 8 address
	}
	A7139_WriteReg(A7139_PREG8S, data);//Set register group data
}



/************************************************* ************************************************** **********************
* Function: u16 A7139_ReadPageB (A7139_PAGE_B RegAddr)
* Function: Read control register set register
* Parameter: RegAddr: Register group address
* Returns: register value
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: Register Group 9
************************************************** ************************************************** *********************/
u16 A7139_ReadPageB(A7139_PAGE_B RegAddr)
{
	u16 data;

	if (((A7139_CRYSTAL_REG >> 7) & 0x7)!= RegAddr)//09 register set is incorrect, need to reset
	{
		A7139_CRYSTAL_REG & = ~(0x7 << 7);//Clear register group 9 address
		A7139_CRYSTAL_REG | = ((RegAddr & 0x7) << 7);//Store register group 9 address
		A7139_WriteReg(A7139_CRYSTAL, A7139_CRYSTAL_REG);//Reset this register group 9 address
	}
	data = A7139_ReadReg(A7139_PREG9S);//Read register group data

	return data;
}



/************************************************* ************************************************** **********************
* Function: void A7139_WritePageB (A7139_PAGE_B RegAddr, u16 data)
* Function: Write to control register bank register
* Parameters: RegAddr: register group address, data: register value
* Returns: register value
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: Register Group 9
************************************************** ************************************************** *********************/
void A7139_WritePageB(A7139_PAGE_B RegAddr, u16 data)
{
	//Select the group first
	if (((A7139_CRYSTAL_REG >> 7) & 0x7)!= RegAddr)//09 register set is incorrect, need to reset
	{
		A7139_CRYSTAL_REG & = ~(0x7 << 7);//Clear register group 9 address
		A7139_CRYSTAL_REG | = ((RegAddr & 0x7) << 7);//Store register group 9 address
		A7139_WriteReg(A7139_CRYSTAL, A7139_CRYSTAL_REG);//Reset this register group 9 address
	}

	A7139_WriteReg(A7139_PREG9S, data);//Set register group data
}

/************************************************* ************************************************** **********************
* Function: u32 A7139_ReadID (void)
* Function: Read A7139 ID
* Parameter: None
* Back: ID value
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: Read ID
************************************************** ************************************************** *********************/
u32 A7139_ReadID(void)
{
	u32 data;
	u8 i;

	A7139_CS_L();
	A7139_OutMode();
	A7139_WriteByte(A7139_RID_CMD);//Read ID command
	A7139_InMode();//Enter
	data = 0;
	for (i = 0; i < 4; i++)
	{
		data << = 8;
		data | = A7139_ReadByte();
	}
	A7139_CS_H();

	return data;
}


/************************************************* ************************************************** **********************
* Function: void A7139_WriteID (u32 ID)
* Function: Set A7139 ID
* Parameter: No ID value
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: Set ID
************************************************** ************************************************** *********************/
void A7139_WriteID(u32 ID)
{
	A7139_CS_L();
	A7139_OutMode();
	A7139_WriteByte(A7139_WID_CMD);//Write ID command
	A7139_WriteByte(ID >> 24);
	A7139_WriteByte(ID >> 16);
	A7139_WriteByte(ID >> 8);
	A7139_WriteByte(ID >> 0);
	A7139_CS_H();
}



/************************************************* ************************************************** **********************
* Function: void A7139_StrobeCmd (A7139_STROBE_CMD StrobeCmd)
* Function: A7139 sends Strobe command
* Parameter: None
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description:
************************************************** ************************************************** *********************/
void A7139_StrobeCmd(A7139_STROBE_CMD StrobeCmd)
{
	A7139_CS_L();
	A7139_OutMode();
	A7139_WriteByte(StrobeCmd);
	A7139_CS_H();
}



/************************************************* ************************************************** **********************
* Function: void A7139_ReadFIFO (u8 * pData, u8 DataLen)
* Function: A7139 read FIFO
* Parameter: None
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description:
************************************************** ************************************************** *********************/
void A7139_ReadFIFO(u8* pData, u8 DataLen)
{
	u8 i;

	A7139_CS_L();
	A7139_OutMode();
	A7139_WriteByte(A7139_RFIFO_CMD);
	A7139_InMode();
	//Cycle read FIFO
	for (i = 0; i < DataLen; i++)
	{
		pData[i] = A7139_ReadByte();
	}
	A7139_CS_H();
}


/************************************************* ************************************************** **********************
* Function: void A7139_WriteFIFO (u8 * pData, u8 DataLen)
* Function: A7139 write FIFO
* Parameter: None
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description:
************************************************** ************************************************** *********************/
void A7139_WriteFIFO(u8* pData, u8 DataLen)
{
	u8 i;

	A7139_CS_L();
	A7139_OutMode();
	A7139_WriteByte(A7139_WFIFO_CMD);
	//Cycle write to FIFO
	for (i = 0; i < DataLen; i++)
	{
		A7139_WriteByte(pData[i]);
	}
	A7139_CS_H();
}




/************************************************* ************************************************** **********************
* Function: void A7139_Config (void)
* Function: A7139 configuration
* Parameter: None
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: Initial configuration
************************************************** ************************************************** *********************/
void A7139_Config(void)
{
	u8 i;

	for (i = 0; i < 8; i++)
		A7139_WriteReg(i, A7139Config[i]);
	for (i = 10; i < 16; i++)
		A7139_WriteReg(i, A7139Config[i]);
	for (i = 0; i < 16; i++)
		A7139_WritePageA(i, A7139Config_PageA[i]);
	for (i = 0; i < 5; i++)
		A7139_WritePageB(i, A7139Config_PageB[i]);
}




/************************************************* ************************************************** **********************
* Function: bool A7139_SendData (u8 pData [64], bool isClear)
* Function: A7139 send data
* Parameters: pData: send data buffer, the size is fixed at 64 bytes; isClear: whether to clear the send buffer
* Return: TRUE: successful transmission; FALSE: failed transmission
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: A7139 send data
************************************************** ************************************************** *********************/
bool A7139_SendData(u8 pData[64], bool isClear)
{
	u8 retry = 0;

	if (isClear)//Need to clear the send buffer
	{
		A7139_StrobeCmd(A7139_STBY_CMD);
		A7139_DelayMS(2);
		A7139_StrobeCmd(A7139_RESTFIFO_CMD);
		A7139_DelayMS(1);
	}
	A7139_WriteFIFO(pData, 64);//Write data block to A7139 internal FIFO buffer
	A7139_StrobeCmd(A7139_TX_CMD);//Send command card to make A7139 enter the "send" state, after which A7139 will package the data and send it automatically
	A7139_DelayMS(1);
	while (A7139_GIO1_IN())
	{
		A7139_DelayMS(10);
		retry++;
		if (retry == (A7139_SEND_TIME_OUT + 1)) return FALSE;
	}

	return TRUE;
}




/************************************************* ************************************************** **********************
* Function: bool A7139_WaitRxData (u8 pData [64], u16 TimeOut)
* Function: A7139 receive data
* Parameters: pData: receive data buffer, the size is fixed at 64 bytes; TimeOut: wait time, unit is 10ms, if it is 0, it will wait
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: A7139 receiving function
************************************************** ************************************************** *********************/
bool A7139_WaitRxData(u8 pData[64], u16 TimeOut)
{
	u16 retry = 0;

	A7139_StrobeCmd(A7139_IDLE_CMD);
	A7139_DelayMS(1);
	A7139_StrobeCmd(A7139_RESRFIFO_CMD);
	A7139_DelayMS(1);
	A7139_StrobeCmd(A7139_STBY_CMD);
	A7139_DelayMS(1);
	A7139_StrobeCmd(A7139_RX_CMD);
	A7139_DelayMS(1);
	while (A7139_GIO1_IN())
	{
		A7139_DelayMS(10);
		if (TimeOut > 0)
		{
			retry++;
			if (retry > (TimeOut + 1)) return FALSE;
		}
	}
	//Data reception is completed
	A7139_ReadFIFO(pData, 64);//Read data block from A7139 internal FIFO buffer

	return TRUE;
}


/************************************************* ************************************************** **********************
* Function: bool A7139_RxMode (void)
* Function: A7139 enter the receiving mode
* Parameter: None
* Return: TRUE: success; FALSE: failure
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: A7139 enters receiving mode
************************************************** ************************************************** *********************/
bool A7139_RxMode(void)
{
	u16 retry = 0;

	A7139_StrobeCmd(A7139_IDLE_CMD);
	A7139_DelayMS(1);
	A7139_StrobeCmd(A7139_RESRFIFO_CMD);
	A7139_DelayMS(1);
	A7139_StrobeCmd(A7139_STBY_CMD);
	A7139_DelayMS(1);
	A7139_StrobeCmd(A7139_RX_CMD);
	A7139_DelayMS(1);
	if (A7139_GIO1_IN()) return TRUE;
	else return FALSE;
}



/************************************************* ************************************************** **********************
* Function: void A7139_SetFreq (float RfFreq)
* Function: A7139 configure RF frequency
* Parameter: rfFreq: RF frequency in MHz
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: Initial configuration
************************************************** ************************************************** *********************/
void A7139_SetFreq(float RfFreq)
{
	float divFreq = RfFreq / 12.800f;
	u8 intFreq = (u8)(divFreq);//integer part
	float fltFreq = divFreq - intFreq * 1.000f;//fraction part
	u16 fpFreg = (u16)(fltFreq * 65536);//FP register val
	u16 orgVal;

	A7139_StrobeCmd(A7139_STBY_CMD);//enter stand-by mode
		   //AFC [15:15] = 0
	orgVal = A7139Config[A7139_PLL3] & 0x7FFF;
	A7139_WriteReg(A7139_PLL3, orgVal);
	//RFC [15:12] = 0000
	orgVal = A7139Config[A7139_PLL6] & 0x0FFF;
	A7139_WriteReg(A7139_PLL6, orgVal);
	//MD1 [12:12] = 0,1
	if (RfFreq < 860)//433-510
		orgVal = A7139Config[A7139_PLL4] & 0xEFFF;
	else//868-915
		orgVal = A7139Config[A7139_PLL4] | 0x1000;
	A7139_WriteReg(A7139_PLL4, orgVal);
	//IP [8: 0] = intg
	orgVal = A7139Config[A7139_PLL1] & 0xFF00;
	A7139_WriteReg(A7139_PLL1, orgVal | intFreq);
	//FP [15: 0] = fpFreg
	A7139_WriteReg(A7139_PLL2, fpFreg);
	//FPA [15: 0] = 0x0000
	A7139_WritePageB(A7139_REG9_IF2, 0x0000);
}




u8 A7139_Cal(void)
{
	u8 fbcf;//IF Filter
	u8 vbcf;//VCO Current
	u8 vccf;//VCO Band
	u8 tmp;

	//IF calibration procedure @STB state
	A7139_WriteReg(A7139_MODE, A7139Config[A7139_MODE] | 0x0802);//IF Filter & VCO Current Calibration
	do {
		tmp = A7139_ReadReg(A7139_MODE);
	} while (tmp & 0x0802);
	//for check (IF Filter)
	tmp = A7139_ReadReg(A7139_CALIB);
	//fb = tmp & 0x0F;
	//fcd = (tmp >> 11) & 0x1F;
	fbcf = (tmp >> 4) & 0x01;
	if (fbcf)
	{
		return ERR_CAL;
	}
	//for check (VCO Current)
	tmp = A7139_ReadPageA(A7139_REG8_VCO);
	//vcb = tmp & 0x0F;
	vccf = (tmp >> 4) & 0x01;
	if (vccf)
	{
		return ERR_CAL;
	}
	//RSSI Calibration procedure @STB state
	A7139_WriteReg(A7139_ADC, 0x4C00);//set ADC average = 64
	A7139_WritePageA(A7139_REG8_WOR2, 0xF800);//set RSSC_D = 40us and RS_DLY = 80us
	A7139_WritePageA(A7139_REG8_TX1, A7139Config_PageA[A7139_REG8_TX1] | 0xE000);//set RC_DLY = 1.5ms
	A7139_WriteReg(A7139_MODE, A7139Config[A7139_MODE] | 0x1000);//RSSI Calibration
	do {
		tmp = A7139_ReadReg(A7139_MODE);
	} while (tmp & 0x1000);
	A7139_WriteReg(A7139_ADC, A7139Config[A7139_ADC]);
	A7139_WritePageA(A7139_REG8_WOR2, A7139Config_PageA[A7139_REG8_WOR2]);
	A7139_WritePageA(A7139_REG8_TX1, A7139Config_PageA[A7139_REG8_TX1]);
	//VCO calibration procedure @STB state
	A7139_WriteReg(A7139_MODE, A7139Config[A7139_MODE] | 0x0004);//VCO Band Calibration
	do {
		tmp = A7139_ReadReg(A7139_MODE);
	} while (tmp & 0x0004);
	//for check (VCO Band)
	tmp = A7139_ReadReg(A7139_CALIB);
	//vb = (tmp >> 5) & 0x07;
	vbcf = (tmp >> 8) & 0x01;
	if (vbcf)
	{
		return ERR_CAL;
	}
	return 0;
}




//PC4 receive interrupt program
void EXTI4_IRQHandler(void)
{
	if (pRxCallBack!= NULL)
	{
		pRxCallBack();//Call the callback function
	}
	EXTI_ClearInt(4);//Clear interrupt
}



/************************************************* ************************************************** **********
 * File name: A7139.h
 * Function: STM32 A7139 driver
 * Author: cp1300@139.com
 * Creation time: 2015-07-19
 * Last modified time: 2015-07-19
 * Details: A7139 driver
************************************************** ************************************************** *********/
#ifndef __A7139_H__
#define __A7139_H__
#include "system.h"



//Three-line spi
#define A7139_DIO_OUT PAout (7)
#define A7139_DIO_IN () PAin (7)
#define A7139_CS PAout (4)
#define A7139_CLK PAout (6)
#define A7139_OutMode () GPIOx_OneInit (GPIOA, 7, OUT_PP, SPEED_50M)
#define A7139_InMode () GPIOx_OneInit (GPIOA, 7, IN_IPU, IN_IN)
#define A7139_GIO1 PCin (4)	


#define A7139_IO_INIT ()\
	DeviceClockEnable (DEV_GPIOA, ENABLE);/* Enable GPIOA clock */\
	GPIOx_Init (GPIOA, BIT4 | BIT6 | BIT7, OUT_PP, SPEED_50M);\
	DeviceClockEnable (DEV_GPIOC, ENABLE);/* Enable GPIOC clock */\
	GPIOx_Init (GPIOC, BIT4, IN_IPT, IN_IN);\


//interface
//DIO
#define A7139_DIO_H () (A7139_DIO_OUT = 1)//Output 1
#define A7139_DIO_L () (A7139_DIO_OUT = 0)//Output 0
#define A7139_CS_H () (A7139_CS = 1)
#define A7139_CS_L () (A7139_CS = 0)
#define A7139_CLK_H () (A7139_CLK = 1)
#define A7139_CLK_L () (A7139_CLK = 0)
#define A7139_GIO1_IN () (A7139_GIO1)
//Interrupt
#define A7139_EnableInt () NVIC_IntEnable (IRQ_EXTI4, ENABLE)//The total interrupt is turned on
#define A7139_DisableInt () NVIC_IntEnable (IRQ_EXTI4, DISABLE)//The total interrupt is closed
#define A7139_EnableRxInt () EXTI_IntConfig (GPIO_C, 4, NegEdge)//Falling edge triggers interrupt
#define A7139_DisableRxInt () EXTI_IntConfig (GPIO_C, 4, OFF_INT)//Close trigger interrupt
//Clear receive interrupt
#define A7139_ClearRxInt () EXTI_ClearInt (4)//Clear interrupt


//Control register
typedef enum
{
	A7139_SCLOCK = 0x00,//System clock register
	A7139_PLL1 = 0x01,//PLL1
	A7139_PLL2 = 0x02,//PLL2
	A7139_PLL3 = 0x03,//PLL3
	A7139_PLL4 = 0x04,//PLL4
	A7139_PLL5 = 0x05,//PLL5
	A7139_PLL6 = 0x06,//PLL6
	A7139_CRYSTAL = 0x07,//Crystal settings
	A7139_PREG8S = 0x08,//Register group, switched by CRYSTAL control
	A7139_PREG9S = 0x09,//register group, switched by CRYSTAL control
	A7139_RX1 = 0x0A,//Receive setting 1
	A7139_RX2 = 0x0B,//Receive setting 2
	A7139_ADC = 0x0C,//ADC
	A7139_PIN = 0x0D,//PIN
	A7139_CALIB = 0x0E,//Calibration
	A7139_MODE = 0x0F,//Mode control
} A7139_CREG;

//Control register group A
typedef enum
{
	//Register 8
	A7139_REG8_TX1 = 0,//addr8 page0, 
	A7139_REG8_WOR1 = 1,//addr8 page1, 
	A7139_REG8_WOR2 = 2,//addr8 page2, 
	A7139_REG8_RF = 3,//addr8 page3, 
	A7139_REG8_POWER = 4,//addr8 page4, 
	A7139_REG8_AGCRC = 5,//addr8 page5, 
	A7139_REG8_AGCCON1 = 6,//addr8 page6, 
	A7139_REG8_AGCCON2 = 7,//addr8 page7, 
	A7139_REG8_GPIO = 8,//addr8 page8, 
	A7139_REG8_CKO = 9,//addr8 page9, 
	A7139_REG8_VCO = 10,//addr8 page10,
	A7139_REG8_CHG1 = 11,//addr8 page11,
	A7139_REG8_CHG2 = 12,//addr8 page12,
	A7139_REG8_FIFO = 13,//addr8 page13,
	A7139_REG8_CODE = 14,//addr8 page14,
	A7139_REG8_WCAL = 15,//addr8 page15,
} A7139_PAGE_A;


//Control register group B
typedef enum
{
	//Register 9
	A7139_REG9_TX2 = 0,//addr9 page0, 
	A7139_REG9_IF1 = 1,//addr9 page1,
	A7139_REG9_IF2 = 2,//addr9 page2,
	A7139_REG9_ACK = 3,//addr9 page3,
	A7139_REG9_ART = 4,//addr9 page4,
} A7139_PAGE_B;


//Strobe command
typedef enum
{
	A7139_WCR_CMD = 0x00,//Write control register
	A7139_RCR_CMD = 0x80,//Read control register
	A7139_WID_CMD = 0x20,//write ID
	A7139_RID_CMD = 0xA0,//Read ID
	A7139_WFIFO_CMD = 0x40,//write FIFO
	A7139_RFIFO_CMD = 0xC0,//Read FIFO	
	A7139_RESRF_CMD = 0x70,//Reset RF
	A7139_RESTFIFO_CMD = 0x60,//Reset the transmit FIFO
	A7139_RESRFIFO_CMD = 0xE0,//Reset the receive FIFO
	A7139_SLEEP_CMD = 0x10,//SLEEP mode
	A7139_IDLE_CMD = 0x12,//IDLE mode
	A7139_STBY_CMD = 0x14,//Standby mode
	A7139_PLL_CMD = 0x16,//PLL mode
	A7139_RX_CMD = 0x18,//RX mode
	A7139_TX_CMD = 0x1A,//TX mode
	A7139_TSLEEP_CMD = 0x1C,//Deep sleep mode tri-state
	A7139_PSLEEP_CMD = 0x1F,//Pull up in Deep sleep mode
} A7139_STROBE_CMD;


#define ERR_PARAM 0x01
#define ERR_PLATFORM 0x02
#define ERR_UNK 0x03
#define ERR_CAL 0x04
#define ERR_TMO 0xFF		
#define ERR_RCOSC_CAL 0x04
#define OK_RCOSC_CAL 0x05
#define ERR_GET_RSSI 0x00


//Macro definition interface
#ifdef _UCOS_II_
#include "ucos_ii.h"
#define A7139_DelayMS (x) OSTimeDlyHMSM (0,0,0, x)//ms delay, maximum 999ms
#else
#include "delay.h"
#define A7139_DelayMS (x) Delay_MS (x)
#endif


//related functions
void A7139_SoftReset(void);//A7139 soft reset
bool A7139_Init(u32 RF_ID, void (*p) ());//A7139 initialization
void A7139_WriteReg(A7139_CREG RegAddr, u16 data);//Write to control register
u16 A7139_ReadReg(A7139_CREG RegAddr);//Read control register
u32 A7139_ReadID(void);//Read A7139 ID
void A7139_WriteID(u32 ID);//Set A7139 ID
u16 A7139_ReadPageA(A7139_PAGE_A RegAddr);//Read control register group register A
void A7139_WritePageA(A7139_PAGE_A RegAddr, u16 data);//Write to control register bank register A
u16 A7139_ReadPageB(A7139_PAGE_B RegAddr);//Read control register bank register B
void A7139_WritePageB(A7139_PAGE_B RegAddr, u16 data);//Write control register bank register B
void A7139_RestRxFIFO(void);//A7139 resets the receive FIFO pointer
void A7139_RestTxFIFO(void);//A7139 resets the transmit FIFO pointer
void A7139_ReadFIFO(u8* pData, u8 DataLen);//A7139 read FIFO
void A7139_WriteFIFO(u8* pData, u8 DataLen);//A7139 write FIFO
void A7139_StrobeCmd(A7139_STROBE_CMD StrobeCmd);//A7139 sends Strobe command
void A7139_Config(void);//Configure A7139
void A7139_SetFreq(float RfFreq);//A7139 configure RF frequency
bool A7139_SendData(u8 pData[64], bool isClear);//A7139 send data
bool A7139_WaitRxData(u8 pData[64], u16 TimeOut);//Waiting to receive data
bool A7139_RxMode(void);//A7139 enters receive mode


#define A7139_ReadDeverID () (A7139_ReadPageB (A7139_REG9_TX2))//Read device hardware ID, read only
#define A7139_RestRxFIFO () A7139_StrobeCmd (A7139_RESRFIFO_CMD)//A7139 reset the receive FIFO pointer
#define A7139_RestTxFIFO () A7139_StrobeCmd (A7139_RESTFIFO_CMD)//A7139 reset the transmit FIFO pointer
#define A7139_SoftReset () A7139_StrobeCmd (A7139_RESRF_CMD)//A7139 soft reset

u8 A7139_Cal(void);


#endif//A7139


Driver layer

/************************************************* ************************************************** **********
 * File name: USER_RF.c
 * Function: USER_RF wireless transceiver application layer
 * Author: cp1300@139.com
 * Creation time: 2015-08-16
 * Last modified time: 2015-08-16
 * Details: RF driver
************************************************** ************************************************** *********/
#include "SYSTEM.H"
#include "GPIO_INIT.H"
#include "USER_RF.H"
#include "A7139.H"
#include "stdlib.h"


//Number of retries per package
#define RF_SEND_RETRY 8
//Single packet data timeout
#define RF_TIME_OUT 20//Unit 10ms, total 200ms
//Single packet data frame data size
#define RF_FRAME_DATA_SIZE (RF_HARDWAVE_FRAME_SIZE-9)
//Delayed response to ACK
#define RF_ACK_DELAY 8//Unit ms, the ACK response must be delayed, otherwise the sender will not receive the response ACK


//Single packet communication data format
typedef struct
{
	u16 Addr;
	u16 PackCnt;
	u16 AllPackCnt;
	u8 Len;
	u8 DataBuff[RF_FRAME_DATA_SIZE];
	u16 CRC16;
} RF_DATA_FRAME;


//The underlying response packet
typedef struct
{
	u16 Addr;
	u16 PackCnt;
	u16 AllPackCnt;
	u8 Ack;
	u8 DataBuff[RF_FRAME_DATA_SIZE];
	u16 CRC16;
} RF_ACK_FRAME;


//Related RF status structure
typedef struct
{
	bool NewDataFlag;//New data received
	bool BuffFull;//Receive Buff Full
	u8* pRxBuff;//Receive Buff pointer
	u16 RxBuffSize;//Receive buffer size, one frame data size
	u16 UartRxCnt;//Receive data counter
	u16 RF_Addr;//Device address
	u16 PackCnt;//Package counter
	//Single packet data buffer
	u8 TxTempBuff[RF_HARDWAVE_FRAME_SIZE];
	u8 RxTempBuff[RF_HARDWAVE_FRAME_SIZE];
} RF_TypeDef;
static RF_TypeDef RF_Config;


//Debug switch
#define USER_RF_DBUG 1
#if USER_RF_DBUG
#include "system.h"
#define USER_RF_debug (format, ...) uart_printf (format, ## __ VA_ARGS__)
#else
#define USER_RF_debug (format, ...)/\
/
#endif//USER_RF_DBUG




//CRC check
static u16 CRC16_Check(u8* Pushdata, u16 length);



/************************************************* ************************************************** **********************
* Function: bool RF_Init (u32 RF_ID, u16 Addr, u8 * pRxBuff, u16 RxBuffSize, void (* p) ())
* Function: RF initialization
* Parameters: RF_ID: RF ID, communication channel address, must be consistent to communicate with each other; Addr: device address, software-defined address; pRxBuff: receive buffer;
				RxBuffSize: receive buffer size; p: receive interrupt callback function
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: Initial configuration 0x13547862
************************************************** ************************************************** *********************/
bool RF_Init(u32 RF_ID, u16 Addr, u8* pRxBuff, u16 RxBuffSize, void (*p) ())
{
	u8 i;

	RF_Config.RF_Addr = Addr;//Record the local address
	RF_Config.pRxBuff = pRxBuff;//Receive buffer pointer
	RF_Config.RxBuffSize = RxBuffSize;//Receive buffer size
	//Initialize the hardware
	for (i = 0; i < 3; i++)
	{
		if (A7139_Init(RF_ID, p) == TRUE)
		{
			USER_RF_debug("[RF] successfully initialized RF hardware!\R\n");
			break;
		}
		else
		{
			USER_RF_debug("[RF] failed to initialize RF hardware!\R\n");
			RF_DelayMS(100);
		}
	}
	if (i == 3) return FALSE;


	return TRUE;
}



/************************************************* ************************************************** **********************
* Function: bool RF_SendData (u8 * pBuff, u16 Len)
* Function: RF send data packet
* Parameters: pBuff: send data buffer; Len: send data length
* Return: TRUE: successful transmission (successful response); FALSE: failed transmission, failed response
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-07-19
* Last modified: 2015-07-19
* Description: RF transmission application layer, a packet of data may be divided into multiple packets of data to send
************************************************** ************************************************** *********************/
bool RF_SendData(u8* pBuff, u16 Len)
{
	u16 i, j, k;
	u16 AllPackCnt;
	u16 PackCnt;
	u8 EndPackSize = Len % RF_FRAME_DATA_SIZE;
	RF_DATA_FRAME* pFrame = (RF_DATA_FRAME*)RF_Config.TxTempBuff;
	RF_ACK_FRAME* pAckFrame = (RF_ACK_FRAME*)RF_Config.RxTempBuff;

	A7139_DisableRxInt();//Close receive interrupt
	//Calculate the total number of packages
	AllPackCnt = Len / RF_FRAME_DATA_SIZE + ((EndPackSize) ? 1 : 0);
	//If the last packet is 0, it is a full packet
	if (EndPackSize == 0) EndPackSize = RF_FRAME_DATA_SIZE;
	//Cycle sending data packets
	for (PackCnt = 0; PackCnt < AllPackCnt; PackCnt++)
	{
		pFrame->Addr = RF_Config.RF_Addr;//Address
		pFrame->PackCnt = PackCnt;//Current packet count	
		pFrame->AllPackCnt = AllPackCnt;//Total number of packets
		if (PackCnt == (AllPackCnt - 1))//The last packet data
		{
			memcpy(pFrame->DataBuff, &pBuff[PackCnt * RF_FRAME_DATA_SIZE], EndPackSize);//Copy the data packet content
		}
		else
		{
			memcpy(pFrame->DataBuff, &pBuff[PackCnt * RF_FRAME_DATA_SIZE], RF_FRAME_DATA_SIZE);//Copy data packet content
		}
		if (PackCnt == (AllPackCnt - 1))//The last packet data
		{
			pFrame->Len = EndPackSize;//The last packet data size
			pFrame->CRC16 = CRC16_Check(RF_Config.TxTempBuff, RF_HARDWAVE_FRAME_SIZE - 2);//Calculate CRC16

			for (i = 0; i < (RF_SEND_RETRY + 1); i++)//Send failed and try again
			{
				if (A7139_SendData(RF_Config.TxTempBuff, TRUE) == TRUE)//Send successfully
				{
					if (A7139_WaitRxData(RF_Config.RxTempBuff, RF_TIME_OUT) == TRUE)//Receive data successfully
					{
						if (pAckFrame->Addr == RF_Config.RF_Addr)//The returned data address is correct
						{
							if (pAckFrame->CRC16 == CRC16_Check(RF_Config.RxTempBuff, 64 - 2))//The returned data is correct
							{
								if (pAckFrame->Ack)//ACK is correct
								{
									break;
								}
							}

						}
					}
					else
					{
						USER_RF_debug("[RF] packet ACK response timed out!\R\n");
					}
				}
				else//Empty the send and clear the send buffer
				{
					USER_RF_debug("[RF] packet sending timeout!\R\n");
					A7139_StrobeCmd(A7139_RESTFIFO_CMD);
					OSTimeDlyHMSM(0, 0, 0, 1);
				}
			}
			if (i == (RF_SEND_RETRY + 1)) return FALSE;//Send timeout
		}
		else//not the last packet of data
		{
			pFrame->Len = RF_FRAME_DATA_SIZE;//Data packet length
			pFrame->CRC16 = CRC16_Check(RF_Config.TxTempBuff, RF_HARDWAVE_FRAME_SIZE - 2);//Calculate CRC16

			if (PackCnt == 0)//First package
			{
				for (i = 0; i < (RF_SEND_RETRY + 1); i++)//Send failed and try again
				{
					if (A7139_SendData(RF_Config.TxTempBuff, TRUE) == TRUE)//Send successfully
					{
						if (A7139_WaitRxData(RF_Config.RxTempBuff, RF_TIME_OUT) == TRUE)//Receive data successfully
						{
							if (pAckFrame->Addr == RF_Config.RF_Addr)//The returned data address is correct
							{
								if (pAckFrame->CRC16 == CRC16_Check(RF_Config.RxTempBuff, 64 - 2))//The returned data is correct
								{
									if (pAckFrame->Ack)//ACK is correct
									{
										break;
									}
								}

							}
						}
						else
						{
							USER_RF_debug("[RF] packet ACK response timed out!\R\n");
						}
					}
					else
					{
						USER_RF_debug("[RF] packet sending timeout!\R\n");
						A7139_StrobeCmd(A7139_RESTFIFO_CMD);
						OSTimeDlyHMSM(0, 0, 0, 1);
					}
				}
				if (i == (RF_SEND_RETRY + 1)) return FALSE;//Send timeout
			}
			else
			{
				for (i = 0; i < (RF_SEND_RETRY + 1); i++)//Send failed and try again
				{
					if (A7139_SendData(RF_Config.TxTempBuff, TRUE) == TRUE)//Send successfully
					{
						if (A7139_WaitRxData(RF_Config.RxTempBuff, RF_TIME_OUT) == TRUE)//Receive data successfully
						{
							if (pAckFrame->Addr == RF_Config.RF_Addr)//The returned data address is correct
							{
								if (pAckFrame->CRC16 == CRC16_Check(RF_Config.RxTempBuff, 64 - 2))//The returned data is correct
								{
									if (pAckFrame->Ack)//ACK is correct
									{
										break;
									}
								}

							}
						}
						else
						{
							USER_RF_debug("[RF] packet ACK response timed out!\R\n");
						}
					}
					else//Empty the send and clear the send buffer
					{
						USER_RF_debug("[RF] packet sending timeout!\R\n");
						A7139_StrobeCmd(A7139_RESTFIFO_CMD);
						OSTimeDlyHMSM(0, 0, 0, 1);
					}
				}
				if (i == (RF_SEND_RETRY + 1)) return FALSE;//Send timeout
			}
		}
	}

	return TRUE;
}



/************************************************* ************************************************** **********************
* Function: void RF_ClearRxCnt (void)
* Function: Clear received data counter
* Parameter: None
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-08-16
* Last modified: 2015-08-16
* Description: RF interrupt received data counter
************************************************** ************************************************** *********************/
void RF_ClearRxCnt(void)
{
	RF_Config.BuffFull = FALSE;//Clear the receive buffer full mark
	RF_Config.NewDataFlag = FALSE;//Clear new data flag
	RF_Config.UartRxCnt = 0;//Received data size is 0
	RF_Config.PackCnt = 0;//Package counter is 0
}




/************************************************* ************************************************** **********************
* Function: bool RF_RxMode (void)
* Function: RF enters receiving mode
* Parameter: None
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-08-16
* Last modified: 2015-08-16
* Description: In RF receiving mode, all data will be received using the receive interrupt, and it will prompt after the data is received
************************************************** ************************************************** *********************/
void RF_RxMode(void)
{
	A7139_RxMode();//A7139 enters receive mode
	A7139_ClearRxInt();//Clear receive interrupt
	A7139_EnableRxInt();//Open receive interrupt
}


/************************************************* ************************************************** **********************
* Function: bool RF_GetDataFlag (void)
* Function: RF new data mark
* Parameter: None
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-08-16
* Last modified: 2015-08-16
* Description: Valid after receiving new data packet
************************************************** ************************************************** *********************/
bool RF_GetDataFlag(void)
{
	return ((RF_Config.NewDataFlag) && (RF_Config.UartRxCnt)) ? TRUE : FALSE;
}


/************************************************* ************************************************** **********************
* Function: u16 RF_GetRxCnt (void)
* Function: RF to get the length of received data
* Parameter: None
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-08-16
* Last modified: 2015-08-16
* Description: Get new data length
************************************************** ************************************************** *********************/
u16 RF_GetRxCnt(void)
{
	return RF_Config.UartRxCnt;
}


/************************************************* ************************************************** **********************
* Function: void RF_GetRxData (u8 * pDataBuff, u16 len)
* Function: Read the received data
* Parameters: pDataBuff: data buffer; len: the number to be read
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-08-16
* Last modified: 2015-08-16
* Description: It must be read after receiving data to be effective
				After reading the data, please clear the reception counter
************************************************** ************************************************** *********************/
void RF_GetRxData(u8* pDataBuff, u16 len)
{
	if (len > RF_Config.RxBuffSize) len = RF_Config.RxBuffSize;//Prevent the buffer size from being exceeded
	memcpy(pDataBuff, RF_Config.pRxBuff, len);
}


/************************************************* ************************************************** **********************
* Function: void RF_RxTask (void)
* Function: RF data receiving thread
* Parameter: None
* Back: None
* Dependency: the definition of the underlying macro
* Author: cp1300@139.com
* Time: 2015-08-16
* Last modified: 2015-08-16
* Note: If you are not using ucOS, please call the secondary function in the receiving interrupt. If you are using ucos, please call it in the receiving thread.
				Wake up, and the receiving thread has a higher priority, otherwise the response may time out, resulting in unstable communication
************************************************** ************************************************** *********************/
void RF_RxTask(void)
{
	static RF_DATA_FRAME* pFrame;
	static RF_ACK_FRAME* pAckFrame;
	static u16 crc16;

	A7139_DisableRxInt();//Close receive interrupt
	if (A7139_GIO1_IN() == 0)//The status is valid
	{
		pFrame = (RF_DATA_FRAME*)RF_Config.RxTempBuff;
		pAckFrame = (RF_ACK_FRAME*)RF_Config.TxTempBuff;
		A7139_ReadFIFO(RF_Config.RxTempBuff, RF_HARDWAVE_FRAME_SIZE);//Read data block from A7139 internal FIFO buffer
		//The address must be consistent, and the crc check is correct, the packet count is valid
		if ((pFrame->Addr == RF_Config.RF_Addr) && (pFrame->PackCnt < pFrame->AllPackCnt))
		{
			crc16 = CRC16_Check(RF_Config.RxTempBuff, RF_HARDWAVE_FRAME_SIZE - 2);
			if (crc16 == pFrame->CRC16)
			{
				//response
				pAckFrame->Addr = pFrame->Addr;//Address
				pAckFrame->AllPackCnt = pFrame->AllPackCnt;//Total number of packages
				pAckFrame->PackCnt = pFrame->PackCnt;//current packet counter
				pAckFrame->Ack = 0x01;//response is valid
				pAckFrame->CRC16 = CRC16_Check(RF_Config.TxTempBuff, RF_HARDWAVE_FRAME_SIZE - 2);//Calculation check


				RF_DelayMS(RF_ACK_DELAY);//Delay for sending ACK
				A7139_SendData(RF_Config.TxTempBuff, TRUE);//Send ACK data

				USER_RF_debug("[RF] received packet is valid!\R\n");
				if (RF_Config.PackCnt == pFrame->PackCnt)//The data packet counter is only valid if it is consistent, to prevent duplication
				{
					if ((RF_Config.UartRxCnt + pFrame->Len) < RF_Config.RxBuffSize)//Receive buffer is not full
					{
						memcpy(&RF_Config.pRxBuff[RF_Config.UartRxCnt], pFrame->DataBuff, pFrame->Len);//Copy data to the receive buffer
						RF_Config.UartRxCnt + = pFrame->Len;//Total length of recorded data
					}
					else
					{
						RF_Config.BuffFull = TRUE;//Data receiving buffer is full
					}
					RF_Config.PackCnt++;//Offset to the next packet data
				}
				if (RF_Config.PackCnt > = pFrame->AllPackCnt)//Data reception is completed
				{
					RF_Config.NewDataFlag = TRUE;//The data is received, new data can be read
				}
			}
			else
			{
				//response
				pAckFrame->Addr = pFrame->Addr;//Address
				pAckFrame->AllPackCnt = pFrame->AllPackCnt;//Total number of packages
				pAckFrame->PackCnt = pFrame->PackCnt;//current packet counter
				pAckFrame->Ack = 0x00;//Invalid response
				pAckFrame->CRC16 = CRC16_Check(RF_Config.TxTempBuff, RF_HARDWAVE_FRAME_SIZE - 2);//Calculation check

				RF_DelayMS(RF_ACK_DELAY);//Delay for sending ACK
				A7139_SendData(RF_Config.TxTempBuff, TRUE);//Send NAK data
				USER_RF_debug("[RF] received packet is invalid!\R\n");
			}
		}
	}
	RF_RxMode();//Re-enter receive mode
}



//CRC check
static u16 CRC16_Check(u8* Pushdata, u16 length)
{
	u16 Reg_CRC = 0xffff;
	u8 Temp_reg = 0x00;
	u16 i, j;

	for (i = 0; i < length; i++)
	{
		Reg_CRC^ = *Pushdata++;

		for (j = 0; j < 8; j++)
		{
			if (Reg_CRC & 0x0001)
				Reg_CRC = Reg_CRC >> 1 ^ 0xA001;
			else
				Reg_CRC >> = 1;

		}
	}
	return (Reg_CRC);
}


/************************************************* ************************************************** **********
 * File name: USER_RF.c
 * Function: USER_RF wireless transceiver application layer
 * Author: cp1300@139.com
 * Creation time: 2015-08-16
 * Last modified time: 2015-08-16
 * Details: RF driver
************************************************** ************************************************** *********/
#ifndef __USER_RF_H__
#define __USER_RF_H__
#include "system.h"

//Related definition
#define RF_HARDWAVE_FRAME_SIZE 64//Data size of one packet of RF hardware


//Macro definition interface
#ifdef _UCOS_II_
#include "ucos_ii.h"
#define RF_DelayMS (x) OSTimeDlyHMSM (0,0,0, x)//ms delay, maximum 999ms
#else
#include "delay.h"
#define RF_DelayMS (x) Delay_MS (x)
#endif



bool RF_Init(u32 RF_ID, u16 Addr, u8* pRxBuff, u16 RxBuffSize, void (*p) ());//RF initialization
bool RF_SendData(u8* pBuff, u16 Len);//RF send data packet
void RF_RxTask(void);//RF receive data processing, call in receive interrupt or receive thread
void RF_RxMode(void);//RF enters the receiving mode
bool RF_GetDataFlag(void);//RF new data flag
u16 RF_GetRxCnt(void);//Get the new data length
void RF_GetRxData(u8* pDataBuff, u16 len);//Read new data
void RF_ClearRxCnt(void);//Clear receive counter

#endif//__ USER_RF_H__


//Send at the application layer

//Task 1:
//System tasks
void TaskSystem(void* pdata)
{
	u8 i;
	u8 TxBuff[64];
	u8 RxBuff[64];
	//RF_ACK_FRAME * pAckFrame = (RF_ACK_FRAME *) TxBuff;
	s16 Temp;
	u16 Humi;
	u16 Voltage;
	u16 len;

	DeviceClockEnable(GPIO_A, ENABLE);
	GPIOx_Init(GPIOA, BIT12, OUT_PP, SPEED_10M);
	PAout(12) = 1;//Start A7139 power supply

	//Initialize related threads
	OSTaskCreate(TaskLED, (void*)0, &TASK_LED_STK[LED_STK_SIZE - 1], LED_TASK_Prio);//LED
	OSTimeDlyHMSM(0, 0, 0, 10);

	//Read the power supply voltage
	ADC1_Init();//Initialize ADC1
	ADC1_PowerUP();
	DeviceClockEnable(DEV_GPIOA, ENABLE);/* Enable PA clock */
	GPIOx_Init(GPIOA, BIT1, IN_AIN, IN_IN);/*/PA1 analog input */
	Voltage = GetDCVoltage() / 10;
	uart_printf("Battery voltage:% d.% 02dV\r\n", Voltage / 100, Voltage % 100);

	//Initialize A7139
	if (RF_Init(0x13547862, 1, TempBuff, 2048 - 1, ThaskCallBack) == TRUE)
	{
		for (i = 0; i < 10; i++)
		{
			LED_FLASH();
			OSTimeDlyHMSM(0, 0, 0, 10);
		}
		LED_OFF();
	}
	else//initialization failed
	{

	}


	if (1)//Sender
	{
		//Initialize and read temperature and humidity
		AM2305_Init();
		for (i = 0; i < 10; i++)
		{
			if (AM2305_ReadData(&Temp, &Humi) == TRUE)
			{
				uart_printf("Temperature:% d.% d ℃\t Humidity:% d.% d %% RH\r\n", Temp / 10, abs(Temp) % 10, Humi / 10, Humi % 10);
				break;
			}

			OSTimeDlyHMSM(0, 0, 1, 0);
		}
		if (i == 10)//Failed to read temperature and humidity
		{

		}

		len = sprintf((char*)TempBuff, "Battery voltage:% d.% 02dV\tTemperature:% d.% d ℃\t Humidity:% d.% d %% RH\r\n", Voltage / 100, Voltage % 100, Temp / 10, abs(Temp) % 10, Humi / 10, Humi % 10);

		//send data
		uart_printf("Send data:");
		for (i = 0; i < 3; i++)
		{
			LED_ON();
			if (RF_SendData(TempBuff, len) == TRUE)
			{
				uart_printf("Success!\r\n");
				break;
			}
		}
		if (i == 3)//Send failed
		{
			uart_printf("Fail!\r\n");
		}
		LED_OFF();


		//Data transmission is completed, sleep
		PAout(12) = 0;//Turn off the power
		uart_printf("Collection and sending completed, power off, sleep!\r\n");
		OSTimeDlyHMSM(0, 0, 0, 100);
		EXTI_IntConfig(GPIO_A, 0, PosEdge);//PA0 rising edge interrupt, used to wake up the microcontroller
		SYSTEM_Standby();
	}
	else//receiver
	{
		RF_RxMode();//Enter the receiving mode
		RF_ClearRxCnt();//Clear receive buffer
	}


	Application layer reception

		//A7139 receive interrupt callback function, used to wake up the receiving thread
		void ThaskCallBack(void)
	{
		OSTaskResume(LED_TASK_Prio);//Wake up the data receiving thread
	}


	//Task 1:
	//System tasks
	void TaskSystem(void* pdata)
	{
		u8 i;
		u8 TxBuff[64];
		u8 RxBuff[64];
		//RF_ACK_FRAME * pAckFrame = (RF_ACK_FRAME *) TxBuff;
		s16 Temp;
		u16 Humi;
		u16 Voltage;
		u16 len;

		DeviceClockEnable(GPIO_A, ENABLE);
		GPIOx_Init(GPIOA, BIT12, OUT_PP, SPEED_10M);
		PAout(12) = 1;//Start A7139 power supply

		//Initialize related threads
		OSTaskCreate(TaskLED, (void*)0, &TASK_LED_STK[LED_STK_SIZE - 1], LED_TASK_Prio);//LED
		OSTimeDlyHMSM(0, 0, 0, 10);

		//Read the power supply voltage
		ADC1_Init();//Initialize ADC1
		ADC1_PowerUP();
		DeviceClockEnable(DEV_GPIOA, ENABLE);/* Enable PA clock */
		GPIOx_Init(GPIOA, BIT1, IN_AIN, IN_IN);/*/PA1 analog input */
		Voltage = GetDCVoltage() / 10;
		uart_printf("Battery voltage:% d.% 02dV\r\n", Voltage / 100, Voltage % 100);

		//Initialize A7139
		if (RF_Init(0x13547862, 1, TempBuff, 2048 - 1, ThaskCallBack) == TRUE)
		{
			for (i = 0; i < 10; i++)
			{
				LED_FLASH();
				OSTimeDlyHMSM(0, 0, 0, 10);
			}
			LED_OFF();
		}
		else//initialization failed
		{

		}

		RF_RxMode();//Enter the receiving mode
		RF_ClearRxCnt();//Clear receive buffer


		while (1)
		{
			OSTimeDlyHMSM(0, 0, 1, 100);
			IWDG_Feed();

			if (RF_GetDataFlag() == TRUE)
			{
				len = RF_GetRxCnt();
				if (len > 0)
				{
					RF_GetRxData(TempBuff, len);//Read data
					TempBuff[len] = 0;
					uart_printf("% s", (char*)TempBuff);
				}
				for (i = 0; i < 10; i++)
				{
					LED_FLASH();
					OSTimeDlyHMSM(0, 0, 0, 100);
				}


				RF_ClearRxCnt();//Clear receive buffer
			}
		}
	}



	//Task 2
	//Responsible for data reception
	void TaskLED(void* pdata)
	{
		while (1)
		{
			OSTaskSuspend(LED_TASK_Prio);//Suspend data receiving thread
			LED_ON();
			//After receiving the data wake-up, process the data
			RF_RxTask();//Receive data processing	
			LED_OFF();
		}
	}



	//The data reception adopts the interrupt mode, and the transmission has ACK, and the application layer can eliminate the need for a second response.