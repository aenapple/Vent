#include "stm32l0xx_hal.h"
#include "vars.h"
#include "main.h"
#include "eeprom.h"

#pragma region interrupt and debug monitor vars
// debug monitor variables
//volatile unsigned int dm_lr;		// old value of lr when monitor was triggered
//volatile unsigned int dm_pc;		// old value of pc when monitor was triggered
//volatile unsigned int dm_old_sp;	// calculated value of sp before monitor was triggered (what was it in original function that was interrupted)
//volatile unsigned int dm_counter;	// incremented each time debug monitor is executed
//volatile unsigned int dm_BrkAdr;	// adr of breakpoint used by step commands
//volatile unsigned int dm_UartRequest;		// set by UART interrupt to request actions from dm
//volatile unsigned int dm_UartCmd;			// requested cmd
//volatile unsigned int dm_MainCodeRequest;	// if set my main code then 1ms periodic interrupt with trigger debug monitor
//volatile unsigned int dm_MainCodeCmd;		// set by main code to request actions from dm
volatile unsigned int dm_State;				// dm state machine state
//volatile unsigned int dm_PendingCmd;			// this cmd will be executed after microstep is done
//volatile unsigned int dm_SendResponseAfterMicrostep;	// if set then dm will send UART response msg to debugger after misrocstep is finished
//volatile unsigned int dm_ExecuteMicrosteps;	// if non zero then we need to do specified number of microsteps
volatile unsigned int dm_pc1;		// old value of pc when monitor was triggered - this is set by low interrupt code, used when Pic32make is not enabled
//volatile unsigned int dm_FPB_BreakpointsCount;		// how many breakpoints are supported by this core
//volatile unsigned int dm_FPB_UserBreakpointsCount;	// how many breakpoints can be used by user
//volatile unsigned int dm_RangeStart;	// start of range adr
//volatile unsigned int dm_RangeEnd;		// end of range adr
//volatile unsigned int dm_RangeSpThreshold;	// max value of stack pointer to stop microstepping
//volatile unsigned int dm_FuncStartAdr;	// first address in current function, used as additional params for special cases for microstepping code
//volatile unsigned int dm_FuncStartEnd;	// first address outside current function, used as additional params for special cases for microstepping code
#pragma endregion

#pragma region main vars

// main vars
char msg[MSG_BUF_LEN];		// temp buffer that can be used to compose log messages, etc.
volatile int stop;			// used for testing
volatile unsigned ErrorHandlerCount;
volatile unsigned ErrorHandlerAdr;		// old value of pc when ErrorHandler() was called
volatile int ErrorHandlerLine;
char SerialNumber[7];		// serial number stored in EEPROM
int HwVer;					// board HW version, e.g. BOARD_VER_6001
volatile unsigned x1, x2, x3, x4;
volatile unsigned char Led1BlinkTimer; // decremented in low interrupt
volatile unsigned char Led2BlinkTimer; // decremented in low interrupt
volatile unsigned char gpio1;			// pin state
volatile unsigned char gpio2;			// pin state
volatile unsigned char mode;			// main of operation
volatile unsigned char Gpio2Timer;		// decremented in low interrupt
volatile unsigned char Rssi;			// last RSSI reading, weakest signal: around 70, strongest signal: around 180
volatile unsigned short TxDelayTimer;	// decremented in low interrupt
volatile unsigned short PeriodicMsgTimer;// decremented in low interrupt
volatile unsigned short Timer1;			// decremented in low interrupt
unsigned char LSE_InitFailed;			// set if LSE initialization fails

// interrupt vars
volatile unsigned int lowInterruptSP;	// stack pointer when in low interrupt code
volatile unsigned long long lowInterruptCounter;
volatile unsigned Tim2HighCnt;			// incremented when TIM2 overflows each 65536 us

EEPROM ee;

volatile struct _StatusFlags StatusFlags;	// system status flags

#pragma endregion

#pragma region HAL driver vars
LPTIM_HandleTypeDef hlptim1;

UART_HandleTypeDef hlpuart1;
DMA_HandleTypeDef hdma_lpuart1_rx;
DMA_HandleTypeDef hdma_lpuart1_tx;

UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_rx;
DMA_HandleTypeDef hdma_usart2_tx;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim21;
TIM_HandleTypeDef htim22;

DMA_HandleTypeDef hdma_adc;
ADC_HandleTypeDef hadc;

//SPI_HandleTypeDef hspi1;

#pragma endregion

#pragma region PC UART vars

char PC_LastCmd[PC_RX_BUF_LEN];			// last comnad will be stored here
char PC_RxBuf[PC_RX_BUF_LEN];			// buffer for receiving data from PC filled by DMA
char PC_TxBuf[PC_TX_BUF_LEN];			// buffer used for sending messages to PC
volatile char PC_TxActive;				// high when tx DMA is in progress
volatile int PC_TxTimer;				// used to detect tx timeouts
volatile int PC_TxTimeoutsCounter;		// how many times did tx timeout happened
volatile int PC_RxTimer;				// used to detect rx timeouts
volatile int PC_RxTimeoutsTimer;		// how many times rx timeout happened
volatile char PC_RxActive;				// high when we are in the middle of receiving msg from PC
volatile int PC_DmaRxLen;				// number of bytes received so far
char respDataStr[PC_TX_BUF_LEN];		// response will be composed in this buffer
char *cmds[MAX_CMDS_COUNT];			// array of pointers, each points to the begining of command
char *cmdWords[MAX_WORDS_COUNT];	// array of pointers, eahc points to the beginning of next word in command, first points to command name
int cmdWordsCount;					// number of words in cmdWords[]

#pragma endregion

#pragma region ADC vars
volatile unsigned short Adc1DmaBuf[6];		// DMA will store ADC counts in this buffer
volatile unsigned short Adc1DmaInterruptCounter;	// incremented in DMA interrupt
volatile unsigned short Adc1FilteredCounts[6];	// filter ADC counts scaled to 16 bits, 0xffff = ADCfull range
volatile unsigned char Adc1FilterCounter;	// incremented in DMA interrupt, used to initialize filter
unsigned short VrefIntCal;					// calibration value from STM manufacturing test read from system memory
unsigned short Vdda;						// Vdda voltage in mv calculated from measuring internal Vref and using STM calibration value from system memory
unsigned short t1;							// T1 temperature, 1 count = 0.01 degC
unsigned short t2;							// T2 temperature, 1 count = 0.01 degC
unsigned short t3;							// T3 temperature, 1 count = 0.01 degC
unsigned short Vin;							// Vin voltage in milivolts
unsigned short MotCurrentMA;				// Motor current in mA
unsigned short MaxMotCurrentMA;				// maximum detected value of Motor current in mA
#pragma endregion

#pragma region Radio
unsigned char R_TxBuf[64 + 1];					// transmit buffer
unsigned char R_RxBuf[64 + 1];					// Rx buffer
volatile unsigned R_LastTxTime;				// last time we transmitted
volatile unsigned R_TxCount;				// number of msgs transmitted
volatile unsigned R_RxCount;				// number of msgs received
volatile unsigned R_CrcErrCount;			// number of msgs received with CRC mismatch
volatile unsigned R_FecErrCount;			// number of msgs with bit correction
volatile unsigned char R_CurrentTxPower;	// currently selected Tx power (0-8)
volatile unsigned char R_tbg_tdc_pac;		// current TX2 reg fields TBG+TDC+PAC
#pragma endregion

#pragma region Motor
volatile unsigned short MotTimer;					// decremented every ms, motor will be turned off when timer reaches 0
volatile unsigned short MotOvercurrOffTimer;		// times off period when we reached overcurent
volatile unsigned char MotOvercurrEventCounter;		// incremented when we detected overcurrent
volatile unsigned short MotStallTime;				// incremented when motor current is higher then ee.MotStallCurrentMA
volatile unsigned short MotOvercurrentTime;			// incremented when motor current is higher then MOT_OVERCURRENT_LIMIT_MA
#pragma endregion

#pragma region Mesh Messages
volatile unsigned char mmNextSeqNum = 10;			// 0 to 35
unsigned char mmRxBuf[MM_MSG_LEN];					//
volatile unsigned char mmCycleIndex;				// cycle index of last received or sent MM msg
volatile unsigned char mmSlotIndex;					// slot index of last received or sent MM msg
volatile unsigned char mmTimer;						// timer used to measure one slot time
volatile unsigned char mmSeqCompleteFlag;			// set by ingterrupt code when sequence is complete
volatile unsigned char mmSendRepeatFlag;			// set by ingterrupt code when main code should send repeat msg
volatile unsigned char mmSequenceActive;			// set when sequence is in progress
#pragma endregion
