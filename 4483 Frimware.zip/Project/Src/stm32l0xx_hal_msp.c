/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : stm32l0xx_hal_msp.c
  * Description        : This file provides code for the MSP Initialization
  *                      and de-Initialization codes.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

extern void _Error_Handler(char*, int);
extern DMA_HandleTypeDef hdma_lpuart1_rx;
extern DMA_HandleTypeDef hdma_lpuart1_tx;
extern DMA_HandleTypeDef hdma_usart2_rx;
extern DMA_HandleTypeDef hdma_usart2_tx;
extern DMA_HandleTypeDef hdma_adc;


/* USER CODE END 0 */
/**
  * Initializes the Global MSP.
  */
void HAL_MspInit(void)
{
  /* USER CODE BEGIN MspInit 0 */

  /* USER CODE END MspInit 0 */

  __HAL_RCC_SYSCFG_CLK_ENABLE();
  __HAL_RCC_PWR_CLK_ENABLE();

  /* System interrupt init*/

  /* USER CODE BEGIN MspInit 1 */

  /* USER CODE END MspInit 1 */
}

/**
* @brief LPTIM MSP Initialization
* This function configures the hardware resources used in this example
* @param hlptim: LPTIM handle pointer
* @retval None
*/
void HAL_LPTIM_MspInit(LPTIM_HandleTypeDef* hlptim)
{
  if(hlptim->Instance==LPTIM1)
  {
  /* USER CODE BEGIN LPTIM1_MspInit 0 */

  /* USER CODE END LPTIM1_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_LPTIM1_CLK_ENABLE();
    /* LPTIM1 interrupt Init */
    HAL_NVIC_SetPriority(LPTIM1_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(LPTIM1_IRQn);
  /* USER CODE BEGIN LPTIM1_MspInit 1 */

  /* USER CODE END LPTIM1_MspInit 1 */
  }

}

/**
* @brief LPTIM MSP De-Initialization
* This function freeze the hardware resources used in this example
* @param hlptim: LPTIM handle pointer
* @retval None
*/
void HAL_LPTIM_MspDeInit(LPTIM_HandleTypeDef* hlptim)
{
  if(hlptim->Instance==LPTIM1)
  {
  /* USER CODE BEGIN LPTIM1_MspDeInit 0 */

  /* USER CODE END LPTIM1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_LPTIM1_CLK_DISABLE();

    /* LPTIM1 interrupt DeInit */
    HAL_NVIC_DisableIRQ(LPTIM1_IRQn);
  /* USER CODE BEGIN LPTIM1_MspDeInit 1 */

  /* USER CODE END LPTIM1_MspDeInit 1 */
  }

}

/**
* @brief UART MSP Initialization
* This function configures the hardware resources used in this example
* @param huart: UART handle pointer
* @retval None
*/
void HAL_UART_MspInit(UART_HandleTypeDef* huart)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if (huart->Instance == LPUART1)
  {
      /* USER CODE BEGIN LPUART1_MspInit 0 */

      /* USER CODE END LPUART1_MspInit 0 */
        /* Peripheral clock enable */
      __HAL_RCC_LPUART1_CLK_ENABLE();

      __HAL_RCC_GPIOA_CLK_ENABLE();
      /**LPUART1 GPIO Configuration
      PA2     ------> LPUART1_TX
      PA3     ------> LPUART1_RX
      */
      GPIO_InitStruct.Pin = GPIO_PIN_2 | GPIO_PIN_3;
      GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
      GPIO_InitStruct.Pull = GPIO_NOPULL;
      GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
      GPIO_InitStruct.Alternate = GPIO_AF6_LPUART1;
      HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

      /* LPUART1 DMA Init */
      /* LPUART1_RX Init */
      hdma_lpuart1_rx.Instance = DMA1_Channel3;
      hdma_lpuart1_rx.Init.Request = DMA_REQUEST_5;
      hdma_lpuart1_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
      hdma_lpuart1_rx.Init.PeriphInc = DMA_PINC_DISABLE;
      hdma_lpuart1_rx.Init.MemInc = DMA_MINC_ENABLE;
      hdma_lpuart1_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
      hdma_lpuart1_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
      hdma_lpuart1_rx.Init.Mode = DMA_NORMAL;
      hdma_lpuart1_rx.Init.Priority = DMA_PRIORITY_MEDIUM;
      if (HAL_DMA_Init(&hdma_lpuart1_rx) != HAL_OK)
      {
          _Error_Handler(__FILE__, __LINE__);
      }

      __HAL_LINKDMA(huart, hdmarx, hdma_lpuart1_rx);

      /* LPUART1_TX Init */
      hdma_lpuart1_tx.Instance = DMA1_Channel2;
      hdma_lpuart1_tx.Init.Request = DMA_REQUEST_5;
      hdma_lpuart1_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
      hdma_lpuart1_tx.Init.PeriphInc = DMA_PINC_DISABLE;
      hdma_lpuart1_tx.Init.MemInc = DMA_MINC_ENABLE;
      hdma_lpuart1_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
      hdma_lpuart1_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
      hdma_lpuart1_tx.Init.Mode = DMA_NORMAL;
      hdma_lpuart1_tx.Init.Priority = DMA_PRIORITY_LOW;
      if (HAL_DMA_Init(&hdma_lpuart1_tx) != HAL_OK)
      {
          _Error_Handler(__FILE__, __LINE__);
      }

      __HAL_LINKDMA(huart, hdmatx, hdma_lpuart1_tx);

      /* USER CODE BEGIN LPUART1_MspInit 1 */

      /* USER CODE END LPUART1_MspInit 1 */
  }

  else if (huart->Instance == USART2)
  {
      /* USER CODE BEGIN USART2_MspInit 0 */

      /* USER CODE END USART2_MspInit 0 */
        /* Peripheral clock enable */
      __HAL_RCC_USART2_CLK_ENABLE();

      __HAL_RCC_GPIOA_CLK_ENABLE();
      /**USART2 GPIO Configuration
      PA9     ------> USART2_TX
      PA15     ------> USART2_RX
      */
      GPIO_InitStruct.Pin = GPIO_PIN_9 | GPIO_PIN_15;
      GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
      GPIO_InitStruct.Pull = GPIO_NOPULL;
      GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
      GPIO_InitStruct.Alternate = GPIO_AF4_USART2;
      HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

      /* USART2 DMA Init */
      /* USART2_RX Init */
      hdma_usart2_rx.Instance = DMA1_Channel5;
      hdma_usart2_rx.Init.Request = DMA_REQUEST_4;
      hdma_usart2_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
      hdma_usart2_rx.Init.PeriphInc = DMA_PINC_DISABLE;
      hdma_usart2_rx.Init.MemInc = DMA_MINC_ENABLE;
      hdma_usart2_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
      hdma_usart2_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
      hdma_usart2_rx.Init.Mode = DMA_NORMAL;
      hdma_usart2_rx.Init.Priority = DMA_PRIORITY_MEDIUM;
      if (HAL_DMA_Init(&hdma_usart2_rx) != HAL_OK)
      {
          _Error_Handler(__FILE__, __LINE__);
      }

      __HAL_LINKDMA(huart, hdmarx, hdma_usart2_rx);

      /* USART2_TX Init */
      hdma_usart2_tx.Instance = DMA1_Channel4;
      hdma_usart2_tx.Init.Request = DMA_REQUEST_4;
      hdma_usart2_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
      hdma_usart2_tx.Init.PeriphInc = DMA_PINC_DISABLE;
      hdma_usart2_tx.Init.MemInc = DMA_MINC_ENABLE;
      hdma_usart2_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
      hdma_usart2_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
      hdma_usart2_tx.Init.Mode = DMA_NORMAL;
      hdma_usart2_tx.Init.Priority = DMA_PRIORITY_MEDIUM;
      if (HAL_DMA_Init(&hdma_usart2_tx) != HAL_OK)
      {
          _Error_Handler(__FILE__, __LINE__);
      }

      __HAL_LINKDMA(huart, hdmatx, hdma_usart2_tx);

      /* USER CODE BEGIN USART2_MspInit 1 */

      /* USER CODE END USART2_MspInit 1 */
  }

}

/**
* @brief UART MSP De-Initialization
* This function freeze the hardware resources used in this example
* @param huart: UART handle pointer
* @retval None
*/
void HAL_UART_MspDeInit(UART_HandleTypeDef* huart)
{

}

/**
* @brief TIM_Base MSP Initialization
* This function configures the hardware resources used in this example
* @param htim_base: TIM_Base handle pointer
* @retval None
*/
void HAL_TIM_Base_MspInit(TIM_HandleTypeDef* htim_base)
{
  if(htim_base->Instance==TIM2)
  {
    __HAL_RCC_TIM2_CLK_ENABLE();

    HAL_NVIC_SetPriority(TIM2_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(TIM2_IRQn);

  }
  else if(htim_base->Instance==TIM21)
  {
    __HAL_RCC_TIM21_CLK_ENABLE();

    /* TIM21 interrupt Init */
    HAL_NVIC_SetPriority(TIM21_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(TIM21_IRQn);
  }
  else if (htim_base->Instance == TIM22)
  {
      __HAL_RCC_TIM22_CLK_ENABLE();
  }

}

/**
* @brief TIM_Base MSP De-Initialization
* This function freeze the hardware resources used in this example
* @param htim_base: TIM_Base handle pointer
* @retval None
*/
void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef* htim_base)
{
  if(htim_base->Instance==TIM2)
  {
    __HAL_RCC_TIM2_CLK_DISABLE();
    HAL_NVIC_DisableIRQ(TIM2_IRQn);
  }
  else if(htim_base->Instance==TIM21)
  {
    __HAL_RCC_TIM21_CLK_DISABLE();
    HAL_NVIC_DisableIRQ(TIM21_IRQn);
  }
  else if (htim_base->Instance == TIM22)
  {
      __HAL_RCC_TIM22_CLK_DISABLE();
  }

}

void HAL_ADC_MspInit(ADC_HandleTypeDef* hadc)
{
    GPIO_InitTypeDef GPIO_InitStruct = { 0 };
    if (hadc->Instance == ADC1)
    {
        /* USER CODE BEGIN ADC1_MspInit 0 */

        /* USER CODE END ADC1_MspInit 0 */
          /* Peripheral clock enable */
        __HAL_RCC_ADC1_CLK_ENABLE();

        __HAL_RCC_GPIOA_CLK_ENABLE();
        /**ADC GPIO Configuration
        PA0-CK_IN     ------> ADC_IN0
        PA1     ------> ADC_IN1
        PA4     ------> ADC_IN4
        PA6     ------> ADC_IN6
        PA7     ------> ADC_IN7
        */
        GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_4 | GPIO_PIN_6
            | GPIO_PIN_7;
        GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /* ADC1 DMA Init */
        /* ADC Init */
        hdma_adc.Instance = DMA1_Channel1;
        hdma_adc.Init.Request = DMA_REQUEST_0;
        hdma_adc.Init.Direction = DMA_PERIPH_TO_MEMORY;
        hdma_adc.Init.PeriphInc = DMA_PINC_DISABLE;
        hdma_adc.Init.MemInc = DMA_MINC_ENABLE;
        hdma_adc.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
        hdma_adc.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
        hdma_adc.Init.Mode = DMA_CIRCULAR; //  DMA_NORMAL;
        hdma_adc.Init.Priority = DMA_PRIORITY_LOW;
        if (HAL_DMA_Init(&hdma_adc) != HAL_OK)
        {
            _Error_Handler(__FILE__, __LINE__);
        }

        __HAL_LINKDMA(hadc, DMA_Handle, hdma_adc);

        /* USER CODE BEGIN ADC1_MspInit 1 */

        /* USER CODE END ADC1_MspInit 1 */
    }

}

/**
* @brief ADC MSP De-Initialization
* This function freeze the hardware resources used in this example
* @param hadc: ADC handle pointer
* @retval None
*/
void HAL_ADC_MspDeInit(ADC_HandleTypeDef* hadc)
{
    if (hadc->Instance == ADC1)
    {
        /* USER CODE BEGIN ADC1_MspDeInit 0 */

        /* USER CODE END ADC1_MspDeInit 0 */
          /* Peripheral clock disable */
        __HAL_RCC_ADC1_CLK_DISABLE();

        /**ADC GPIO Configuration
        PA0-CK_IN     ------> ADC_IN0
        PA1     ------> ADC_IN1
        PA4     ------> ADC_IN4
        PA6     ------> ADC_IN6
        PA7     ------> ADC_IN7
        */
        HAL_GPIO_DeInit(GPIOA, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_4 | GPIO_PIN_6
            | GPIO_PIN_7);

        /* ADC1 DMA DeInit */
        HAL_DMA_DeInit(hadc->DMA_Handle);
        /* USER CODE BEGIN ADC1_MspDeInit 1 */

        /* USER CODE END ADC1_MspDeInit 1 */
    }

}

#if 0
void HAL_SPI_MspInit(SPI_HandleTypeDef* hspi)
{
    GPIO_InitTypeDef GPIO_InitStruct = { 0 };
    if (hspi->Instance == SPI1)
    {
        /* USER CODE BEGIN SPI1_MspInit 0 */

        /* USER CODE END SPI1_MspInit 0 */
          /* Peripheral clock enable */
        __HAL_RCC_SPI1_CLK_ENABLE();

        __HAL_RCC_GPIOB_CLK_ENABLE();
        /**SPI1 GPIO Configuration
        PB13     ------> SPI1_SCK
        PB14     ------> SPI1_MISO - if used as full duplex
        PB15     ------> SPI1_MOSI
        */
        GPIO_InitStruct.Pin = GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15; ; // GPIO_PIN_13 | GPIO_PIN_15;
        GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
        GPIO_InitStruct.Alternate = GPIO_AF0_SPI1;
        HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

        /* USER CODE BEGIN SPI1_MspInit 1 */

        /* USER CODE END SPI1_MspInit 1 */
    }

}

/**
* @brief SPI MSP De-Initialization
* This function freeze the hardware resources used in this example
* @param hspi: SPI handle pointer
* @retval None
*/
void HAL_SPI_MspDeInit(SPI_HandleTypeDef* hspi)
{
    if (hspi->Instance == SPI1)
    {
        /* USER CODE BEGIN SPI1_MspDeInit 0 */

        /* USER CODE END SPI1_MspDeInit 0 */
          /* Peripheral clock disable */
        __HAL_RCC_SPI1_CLK_DISABLE();

        /**SPI1 GPIO Configuration
        PB13     ------> SPI1_SCK
        PB15     ------> SPI1_MOSI
        */
        HAL_GPIO_DeInit(GPIOB, GPIO_PIN_13 | GPIO_PIN_15);

        /* USER CODE BEGIN SPI1_MspDeInit 1 */

        /* USER CODE END SPI1_MspDeInit 1 */
    }

}
#endif

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
