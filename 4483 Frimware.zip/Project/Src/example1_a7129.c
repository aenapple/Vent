﻿// http://www.pudn.com/Download/item/id/2463752.html

/*********************************************************************                                                                   **
**  Device:     A7129
**  File:       main.c
**  Target:     Winbond W77LE58
**  Tools:      ICE
**  Updated:    2012-10-30
**  Description:
**  This file is a sample code for your reference.
**
**  Copyright (C) 2011 AMICCOM Corp.
**
*********************************************************************/
#include "define.h"   
#include "w77le58.h"   
#include "a7129reg.h"   
#include "Uti.h"   

/*********************************************************************
**  I/O Declaration
*********************************************************************/
#define SCS         P1_0        //SPI SCS   
#define SCK         P1_1        //SPI SCK   
#define SDIO        P1_2        //SPI SDIO   
#define CKO         P1_3        //CKO   
#define GIO1        P1_4        //GIO1   
#define GIO2        P1_5        //GIO2   

/*********************************************************************
**  Constant Declaration
*********************************************************************/
#define TIMEOUT         50      //50ms   
#define t0hrel          1000    //1ms   

/*********************************************************************
**  Global Variable Declaration
*********************************************************************/
Uint8   data    timer;
Uint8   data    TimeoutFlag;
Uint16  idata   RxCnt;
Uint32  idata   Err_ByteCnt;
Uint32  idata   Err_BitCnt;
Uint16  idata   TimerCnt0;
Uint8   data* Uartptr;
Uint8   data    UartSendCnt;
Uint8   data    CmdBuf[11];
Uint8   idata   tmpbuf[64];

const Uint8 code BitCount_Tab[16] = { 0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4 };
const Uint8 code ID_Tab[8] = { 0x34,0x75,0xC5,0x8C,0xC7,0x33,0x45,0xE7 };   //ID code   
const Uint8 code PN9_Tab[] =
{ 0xFF,0x83,0xDF,0x17,0x32,0x09,0x4E,0xD1,
    0xE7,0xCD,0x8A,0x91,0xC6,0xD5,0xC4,0xC4,
    0x40,0x21,0x18,0x4E,0x55,0x86,0xF4,0xDC,
    0x8A,0x15,0xA7,0xEC,0x92,0xDF,0x93,0x53,
    0x30,0x18,0xCA,0x34,0xBF,0xA2,0xC7,0x59,
    0x67,0x8F,0xBA,0x0D,0x6D,0xD8,0x2D,0x7D,
    0x54,0x0A,0x57,0x97,0x70,0x39,0xD2,0x7A,
    0xEA,0x24,0x33,0x85,0xED,0x9A,0x1D,0xE0
};  // This table are 64bytes PN9 pseudo random code.   

const Uint16 code A7129Config[] =     //470MHz, 10kbps (IFBW = 100KHz, Fdev = 37.5KHz)   
{
    0x1221,     //SYSTEM CLOCK register,   
    0x0A24,     //PLL1 register,   
    0xB805,     //PLL2 register,    470.001MHz   
    0x0000,     //PLL3 register,   
    0x0A20,     //PLL4 register,   
    0x0024,     //PLL5 register,   
    0x0000,     //PLL6 register,   
    0x0001,     //CRYSTAL register,   
    0x0000,     //PAGEA,   
    0x0000,     //PAGEB,   
    0x18D4,     //RX1 register,     IFBW=100KHz, ETH=1     
    0x7009,     //RX2 register,     by preamble   
    0x4400,     //ADC register,        
    0x0800,     //PIN CONTROL register,     Use Strobe CMD   
    0x4845,     //CALIBRATION register,   
    0x20C0      //MODE CONTROL register,    Use FIFO mode   
};

const Uint16 code A7129Config_PageA[] =   //470MHz, 10kbps (IFBW = 100KHz, Fdev = 37.5KHz)   
{
    0x1706,     //TX1 register,     Fdev = 37.5kHz   
    0x0000,     //WOR1 register,   
    0x0000,     //WOR2 register,   
    0x1187,     //RFI register,     Enable Tx Ramp up/down     
    0x8160,     //PM register,      CST=1   
    0x0302,     //RTH register,   
    0x400F,     //AGC1 register,       
    0x0AC0,     //AGC2 register,    
    0x0045,     //GIO register,     GIO2=WTR, GIO1=FSYNC   
    0xD281,     //CKO register   
    0x0004,     //VCB register,   
    0x0825,     //CHG1 register,    480MHz   
    0x0127,     //CHG2 register,    500MHz   
    0x003F,     //FIFO register,    FEP=63+1=64bytes   
    0x1507,     //CODE register,    Preamble=4bytes, ID=4bytes   
    0x0000      //WCAL register,   
};

const Uint16 code A7129Config_PageB[] =   //470MHz, 10kbps (IFBW = 100KHz, Fdev = 37.5KHz)   
{
    0x0B7F,     //TX2 register,     Tx power=13dBm   
    0x8400,     //IF1 register,     Enable Auto-IF, IF=200KHz   
    0x0000,     //IF2 register,   
    0x0000,     //ACK register,   
    0x0000      //ART register,   
};

const Uint16 code Freq_Cal_Tab[] =
{
    0x0A24, 0xB805, //470.001MHz   
    0x0A26, 0x4805, //490.001MHz   
    0x0A27, 0xD805  //510.001MHz   
};

/*********************************************************************
**  function Declaration
*********************************************************************/
void Timer0ISR(void);
void UART0Isr(void);
void InitTimer0(void);
void InitUART0(void);
void InitRF(void);
void A7129_Config(void);
void A7129_WriteID(void);
void A7129_Cal(void);
void StrobeCMD(Uint8);
void ByteSend(Uint8);
Uint8 ByteRead(void);
void A7129_WriteReg(Uint8, Uint16);
Uint16 A7129_ReadReg(Uint8);
void A7129_WritePageA(Uint8, Uint16);
Uint16 A7129_ReadPageA(Uint8);
void A7129_WritePageB(Uint8, Uint16);
Uint16 A7129_ReadPageB(Uint8);
void A7129_WriteFIFO(void);
void RxPacket(void);
void Err_State(void);
void RCOSC_Cal(void);
void WOR_enable_by_preamble(void);
void WOR_enable_by_sync(void);
void WOR_enable_by_carrier(void);
void WOT_enable(void);
void TWOR_enable(void);
void RSSI_measurement(void);
void FIFO_extension_Infinite_TX(void);
void FIFO_extension_Infinite_RX(void);
void Auto_Resend(void);
void Auto_ACK(void);
void entry_deep_sleep_mode(void);
void wake_up_from_deep_sleep_mode(void);

/*********************************************************************
* main loop
*********************************************************************/
void main(void)
{
    //initsw   
    PMR |= 0x01;    //set DME0   

    //initHW   
    P0 = 0xFF;
    P1 = 0xFF;
    P2 = 0xFF;
    P3 = 0xFF;
    P4 = 0x0F;

    InitTimer0();
    InitUART0();
    TR0 = 1;  //Timer0 on   
    EA = 1;   //enable interrupt   

    if ((P4 & 0x04) == 0x04)   //if P4.2=1, master   
    {
        InitRF(); //init RF   

        while (1)
        {
            A7129_WriteFIFO();  //write data to TX FIFO   
            StrobeCMD(CMD_TX);
            Delay10us(1);
            while (GIO2);        //wait transmit completed   
            StrobeCMD(CMD_RX);
            Delay10us(1);

            timer = 0;
            TimeoutFlag = 0;
            while ((GIO2 == 1) && (TimeoutFlag == 0));     //wait receive completed   
            if (TimeoutFlag)
            {
                StrobeCMD(CMD_STBY);
            }
            else
            {
                RxPacket();
                Delay10ms(5);
            }
        }
    }
    else    //if P4.2=0, slave   
    {
        InitRF(); //init RF   

        RxCnt = 0;
        Err_ByteCnt = 0;
        Err_BitCnt = 0;

        while (1)
        {
            StrobeCMD(CMD_RX);
            Delay10us(1);
            while (GIO2);        //wait receive completed   
            RxPacket();

            A7129_WriteFIFO();  //write data to TX FIFO   
            StrobeCMD(CMD_TX);
            Delay10us(1);
            while (GIO2);        //wait transmit completed   

            Delay10ms(4);
        }
    }
}

/************************************************************************
**  Timer0ISR
************************************************************************/
void Timer0ISR(void) interrupt 1
{
    TH0 = (65536 - t0hrel) >> 8;  //Reload Timer0 high byte, low byte   
    TL0 = 65536 - t0hrel;

    timer++;
    if (timer >= TIMEOUT)
    {
        TimeoutFlag = 1;
    }

    TimerCnt0++;
    if (TimerCnt0 == 500)
    {
        TimerCnt0 = 0;
        CmdBuf[0] = 0xF1;

        memcpy(&CmdBuf[1], &RxCnt, 2);
        memcpy(&CmdBuf[3], &Err_ByteCnt, 4);
        memcpy(&CmdBuf[7], &Err_BitCnt, 4);

        UartSendCnt = 11;
        Uartptr = &CmdBuf[0];
        SBUF = CmdBuf[0];
    }
}

/************************************************************************
**  UART0ISR
************************************************************************/
void UART0Isr(void) interrupt 4 using 3
{
    if (TI == 1)
    {
        TI = 0;
        UartSendCnt--;
        if (UartSendCnt != 0)
        {
            Uartptr++;
            SBUF = *Uartptr;
        }
    }
}

/************************************************************************
**  init Timer0
************************************************************************/
void InitTimer0(void)
{
    TR0 = 0;
    TMOD = (TMOD & 0xF0) | 0x01;    //Timer0 mode=1   
    TH0 = (65536 - t0hrel) >> 8;  //setup Timer0 high byte, low byte   
    TL0 = 65536 - t0hrel;
    TF0 = 0;            //Clear any pending Timer0 interrupts   
    ET0 = 1;            //Enable Timer0 interrupt   
}

/************************************************************************
**  Init UART0
************************************************************************/
void InitUART0(void)
{
    TH1 = 0xFD;         //BaudRate 9600;   
    TL1 = 0xFD;
    SCON = 0x40;
    TMOD = (TMOD & 0x0F) | 0x20;
    REN = 1;
    TR1 = 1;
    ES = 1;
}

/*********************************************************************
** Strobe Command
*********************************************************************/
void StrobeCMD(Uint8 cmd)
{
    Uint8 i;

    SCS = 0;
    for (i = 0; i < 8; i++)
    {
        if (cmd & 0x80)
            SDIO = 1;
        else
            SDIO = 0;

        _nop_();
        SCK = 1;
        _nop_();
        SCK = 0;
        cmd <<= 1;
    }
    SCS = 1;
}

/************************************************************************
**  ByteSend
************************************************************************/
void ByteSend(Uint8 src)
{
    Uint8 i;

    for (i = 0; i < 8; i++)
    {
        if (src & 0x80)
            SDIO = 1;
        else
            SDIO = 0;

        _nop_();
        SCK = 1;
        _nop_();
        SCK = 0;
        src <<= 1;
    }
}

/************************************************************************
**  ByteRead
************************************************************************/
Uint8 ByteRead(void)
{
    Uint8 i, tmp;

    //read data code   
    SDIO = 1;     //SDIO pull high   
    for (i = 0; i < 8; i++)
    {
        if (SDIO)
            tmp = (tmp << 1) | 0x01;
        else
            tmp = tmp << 1;

        SCK = 1;
        _nop_();
        SCK = 0;
    }
    return tmp;
}

/************************************************************************
**  A7129_WriteReg
************************************************************************/
void A7129_WriteReg(Uint8 address, Uint16 dataWord)
{
    Uint8 i;

    SCS = 0;
    address |= CMD_Reg_W;
    for (i = 0; i < 8; i++)
    {
        if (address & 0x80)
            SDIO = 1;
        else
            SDIO = 0;

        SCK = 1;
        _nop_();
        SCK = 0;
        address <<= 1;
    }
    _nop_();

    //send data word   
    for (i = 0; i < 16; i++)
    {
        if (dataWord & 0x8000)
            SDIO = 1;
        else
            SDIO = 0;

        SCK = 1;
        _nop_();
        SCK = 0;
        dataWord <<= 1;
    }
    SCS = 1;
}

/************************************************************************
**  A7129_ReadReg
************************************************************************/
Uint16 A7129_ReadReg(Uint8 address)
{
    Uint8 i;
    Uint16 tmp;

    SCS = 0;
    address |= CMD_Reg_R;
    for (i = 0; i < 8; i++)
    {
        if (address & 0x80)
            SDIO = 1;
        else
            SDIO = 0;

        _nop_();
        SCK = 1;
        _nop_();
        SCK = 0;

        address <<= 1;
    }
    _nop_();

    //read data code   
    SDIO = 1;     //SDIO pull high   
    for (i = 0; i < 16; i++)
    {
        if (SDIO)
            tmp = (tmp << 1) | 0x01;
        else
            tmp = tmp << 1;

        SCK = 1;
        _nop_();
        SCK = 0;
    }
    SCS = 1;
    return tmp;
}

/************************************************************************
**  A7129_WritePageA
************************************************************************/
void A7129_WritePageA(Uint8 address, Uint16 dataWord)
{
    Uint16 tmp;

    tmp = address;
    tmp = ((tmp << 12) | A7129Config[CRYSTAL_REG]);
    A7129_WriteReg(CRYSTAL_REG, tmp);
    A7129_WriteReg(PAGEA_REG, dataWord);
}

/************************************************************************
**  A7129_ReadPageA
************************************************************************/
Uint16 A7129_ReadPageA(Uint8 address)
{
    Uint16 tmp;

    tmp = address;
    tmp = ((tmp << 12) | A7129Config[CRYSTAL_REG]);
    A7129_WriteReg(CRYSTAL_REG, tmp);
    tmp = A7129_ReadReg(PAGEA_REG);
    return tmp;
}

/************************************************************************
**  A7129_WritePageB
************************************************************************/
void A7129_WritePageB(Uint8 address, Uint16 dataWord)
{
    Uint16 tmp;

    tmp = address;
    tmp = ((tmp << 7) | A7129Config[CRYSTAL_REG]);
    A7129_WriteReg(CRYSTAL_REG, tmp);
    A7129_WriteReg(PAGEB_REG, dataWord);
}

/************************************************************************
**  A7129_ReadPageB
************************************************************************/
Uint16 A7129_ReadPageB(Uint8 address)
{
    Uint16 tmp;

    tmp = address;
    tmp = ((tmp << 7) | A7129Config[CRYSTAL_REG]);
    A7129_WriteReg(CRYSTAL_REG, tmp);
    tmp = A7129_ReadReg(PAGEB_REG);
    return tmp;
}

/*********************************************************************
** initRF
*********************************************************************/
void InitRF(void)
{
    //initial pin   
    SCS = 1;
    SCK = 0;
    SDIO = 1;
    CKO = 1;
    GIO1 = 1;
    GIO2 = 1;

    StrobeCMD(CMD_RF_RST);  //reset A7129 chip   
    A7129_Config();     //config A7129 chip   
    Delay1ms(1);        //for crystal stabilized   
    A7129_WriteID();        //write ID code   
    A7129_Cal();        //IF and VCO calibration   
}

/*********************************************************************
** A7129_Config
*********************************************************************/
void A7129_Config(void)
{
    Uint8 i;
    Uint16 tmp;

    for (i = 0; i < 8; i++)
        A7129_WriteReg(i, A7129Config[i]);

    for (i = 10; i < 16; i++)
        A7129_WriteReg(i, A7129Config[i]);

    for (i = 0; i < 16; i++)
        A7129_WritePageA(i, A7129Config_PageA[i]);

    for (i = 0; i < 5; i++)
        A7129_WritePageB(i, A7129Config_PageB[i]);

    //for check           
    tmp = A7129_ReadReg(SYSTEMCLOCK_REG);
    if (tmp != A7129Config[SYSTEMCLOCK_REG])
    {
        Err_State();
    }
}

/************************************************************************
**  WriteID
************************************************************************/
void A7129_WriteID(void)
{
    Uint8 i;
    Uint8 d1, d2, d3, d4;

    SCS = 0;
    ByteSend(CMD_ID_W);
    for (i = 0; i < 4; i++)
        ByteSend(ID_Tab[i]);
    SCS = 1;

    SCS = 0;
    ByteSend(CMD_ID_R);
    d1 = ByteRead();
    d2 = ByteRead();
    d3 = ByteRead();
    d4 = ByteRead();
    SCS = 1;

    if ((d1 != ID_Tab[0]) || (d2 != ID_Tab[1]) || (d3 != ID_Tab[2]) || (d4 != ID_Tab[3]))
    {
        Err_State();
    }
}

/*********************************************************************
** A7129_Cal
*********************************************************************/
void A7129_Cal(void)
{
    Uint8 i;
    Uint8 fb, fcd, fbcf;    //IF Filter   
    Uint8 vb, vbcf;      //VCO Current   
    Uint8 vcb, vccf;    //VCO Band   
    Uint16 tmp;

    //IF calibration procedure @STB state   
    A7129_WriteReg(MODE_REG, A7129Config[MODE_REG] | 0x0802);    //IF Filter & VCO Current Calibration   
    do {
        tmp = A7129_ReadReg(MODE_REG);
    } while (tmp & 0x0802);

    //for check(IF Filter)   
    tmp = A7129_ReadReg(CALIBRATION_REG);
    fb = tmp & 0x0F;
    fcd = (tmp >> 11) & 0x1F;
    fbcf = (tmp >> 4) & 0x01;
    if (fbcf)
    {
        Err_State();
    }

    //for check(VCO Current)   
    tmp = A7129_ReadPageA(VCB_PAGEA);
    vcb = tmp & 0x0F;
    vccf = (tmp >> 4) & 0x01;
    if (vccf)
    {
        Err_State();
    }


    //RSSI Calibration procedure @STB state   
    A7129_WriteReg(ADC_REG, 0x4C00);                    //set ADC average=64   
    A7129_WritePageA(WOR2_PAGEA, 0xF800);                   //set RSSC_D=40us and RS_DLY=80us   
    A7129_WritePageA(TX1_PAGEA, A7129Config_PageA[TX1_PAGEA] | 0xE000); //set RC_DLY=1.5ms   
    A7129_WriteReg(MODE_REG, A7129Config[MODE_REG] | 0x1000);           //RSSI Calibration   
    do {
        tmp = A7129_ReadReg(MODE_REG);
    } while (tmp & 0x1000);
    A7129_WriteReg(ADC_REG, A7129Config[ADC_REG]);
    A7129_WritePageA(WOR2_PAGEA, A7129Config_PageA[WOR2_PAGEA]);
    A7129_WritePageA(TX1_PAGEA, A7129Config_PageA[TX1_PAGEA]);


    //VCO calibration procedure @STB state   
    for (i = 0; i < 3; i++)
    {
        A7129_WriteReg(PLL1_REG, Freq_Cal_Tab[i * 2]);
        A7129_WriteReg(PLL2_REG, Freq_Cal_Tab[i * 2 + 1]);
        A7129_WriteReg(MODE_REG, A7129Config[MODE_REG] | 0x0004);   //VCO Band Calibration   
        do {
            tmp = A7129_ReadReg(MODE_REG);
        } while (tmp & 0x0004);

        //for check(VCO Band)   
        tmp = A7129_ReadReg(CALIBRATION_REG);
        vb = (tmp >> 5) & 0x07;
        vbcf = (tmp >> 8) & 0x01;
        if (vbcf)
        {
            Err_State();
        }
    }
}

/*********************************************************************
** A7129_WriteFIFO
*********************************************************************/
void A7129_WriteFIFO(void)
{
    Uint8 i;

    StrobeCMD(CMD_TFR);     //TX FIFO address pointer reset   

    SCS = 0;
    ByteSend(CMD_FIFO_W);   //TX FIFO write command   
    for (i = 0; i < 64; i++)
        ByteSend(PN9_Tab[i]);
    SCS = 1;
}

/*********************************************************************
** RxPacket
*********************************************************************/
void RxPacket(void)
{
    Uint8 i;
    Uint8 recv;
    Uint8 tmp;

    RxCnt++;

    StrobeCMD(CMD_RFR);     //RX FIFO address pointer reset   

    SCS = 0;
    ByteSend(CMD_FIFO_R);   //RX FIFO read command   
    for (i = 0; i < 64; i++)
    {
        tmpbuf[i] = ByteRead();
    }
    SCS = 1;

    for (i = 0; i < 64; i++)
    {
        recv = tmpbuf[i];
        tmp = recv ^ PN9_Tab[i];
        if (tmp != 0)
        {
            Err_ByteCnt++;
            Err_BitCnt += (BitCount_Tab[tmp >> 4] + BitCount_Tab[tmp & 0x0F]);
        }
    }
}

/*********************************************************************
** Err_State
*********************************************************************/
void Err_State(void)
{
    //ERR display   
    //Error Proc...   
    //...   
    while (1);
}

/*********************************************************************
** RC Oscillator Calibration
*********************************************************************/
void RCOSC_Cal(void)
{
    Uint16 tmp;

    A7129_WritePageA(WOR2_PAGEA, A7129Config_PageA[WOR2_PAGEA] | 0x0010);       //enable RC OSC   

    while (1)
    {
        A7129_WritePageA(WCAL_PAGEA, A7129Config_PageA[WCAL_PAGEA] | 0x0001);   //set ENCAL=1 to start RC OSC CAL   
        do {
            tmp = A7129_ReadPageA(WCAL_PAGEA);
        } while (tmp & 0x0001);

        tmp = (A7129_ReadPageA(WCAL_PAGEA) & 0x03FF);       //read NUMLH[8:0]   
        tmp >>= 1;
        if ((tmp > 186) && (tmp < 198))  //NUMLH[8:0]~192   
        {
            break;
        }
    }
}

/*********************************************************************
** WOR_enable_by_preamble
*********************************************************************/
void WOR_enable_by_preamble(void)
{
    StrobeCMD(CMD_STBY);

    A7129_WritePageA(GIO_PAGEA, 0x004D);    //GIO1=PMDO, GIO2=WTR   

    //Real WOR Active Period = (WOR_AC[5:0]+1) x 244us �V X'TAL and Regulator Settling Time   
    //Note : Be aware that X��tal settling time requirement includes initial tolerance,    
    //       temperature drift, aging and crystal loading.   
    A7129_WritePageA(WOR1_PAGEA, 0x8005);   //setup WOR Sleep time and Rx time   

    RCOSC_Cal();        //RC Oscillator Calibration   

    A7129_WritePageA(WOR2_PAGEA, A7129Config_PageA[WOR2_PAGEA] | 0x0030);   //enable RC OSC & WOR by preamble   

    A7129_WriteReg(MODE_REG, A7129Config[MODE_REG] | 0x0200);       //WORE=1 to enable WOR function   

    while (GIO1 == 0);     //Stay in WOR mode until receiving preamble(preamble ok)   

}

/*********************************************************************
** WOR_enable_by_sync
*********************************************************************/
void WOR_enable_by_sync(void)
{
    StrobeCMD(CMD_STBY);

    A7129_WritePageA(GIO_PAGEA, 0x0045);    //GIO1=FSYNC, GIO2=WTR   

    //Real WOR Active Period = (WOR_AC[5:0]+1) x 244us �V X'TAL and Regulator Settling Time   
    //Note : Be aware that X��tal settling time requirement includes initial tolerance,    
    //       temperature drift, aging and crystal loading.   
    A7129_WritePageA(WOR1_PAGEA, 0x8005);   //setup WOR Sleep time and Rx time   

    RCOSC_Cal();        //RC Oscillator Calibration   

    A7129_WritePageA(WOR2_PAGEA, A7129Config_PageA[WOR2_PAGEA] | 0x0010);   //enable RC OSC & WOR by sync   

    A7129_WriteReg(MODE_REG, A7129Config[MODE_REG] | 0x0200);       //WORE=1 to enable WOR function   

    while (GIO1 == 0);     //Stay in WOR mode until receiving ID code(sync ok)   

}

/*********************************************************************
** WOR_enable_by_carrier
*********************************************************************/
void WOR_enable_by_carrier(void)
{
    StrobeCMD(CMD_STBY);

    A7129_WritePageA(GIO_PAGEA, 0x0049);    //GIO1=CD, GIO2=WTR   

    //Real WOR Active Period = (WOR_AC[5:0]+1) x 244us �V X'TAL and Regulator Settling Time   
    //Note : Be aware that X��tal settling time requirement includes initial tolerance,    
    //       temperature drift, aging and crystal loading.   
    A7129_WritePageA(WOR1_PAGEA, 0x8005);   //setup WOR Sleep time and Rx time   

    RCOSC_Cal();        //RC Oscillator Calibration   

    A7129_WritePageA(WOR2_PAGEA, A7129Config_PageA[WOR2_PAGEA] | 0x0410);   //enable RC OSC & WOR by carrier   
    A7129_WriteReg(ADC_REG, A7129Config[ADC_REG] | 0x8096);         //ARSSI=1, RTH=150   
    A7129_WritePageA(RFI_PAGEA, A7129Config_PageA[RFI_PAGEA] | 0x6000); //RSSI Carrier Detect plus In-band Carrier Detect   
    A7129_WritePageB(ACK_PAGEB, A7129Config_PageB[ACK_PAGEB] | 0x0200); //CDRS=[01]   
    A7129_WritePageA(VCB_PAGEA, A7129Config_PageA[VCB_PAGEA] | 0x4000); //CDTM=[01]   

    A7129_WriteReg(MODE_REG, A7129Config[MODE_REG] | 0x0200);       //WORE=1 to enable WOR function   

    while (GIO1 == 0);     //Stay in WOR mode until carrier signal strength is greater than the value set by RTH[7:0](carrier ok)   

}

/*********************************************************************
** WOT_enable
*********************************************************************/
void WOT_enable(void)
{
    StrobeCMD(CMD_STBY);

    A7129_WritePageA(GIO_PAGEA, 0x0045);    //GIO1=FSYNC, GIO2=WTR   

    //Real WOR Active Period = (WOR_AC[5:0]+1) x 244us �V X'TAL and Regulator Settling Time   
    //Note : Be aware that X��tal settling time requirement includes initial tolerance,    
    //       temperature drift, aging and crystal loading.   
    A7129_WritePageA(WOR1_PAGEA, 0x8005);   //setup WOR Sleep time and Rx time   

    RCOSC_Cal();            //RC Oscillator Calibration   

    A7129_WriteFIFO();      //write data to TX FIFO   

    A7129_WriteReg(PIN_REG, A7129Config[PIN_REG] | 0x0400);     //WMODE=1 select WOT function   

    A7129_WriteReg(MODE_REG, A7129Config[MODE_REG] | 0x0200);   //WORE=1 to enable WOR function   

    while (1);

}

/*********************************************************************
** TWOR_enable
*********************************************************************/
void TWOR_enable(void)
{
    StrobeCMD(CMD_STBY);

    A7129_WritePageA(GIO_PAGEA, 0x0051);    //GIO1=TWOR, GIO2=WTR   

    //Real WOR Active Period = (WOR_AC[5:0]+1) x 244us �V X'TAL and Regulator Settling Time   
    //Note : Be aware that X��tal settling time requirement includes initial tolerance,    
    //       temperature drift, aging and crystal loading.   
    A7129_WritePageA(WOR1_PAGEA, 0x8005);   //setup WOR Sleep time and Rx time   

    RCOSC_Cal();            //RC Oscillator Calibration   

    A7129_WritePageA(WOR2_PAGEA, A7129Config_PageA[WOR2_PAGEA] | 0x0014);   //start TWOR by WOR_AC   
    //A7129_WritePageA(WOR2_PAGEA, A7129Config_PageA[WOR2_PAGEA] | 0x001C); //start TWOR by WOR_SL   

    StrobeCMD(CMD_SLEEP);   //entry sleep mode   

    while (1);

}

/*********************************************************************
** RSSI_measurement
*********************************************************************/
void RSSI_measurement(void)
{
    Uint16 tmp;

    StrobeCMD(CMD_STBY);

    A7129_WritePageA(GIO_PAGEA, 0x0045);            //GIO1=FSYNC, GIO2=WTR   

    A7129_WriteReg(ADC_REG, A7129Config[ADC_REG] | 0x8000); //ARSSI=1   

    StrobeCMD(CMD_RX);  //entry RX mode   
    Delay10us(1);

    while (GIO1 == 0)      //Stay in WOR mode until receiving ID code(sync ok)   
    {
        tmp = (A7129_ReadReg(ADC_REG) & 0x00FF);    //read RSSI value(environment RSSI)   
    }
    tmp = (A7129_ReadReg(ADC_REG) & 0x00FF);        //read RSSI value(wanted signal RSSI)   

}

/*********************************************************************
** FIFO_extension_Infinite_TX
*********************************************************************/
void FIFO_extension_Infinite_TX(void)
{
    Uint8 i, n;
    Uint16 j;

    //for Infinite : FEP[13:0]=remainder,  5 < FEP[13:0] < 63   
    A7129_WritePageA(VCB_PAGEA, 0x0004);
    A7129_WritePageA(FIFO_PAGEA, 0x0006);

    A7129_WritePageA(GIO_PAGEA, 0x0075);    //GIO1=FPF, GIO2=WTR   
    A7129_WritePageA(CKO_PAGEA, 0xD283);    //CKO=DCK   

    A7129_WriteReg(PIN_REG, 0x0A00);    //set INFS=1, infinite length   

    n = 0;

    SCS = 0;
    ByteSend(CMD_FIFO_W);               //write 1st TX FIFO 64bytes   
    for (i = 0; i < 64; i++)
    {
        ByteSend(n);
        if (n == 255)
            n = 0;
        else
            n++;
    }
    SCS = 1;

    StrobeCMD(CMD_TX);          //entry TX mode   

    for (j = 0; j < 500; j++)
    {
        while (GIO1 == 0);         //wait FPF go high   
        while (GIO1 == 1);         //wait FPF go low   

        SCS = 0;
        ByteSend(CMD_FIFO_W);   //write TX FIFO 64bytes   
        for (i = 0; i < 64; i++)
        {
            ByteSend(n);
            if (n == 255)
                n = 0;
            else
                n++;
        }
        SCS = 1;
    }

    //remainder : FEP[13:0]=6, FIFO Length=6+1=7   
    while (GIO1 == 0);             //wait last FPF go high   
    while (GIO1 == 1);             //wait last FPF go low   

    SCS = 0;
    ByteSend(CMD_FIFO_W);       //write TX FIFO 7bytes   
    for (i = 0; i < 7; i++)
    {
        ByteSend(n);
        if (n == 255)
            n = 0;
        else
            n++;
    }
    SCS = 1;

    A7129_WriteReg(PIN_REG, 0x0800);    //disable INFS   

    while (GIO2);    //wait transmit completed   
}

/*********************************************************************
** FIFO_extension_Infinite_RX
*********************************************************************/
void FIFO_extension_Infinite_RX(void)
{
    Uint8 i, n;
    Uint8 recv;
    Uint8 tmp;
    Uint16 j;

    //for Infinite : FEP[13:0]=remainder,  5 < FEP[13:0] < 63   
    A7129_WritePageA(VCB_PAGEA, 0x0004);
    A7129_WritePageA(FIFO_PAGEA, 0x0006);

    A7129_WritePageA(GIO_PAGEA, 0x0075);    //GIO1=FPF, GIO2=WTR   
    A7129_WritePageA(CKO_PAGEA, 0xD28B);    //CKO=RCK   

    A7129_WriteReg(PIN_REG, 0x0A00);        //set INFS=1, infinite length   

    Err_ByteCnt = 0;
    Err_BitCnt = 0;
    n = 0;

    StrobeCMD(CMD_RX);          //entry RX mode   

    for (j = 0; j < 501; j++)
    {
        while (GIO1 == 0);         //wait FPF go high   
        while (GIO1 == 1);         //wait FPF go low   

        SCS = 0;
        ByteSend(CMD_FIFO_R);   //read RX FIFO 64bytes   
        for (i = 0; i < 64; i++)
            tmpbuf[i] = ByteRead();
        SCS = 1;

        //for check   
        for (i = 0; i < 64; i++)
        {
            recv = tmpbuf[i];
            tmp = recv ^ n;
            if (tmp != 0)
            {
                Err_ByteCnt++;
                Err_BitCnt += (BitCount_Tab[tmp >> 4] + BitCount_Tab[tmp & 0x0F]);
            }

            if (n == 255)
                n = 0;
            else
                n++;
        }
    }

    A7129_WriteReg(PIN_REG, 0x0800);    //disable INFS   

    while (GIO2);    //wait receive completed   

    //remainder : FEP[13:0]=6, FIFO Length=6+1=7   
    SCS = 0;
    ByteSend(CMD_FIFO_R);       //read RX FIFO 7bytes   
    for (i = 0; i < 7; i++)
        tmpbuf[i] = ByteRead();
    SCS = 1;

    //for check   
    for (i = 0; i < 7; i++)
    {
        recv = tmpbuf[i];
        tmp = recv ^ n;
        if (tmp != 0)
        {
            Err_ByteCnt++;
            Err_BitCnt += (BitCount_Tab[tmp >> 4] + BitCount_Tab[tmp & 0x0F]);
        }

        if (n == 255)
            n = 0;
        else
            n++;
    }
}

/*********************************************************************
** Auto_Resend
*********************************************************************/
void Auto_Resend(void)
{
    StrobeCMD(CMD_STBY);

    A7129_WritePageA(GIO_PAGEA, 0x0071);    //GIO1=VPOAK, GIO2=WTR   
    A7129_WritePageA(CKO_PAGEA, 0xD283);    //CKO=DCK   

    A7129_WritePageB(ACK_PAGEB, 0x003F);    //enable Auto Resend, by event, fixed, ARC=15   
    A7129_WritePageB(ART_PAGEB, 0x001E);    //RND=0, ARD=30   
    //ACK format = Preamble + ID = 8bytes   
    //data rate=10kbps, Transmission Time=(1/10k)*8*8=6.4ms   
    //so set ARD=30, RX time=30*250us=7.75ms   

    while (1)
    {
        A7129_WriteFIFO();
        StrobeCMD(CMD_TX);      //entry TX mode   
        Delay10us(1);
        while (GIO2);            //wait transmit completed   

        //check VPOAK   
        if (GIO1)
        {
            //ACK ok   
        }
        else
        {
            //NO ACK   
        }

        StrobeCMD(CMD_STBY);    //clear VPOAK(GIO1 signal)   

        Delay10ms(1);
    }
}

/*********************************************************************
** Auto_ACK
*********************************************************************/
void Auto_ACK(void)
{
    A7129_WritePageA(GIO_PAGEA, 0x0045);    //GIO1=FSYNC, GIO2=WTR   
    A7129_WritePageA(CKO_PAGEA, 0xD28B);    //CKO=RCK   

    A7129_WritePageB(ACK_PAGEB, 0x0001);    //enable Auto ACK   

    while (1)
    {
        StrobeCMD(CMD_RX);      //entry RX mode   
        Delay10us(1);
        while (GIO2);            //wait receive completed   

        RxPacket();
    }
}

/*********************************************************************
** entry_deep_sleep_mode
*********************************************************************/
void entry_deep_sleep_mode(void)
{
    StrobeCMD(CMD_RF_RST);          //RF reset   

    A7129_WriteReg(PIN_REG, 0x0800);    //SCMDS=1   
    A7129_WritePageA(PM_PAGEA, 0x0170); //QDS=1   
    StrobeCMD(CMD_SLEEP);           //entry sleep mode   
    Delay100us(6);              //for VDD_A shutdown, C load=0.1uF   
    StrobeCMD(CMD_DEEP_SLEEP);      //entry deep sleep mode   
    Delay100us(2);              //for VDD_D shutdown, C load=0.1uF   
}

/*********************************************************************
** wake_up_from_deep_sleep_mode
*********************************************************************/
void wake_up_from_deep_sleep_mode(void)
{
    StrobeCMD(CMD_STBY);    //wake up (any Strobe CMD)   
    Delay100us(3);      //for VDD_D stabilized   
    InitRF();
}