#include "stm32l0xx_hal.h"
#include "debug.h"
#include "intr.h"
#include "vars.h"
#include <string.h>
#include <stdarg.h>
#include <stdio.h>
#include "lib.h"

#pragma region HAL driver vars
extern UART_HandleTypeDef hlpuart1;
extern DMA_HandleTypeDef hdma_lpuart1_rx;
extern DMA_HandleTypeDef hdma_lpuart1_tx;
#pragma endregion

#pragma region variables
#define log(args...) Log(LOG_SEV_ALWAYS, LOG_DBG, args)

unsigned char dbg_Buf[DBG_MAX_MSG_LEN];
unsigned char dbg_Temp[DBG_MAX_DATA_LEN];	// buffer for temporary data, used by DBG_READ_MEM, ...
unsigned char dbg_RxSeqNum;
volatile unsigned int dbg_RxTimer;
volatile unsigned int dbg_OverrunCounter;
unsigned int dbg_RxDataLen;		// set to number of data bytes in received request
volatile unsigned int dbg_TxTimer;
unsigned int dbg_RxChecksumErrCounter;
unsigned int dbg_RxTimeoutCounter;
unsigned int dbg_TxTimeoutCounter;
unsigned int dbg_ProcessingTimeoutCounter;
unsigned int dbg_OtherErrorCounter;
volatile unsigned char dbg_DebuggerConnected;	// set when first valid msg is received from debugger, used to stop logging to console 
volatile unsigned int dbg_DebuggerConnectionTimeoutTimer;			// used to measure time since last request from debugger to detect if debugger is connected
int(*dbg_UserFunction)(int len, char *buf);	// user commands received from debugger will be passed for processing to this function
void(*dbg_SecondaryLogFunction)(int len, char *buf);	// if this is set then logd() will call this function with resolved string. String might not be null terminated. len is length of string.

volatile struct _DBG_Flags DBG_Flags;
unsigned int dbg_fp;			// value of frame pointer calculate from dbg_sp

volatile int LoggingDisabled;					// if set then Log function will do nothing
volatile char LogReleaseTransferedLogs;			// if set then logs read by debugger will be removed from log buffer
volatile unsigned LogLastDebuggerReadIndex;		// index of last log read by debugger
volatile unsigned char LdrCheckAdrDisabled;		// when set then ldrCheckAdr() will always return 0, even if adr is invalid

#define DEBUG_SKIP
struct _LogEntry {
	unsigned len:10;		// length of text in the entry
	unsigned pos:14;		// position in LogTextBuf for first character of entry text
	unsigned sev:3;			// entry severity
	unsigned module:4;		// module index
	unsigned valid:1;		// when true then this entry is valid and LogTextBuf[] contains text for this entry
	unsigned time:32;		// entry time, taken from coutner in high interrupt, 1 count = 1.000 microsec
};

// special values for _LogEntry.time
#define LOG_TIME_LAST_VALID 0xfffffffd
#define LOG_TIME_STORE_SAMPLES_NEW_BATCH 0xfffffffe
#define LOG_TIME_STORE_SAMPLES_CONT 0xffffffff

#undef DEBUG_SKIP

struct _LogEntry LogEntries[LOG_MAX_ENTRIES_COUNT];	// holds all entries
char LogTextBuf[LOG_TEXT_BUF_LEN];					// holds all entries text
char LogText[LOG_MAX_ENTRY_TEXT_LEN + 1];			// buffer for creating last log
volatile unsigned LogIndex;									// used with mask LOG_ENTRY_INDEX_MASK as index to LogEntries[] where next log will be written
volatile unsigned LogTextIndex;								// used with mask LOG_TEXT_BUF_INDEX_MASK as index to LogTextBuf[] where first character of text for next entry wil go
volatile int LogFreeLen = LOG_TEXT_BUF_LEN;					// number of bytes free in LogText[]
volatile int LogCS;											// critical section for log code
//int LogWaitForDebuggerToReadLogs;					// if setm then code will wait inside Log() until there is enough space to write new text. If debuger does not read these the micro will never return from Log()
volatile unsigned LogWaitForSpaceWaitCounter;// how many times this function had to wait
volatile unsigned LogWaitForSpaceTimeouts;	// how many times this function timed out
volatile unsigned LogWaitForSpaceWaitTime;	// total accumulated time waited in ms
volatile char LogWaitForSpaceWaitActive;	// set while waiting
volatile unsigned LogWaitForSpaceTimer;		// timer used to measure timeout duration


const char DeviceName[] = "STM32L0";
#pragma endregion

// define PIC32MAKE to include code for PIC32MAKE software-debugger
// this should be defined in Pic32make config file in compiler options, if it would be defined here then Eclipse debugger would get confused
// #define PIC32MAKE

#pragma region DbgInit()
void DbgInit()
{
	int i;

#ifndef PIC32MAKE
	// if sw debugger code is not present then simulate that breakpoints are set so that debugger does not keep sending breakpoint-set request
	DBG_Flags.BreakpointsSet = 1;
#endif

	// enable receiving of messages
	EnableDebugRx();
}
#pragma endregion

#pragma region DbgRxTx()

//extern volatile unsigned SlowDownFactor;		// factor by which we reduced clock speed

// function perform rx and tx logic processing:
//	- rx timeout and cmd processing timeout checks
//	- rx logic processing
//	- tx timeout processing
//	- sending of debug messages to console if debugger is not connected
//	- log wait timeout
// function is called from periodic timer 1 interrupt
void DbgRxTx()
{
	#pragma region process received data
	unsigned i;
	unsigned int msgLen;
	unsigned char dbg_RxChecksum;
	unsigned int numberOfReceivedChars;
	unsigned source;
	UART_HandleTypeDef *huart = &hlpuart1;
	int asciiMsg;

	if(DBG_Flags.DebugRxEnabled)
	{
		// number of chars recevied for DBG UART
		numberOfReceivedChars = DBG_MAX_MSG_LEN - __HAL_DMA_GET_COUNTER(huart->hdmarx); // huart->hdmarx->Instance->CNDTR;

		source = DBG_REQ_DBG_UART;

		if(numberOfReceivedChars > 0)
		{
			// try to detect if this is ascii message from terminal
			if (!dbg_DebuggerConnected && dbg_Buf[numberOfReceivedChars - 1] == '\r')
			{
				// check if all chars are  chars
				asciiMsg = 1;
				for (i = 0; i < numberOfReceivedChars - 1; ++i)
				{
					if (dbg_Buf[i] < ' ' && !(dbg_Buf[i] == '\t' || dbg_Buf[i] == '\r' || dbg_Buf[i] == '\n'))
					{
						asciiMsg = 0;
						break;
					}
				}
				if (asciiMsg && dbg_UserFunction != NULL)
				{
					// this seems to be ascii request from terminal, call user function
					
					// add terminating zero
					dbg_Buf[numberOfReceivedChars - 1] = '\0';

					// execute user function
					(*dbg_UserFunction)(numberOfReceivedChars - 1, (char *)&dbg_Buf[0]);

					// start receiving
					EnableDebugRx();
				}
			}

			// detect start of new msg
			if( ! DBG_Flags.ReceivingMsg)
			{
				// start timeout counter
				// worst case calculation for 1024+4 bytes long msg and 125 kbit UART (2M with 16 slowdon factor) speed:
				// 1028*10/125000 = 82 ms
				// add 16 ms for USB dongle overhead and 20ms for extra tolerance: total = 82+16+20 = 118ms
				#define DBG_RX_TIMEOUT_MILLISEC 118				// how long to wait to received complete message before timeout, needs to be able to transfer 1k at 115200 with PC/USB overhead

				// is we are in low freq mode we need to decrease the timer value so we are measuring actual real time
				dbg_RxTimer = DBG_RX_TIMEOUT_MILLISEC;
				//dbg_RxTimer = DBG_RX_TIMEOUT_MILLISEC / SlowDownFactor + 1;

				// init receive
				DBG_Flags.ReceivingMsg = 1;
			}

			// decode complete msg length - this is valid only is we received at least 2 chars
			msgLen = (unsigned int)dbg_Buf[0] | (  ((unsigned int)(dbg_Buf[1] & 0xe0))<<3  );
			if(numberOfReceivedChars >= 2 && numberOfReceivedChars >= msgLen)
			{
				// abort rx transfer
				HAL_UART_Abort(huart);

				// if we are here it means we have received complete msg
				// check checksum
				dbg_RxChecksum = 0;
				for(i=0; i<msgLen; ++i)
					dbg_RxChecksum += dbg_Buf[i];

				if(dbg_RxChecksum != 0)
				{
					// invalid checksum, drop msg
					++dbg_RxChecksumErrCounter;
					EnableDebugRx();	// this will re-init receiving
				}

				// verify if this is debuger msg
				else if(((dbg_Buf[1] >> 3) & 0x03) != 2)
				{
					// this is not loader msg, drop
					++dbg_OtherErrorCounter;
					EnableDebugRx();	// this will re-init receiving
				}

				else
				{
					// msg OK
					dbg_DebuggerConnected = 1;
					DBG_Flags.RxMsgSource = source;
					DisableDebugRx();
//					DBG_Flags.ReceivingMsg = 0;
					dbg_RxDataLen = msgLen - 4;

					// store sequence number
					dbg_RxSeqNum = dbg_Buf[1] & 0x07;

					// process this request
					DbgProcessFastCmds();
				}
			}
		}
	}
	#pragma endregion

	#pragma region check for rx timeout, processing timeout and overrun
	// check for rx timeout
	if(DBG_Flags.ReceivingMsg && dbg_RxTimer)
	{
		--dbg_RxTimer;
		if(dbg_RxTimer == 0)
		{
			// timeout just happend
			++dbg_RxTimeoutCounter;
			EnableDebugRx();	// this will re-init receiving
		}
	}

	// check for cmd processing timeout
	// we need to do this to recover when main code enters busy loop and d() is not called anymore so that
	// at least 'g' commands are processed
	if(DBG_Flags.ProcessingCmd && dbg_RxTimer)
	{
		--dbg_RxTimer;
		if(dbg_RxTimer == 0)
		{
			// timeout waiting for d() to finish processing of last cmd just happend
			++dbg_ProcessingTimeoutCounter;
			EnableDebugRx();	// this will re-init receiving
		}
	}

	// clear overrun
	//if(USART_GetFlagStatus(DBG_COM, USART_FLAG_ORE))
	//{
	//	DBG_Flags.ReceivingMsg = 0;
	//	++dbg_OverrunCounter;

	//	// STM32F3: clear overrun flag by writing to ORECF
	//	DBG_COM->ICR = USART_FLAG_ORE; // the same as USART_ClearFlag(USART_FLAG_ORE);
	//}

	if(__HAL_UART_GET_FLAG(huart, UART_FLAG_ORE))
	{
		DBG_Flags.ReceivingMsg = 0;
		++dbg_OverrunCounter;

		__HAL_UART_CLEAR_OREFLAG(huart);
	}

	// stm32h7: clear noise error
	if(__HAL_UART_GET_FLAG(huart, UART_FLAG_NE))
	{
		++dbg_OtherErrorCounter;
		__HAL_UART_CLEAR_NEFLAG(huart);
	}

	// stm32h7: clear frame error flag
	if (__HAL_UART_GET_FLAG(huart, UART_FLAG_FE))
	{
		++dbg_OtherErrorCounter;
		__HAL_UART_CLEAR_FEFLAG(huart);
	}

	// stm32h7: clear parity flag
	if (__HAL_UART_GET_FLAG(huart, UART_FLAG_PE))
	{
		++dbg_OtherErrorCounter;
		__HAL_UART_CLEAR_PEFLAG(huart);
	}

	#pragma endregion

	#pragma region Tx
	if(dbg_TxTimer)
	{
		--dbg_TxTimer;
		if(dbg_TxTimer == 0)
		{
			// Tx timeout, maybe USB got disconnected or something
			++dbg_TxTimeoutCounter;
			EnableDebugRx();
		}
	}
	#pragma endregion

	#pragma region send to console
	#if DBG_DEBUG_TO_CONSOLE
		// we do not want to send messages to console for first 600 milliseconds because
		// even if we are using the debugger, the debugger probably did not connect yet and we would loose those messages
		// so we keep count of time passed from reset and start sending to console only after some time
	if (dbg_DebuggerConnectionTimeoutTimer < DBG_DEBUGGER_CONNECTION_TIMEOUT_MS)
		++dbg_DebuggerConnectionTimeoutTimer;

	if( ! dbg_DebuggerConnected && dbg_DebuggerConnectionTimeoutTimer >= DBG_DEBUGGER_CONNECTION_TIMEOUT_MS)
		DbgSendLogsToConsole();
	#endif
	#pragma endregion

	#pragma region log wait timeout
	if (LogWaitForSpaceTimer) --LogWaitForSpaceTimer;
	if (LogWaitForSpaceWaitActive)
		++LogWaitForSpaceWaitTime;
	#pragma endregion

}
#pragma endregion

#pragma region DisableDebugRx(), EnableDebugRx(), DbgStartTx()

#pragma region DisableDebugRx()
//
// disable receive
//
void DisableDebugRx()
{
	DBG_Flags.DebugRxEnabled = 0;

	// disable DBG UART
	__HAL_DMA_DISABLE(&hdma_lpuart1_rx);
}
#pragma endregion

#pragma region EnableDebugRx()
//
// enable debugger to receive more messages from PC
//
void EnableDebugRx()
{
	int ret;

	// mark previous command as finished
	DBG_Flags.ProcessingCmd = 0;

	// we did not receive begining of new msg yet
	DBG_Flags.ReceivingMsg = 0;

	// enable receiving
	DBG_Flags.DebugRxEnabled = 1;

	// clear overrun flag
	UART_HandleTypeDef *huart = &hlpuart1;
	__HAL_UART_CLEAR_OREFLAG(huart);

	ret = HAL_UART_Receive_DMA(huart, (uint8_t *)dbg_Buf, DBG_MAX_MSG_LEN);
}
#pragma endregion

#pragma region DbgStartTx()
// function initiates uart transmition
// function copies tx seq. number from dbg_RxSeqNum
void DbgStartTx(unsigned int txLen, unsigned char respCode)
{
	unsigned char chk;
	unsigned int i;
	unsigned int dbg_TxLen;
	unsigned packetLen;
	int ret;

	// prepare msg
	// first byte is low 8 bits of length
	dbg_TxLen = txLen;
	dbg_Buf[0] = dbg_TxLen;

	// second byte is: lllttsss
	// lll - 3 msb bits of msg len, tt-msg type (2-debug msg, 3-loader msg), sss-seq number
	dbg_Buf[1] = ((dbg_TxLen >> 3) & 0xe0) | ((unsigned short)2 << 3) | (dbg_RxSeqNum & 0x07);

	// third byte is response code
	dbg_Buf[2] = respCode;

	// calculate checksum and put it after data
	chk = 0;
	for(i=0; i < dbg_TxLen - 1; ++i)
		chk += dbg_Buf[i];

	chk = -chk;
	dbg_Buf[dbg_TxLen - 1] = chk;

	// send on DBG UART
	// wait until Tx hardware buffers are completely empty (at this point the previous msg should have been completely gone)
	//while( ! USART_GetFlagStatus(DBG_COM, USART_FLAG_TC));
	while( ! __HAL_UART_GET_FLAG(&hlpuart1,UART_FLAG_TC));

	HAL_UART_Abort(&hlpuart1);
	ret = HAL_UART_Transmit_DMA(&hlpuart1, dbg_Buf, dbg_TxLen);

	// mark Tx in progress
	DBG_Flags.TxActiveSource = DBG_Flags.RxMsgSource;

	// start Tx timeout timer - need enough time to transmit 1K of data at 115kbps
	dbg_TxTimer = DBG_TX_TIMEOUT_MS;
}
#pragma endregion

#pragma endregion

#pragma region DetectDebugerRequest
//
// functino returns true if it finds valid DBG_DM_CMD_GET_LAST_ADR request in specified location
//
int DetectDebugerRequest(char *buf, int rxLen)
{
	unsigned char checksum;
	if(rxLen >= 4 && buf[0] == 4 && (buf[1] & ~0x7) == (0x2<<3) && buf[2] == DBG_DM_CMD_GET_LAST_ADR)
	{
		// verify checksum
		checksum = buf[0]+buf[1]+buf[2]+buf[3];
		if(checksum == 0)
			return 1;
	}

	return 0;
}
#pragma endregion

#pragma region DbgReset()
// reset microcntroller
void DbgReset()
{
	HAL_NVIC_SystemReset();
	while(1);
}
#pragma endregion

#pragma region log functions
//
// function returns true if log buffer is empty and all logs were sent to debugger
//
int LogIsBufEmpty()
{
	return LogFreeLen < LOG_TEXT_BUF_LEN ? 0 : 1;
}

//
// function waits until there is at least 25% empty space in log buffer,
// function must not be called form interrupt as it would block debuger and debuger code would never run and micro would get stuck here forever !
//
void LogWaitForSpace()
{
	LogWaitForSpaceSize(LOG_TEXT_BUF_LEN * 1 / 4, 1000);
}

//
// function waits until specified number of bytes is available in buffer and there are available slots
// if specified number of bytes becomes available within specified time function returns 0
// if specified number of bytes does not get released in specified time, function force-clears specified len and returns 1
//
int LogWaitForSpaceSize(int len, int timeoutMs)
{
	unsigned j;
	unsigned i;

	// add some extra space
	len += 256;

	if (LogFreeLen < len)
	{
		;
	}
	else if (LogIndex >= LogLastDebuggerReadIndex + LOG_MAX_ENTRIES_COUNT - 1)
	{
		;
	}
	else
		return 0;

	// if debugger is not active, then logs transfered out on UART should already clear the space they used after transfering
	// if debugger is active, then logs are still in buffer, we will now clear all those that were transfered already
	if (dbg_DebuggerConnected)
	{
		// release all old logs up to the last transfered one
		// start with oldest log
		j = LogIndex & LOG_ENTRY_INDEX_MASK;	// oldest log
		unsigned lastTransferedPlusOne = LogLastDebuggerReadIndex & LOG_ENTRY_INDEX_MASK;
		do
		{
			if (LogEntries[j].valid)
			{
				LogFreeLen += LogEntries[j].len;
				LogEntries[j].valid = 0;
			}
			j = (j + 1) & LOG_ENTRY_INDEX_MASK;
		} while (j != lastTransferedPlusOne);
	}

	if (LogFreeLen >= len && !(LogIndex >= LogLastDebuggerReadIndex + LOG_MAX_ENTRIES_COUNT - 1))
	{
		return 0;
	}

	// we need to wait

	++LogWaitForSpaceWaitCounter;
	LogWaitForSpaceWaitActive = 1;

	// ask debugger to release logs
	LogReleaseTransferedLogs = 1;

	// wait until we have space or timeout
	LogWaitForSpaceTimer = timeoutMs;
	while (1)
	{
		if (LogFreeLen >= len && !(LogIndex >= LogLastDebuggerReadIndex + LOG_MAX_ENTRIES_COUNT - 1))
		{
			// space became available
			LogReleaseTransferedLogs = 0;
			LogWaitForSpaceWaitActive = 0;
			return 0;
		}

		if (LogWaitForSpaceTimer == 0)
		{
			// timeout

			// force release all logs
			// release all old logs up to the last transfered one
			// start with oldest log
			j = LogIndex & LOG_ENTRY_INDEX_MASK;	// oldest log
			for(i=0; i<LOG_MAX_ENTRIES_COUNT; ++i)
			{
				if (LogEntries[j].valid)
				{
					LogFreeLen += LogEntries[j].len;
					LogEntries[j].valid = 0;
				}
				j = (j + 1) & LOG_ENTRY_INDEX_MASK;
			}

			++LogWaitForSpaceTimeouts;
			LogReleaseTransferedLogs = 0;
			LogWaitForSpaceWaitActive = 0;
			return 1;
		}

	}
}

// function copies maximum maxLen chars to specified buffer of specified log entry text
// age: 0-last entry, 1-second last, ...
// function does not write '\0' at the end
// if specified etry does not exist or is invalid function copies "..."
void GetLogText(int age, char *p, int maxLen)
{
	int i;		// index of desired entry in LogEntries[]
	int len;	// how many chars to copy
	int pos;	// position in LogTextBuf[] for processed chracter
	
	if((unsigned)age >= LogIndex)
		goto Invalid;

	// get index of entry
	i = (LogIndex - (unsigned)age - 1) & LOG_ENTRY_INDEX_MASK;
	if( ! LogEntries[i].valid)
		goto Invalid;

	// get number of chars to copy
	len = MIN(LogEntries[i].len, maxLen);

	// copy text
	pos = LogEntries[i].pos;
	while(len--)
	{
		*p++ = LogTextBuf[pos & LOG_TEXT_BUF_INDEX_MASK];
		++pos;
	}
	
	return;

Invalid:
	memcpy(p, "???", 3);
}

// function adds log to buffer
void Log(int severity, int module, char *format, ...)
{
	int i;
	char *p;
	struct _LogEntry *pe;
	int j;
	unsigned tim2hi1;
	unsigned tim2lo1;
	unsigned tim2hi2;
	unsigned tim2lo2;
	unsigned tim2cnt;

	va_list ap;
    va_start(ap, format);

	if(LoggingDisabled)
		return;

	// write to buf first
	int n;
	n = vsnprintf2(LogText, LOG_MAX_ENTRY_TEXT_LEN + 1, format, ap);
	if(n > LOG_MAX_ENTRY_TEXT_LEN) n = LOG_MAX_ENTRY_TEXT_LEN;
	// now n contains number of characters we want to store for this entry
	
	if(n == 0)
		return;	// do not write empty entries

	// call secondary log function
	if (dbg_SecondaryLogFunction != NULL && (module == LOG_OPEN_NEW_DATA_FILE || module == LOG_ADD_TO_DATA_FILE))
	{
		(*dbg_SecondaryLogFunction)(n, LogText);
	}

	// enter critical section
	LogCS = 1;

	//// not enough space, check if we shoudl wait for debuger to read logs
	//if(n > LogFreeLen && LogWaitForDebuggerToReadLogs)
	//{
	//	while(n > LogFreeLen);
	//}

	// now we need to create enough space in LogTextBuf[] for this text
	if(n > LogFreeLen)
	{
		// not enough space, keep deleting old entries until we have enough space
		// first skip all entries that are not valid
		j = LOG_MAX_ENTRIES_COUNT;	// this is used as a safety counter, so that we do not get stuck in loop forever if something is not right
		i = ((unsigned)LogIndex) & LOG_ENTRY_INDEX_MASK;
		while( ! LogEntries[i].valid && j>=0)
		{
			i = (i+1) & LOG_ENTRY_INDEX_MASK;
			--j;
		}

		// now start deleting old entries
		j = LOG_MAX_ENTRIES_COUNT;	// this is used as a safety counter, so that we do not get stuck in loop forever if something is not right
		while(j >= 0)
		{
			LogFreeLen += LogEntries[i].len;
			LogEntries[i].valid = 0;
			if(n <= LogFreeLen)
				break;

			i = (i+1) & LOG_ENTRY_INDEX_MASK;
			--j;
		}
	}

	// we have enough space now
	// create entry
	pe = LogEntries + (((unsigned)LogIndex) & LOG_ENTRY_INDEX_MASK);
	pe->pos = LogTextIndex;
	pe->len = n;
	pe->module = module;
	pe->sev = severity;
	pe->valid = 1;

	// Get timer low and high counts and compose one 32 bit long count value. High is from TIM overflow interrupt. We need to make sure that timer did not eoverflow while we are fetching counter values
	while(1)
	{
		tim2lo1 = TIM2->CNT;
		tim2hi1 = Tim2HighCnt;
		tim2lo2 = TIM2->CNT;
		tim2hi2 = Tim2HighCnt;
		if (tim2lo2 >= tim2lo1 && tim2hi1 == tim2hi2)
			break;
	}
	tim2cnt = (tim2hi2 << 16) | tim2lo2;
	pe->time = tim2cnt;

	// decrement freen space by number of chars that this log will take
	LogFreeLen -= n;
	
	// store text
	p = LogText;
	while(n--)
	{
		LogTextBuf[LogTextIndex] = *p++;
		LogTextIndex = (LogTextIndex + 1) & LOG_TEXT_BUF_INDEX_MASK;
	}
	++LogIndex;

	// leave critical section
	LogCS = 0;
}
#pragma endregion

#pragma region DbgProcessFastCmds()

// function is called by rx interrupt code when complete msg is received
// function processes some debugger commands
void DbgProcessFastCmds()
{
	//unsigned char *pd, *ps;
	unsigned i;

	switch(dbg_Buf[2])
	{
	case DBG_CLEAR_RESET_FLAG:
		// clear reset flag
		DBG_Flags.ResetAcknowledged = 1;
		DbgStartTx(4, DBG_RESP_OK);
		break;

	case DBG_CMD_PING:
		// ping request
		// send back positive response with flag boot/main-app

		#if THIS_IS_BOOT_CODE
			dbg_Buf[3] = 0;	// boot code
		#else
			dbg_Buf[3] = 1;	// main app code
		#endif

		DbgStartTx(5, DBG_RESP_OK);
		break;

	case DBG_CMD_RESET:
		// reset

		DbgReset();
		break;

#ifndef PIC32MAKE
		// debugging commands if pic32make is not enabled

	case DBG_DM_CMD_GET_LAST_ADR:
		// respond with last executed code address stored by 1 ms periodic interrupt
		// if Pic32make is enabled then this is handled by debug monitor interrupt code

		// send response to PC
		memcpy( & dbg_Buf[3], (void *) &dm_pc1, 4);

		// add flags to state, then send it to debugger
		i = dm_State | ((*((unsigned int *) &DBG_Flags) & 0xff000000u));
		memcpy( & dbg_Buf[7], (void *) &i, 4);

		memcpy( & dbg_Buf[11], (void *) &LogIndex, 4);
		DbgStartTx(4 + 12, DBG_RESP_OK);

		break;

	
	case DBG_SET_BREAKPOINTS:
		// just respond with ok to make debugger happy
		DbgStartTx(4, DBG_RESP_OK);
		break;

#endif //PIC32MAKE

	default:
		// if code is compiled for Pic32Make debugger then trigger debug monitor exception to process the command
		// if code is not compiled for Pic32Make then execute command directly
#ifdef PIC32MAKE
		// trigger debug monitor to execute requested cmd
		dm_UartCmd = dbg_Buf[2];
		dm_UartRequest = 1;
		
		dbg_RxTimer = DBG_CMD_PROCESSING_TIMEOUT_MILLISEC;
		DBG_Flags.ProcessingCmd = 1;
		
		TriggerDebugMonitor();
#else

		DbgExecuteCmd();

#endif	//PIC32MAKE

		break;
	}
}
#pragma endregion

#pragma region DbgExecuteCmd()
// function executes debugger cmd that is ready in dbg_Buf and sends response to debugger
void DbgExecuteCmd()
{
	unsigned temp = 0;
	unsigned temp2 = 0;
	unsigned value, adr, len;
	unsigned i,j;
	unsigned char *ps,*ps2,*pd;
	unsigned txLen;
	unsigned oldestPossible;
	unsigned requestedIndex;
	unsigned returnedIndex;
	unsigned availableLen;
	unsigned logsCount;
	unsigned lenOfText;
	unsigned lastTransferedPlusOne;
	unsigned foundValidLog;
	unsigned char chunkLen;
	unsigned chunkCount;

	// process debugger commands
	switch(dbg_Buf[2])
	{
	#pragma region DBG_TOGGLE_BIT
	case DBG_TOGGLE_BIT:
		// toggle specified bit
		// [3-6]:   address of the byte
		// [7]:		mask to toggle - this is be xored with value pn specified adr

		// check param len
		if(dbg_RxDataLen != 5)
		{
			DbgStartTx(4, DBG_RESP_INVALID_PARAM_LEN);
			break;
		}

		// get adr
		ps2 = & dbg_Buf[3];
		pd = (unsigned char *) ((unsigned)*ps2++);
		pd += ((unsigned) *ps2++) << 8;
		pd += ((unsigned) *ps2++) << 16;
		pd += ((unsigned) *ps2++) << 24;

		// check adr
		if(ldrCheckAdr(LDR_CA_RAM_OR_PERIPH, (unsigned int) pd, 4))
		{
			DbgStartTx(4, DBG_RESP_INVALID_ADR);
			goto DbgWriteByMaskEnd;
		}

		// toggle specified bit
		*pd ^= dbg_Buf[7];

		// send positive response
		DbgStartTx(4, DBG_RESP_OK);
		break;
		#pragma endregion

	#pragma region DBG_WRITE_BY_MASK
	case DBG_WRITE_BY_MASK:
		// write specified bits in 4 byte words
		// [3-6]:   address of first word - must be on 4 byte boundary
		// [7-10]:  mask for first word that will be and-ed with value in memory
		// [11-14]: value for first word that will be or-ed wit hvalue in memory
		// [15-..]: more masks and values can follow

		// check param len
		if(dbg_RxDataLen < 12 || ((dbg_RxDataLen - 4) % 8) != 0)
		{
			DbgStartTx(4, DBG_RESP_INVALID_PARAM_LEN);
			break;
		}

		// get adr
		ps2 = & dbg_Buf[3];
		pd = (unsigned char *) ((unsigned)*ps2++);
		pd += ((unsigned) *ps2++) << 8;
		pd += ((unsigned) *ps2++) << 16;
		pd += ((unsigned) *ps2++) << 24;

		i = dbg_RxDataLen - 4;
		while(i)
		{
			// check adr
			if(ldrCheckAdr(LDR_CA_RAM_OR_PERIPH, (unsigned int) pd, 4))
			{
				DbgStartTx(4, DBG_RESP_INVALID_ADR);
				goto DbgWriteByMaskEnd;
			}

			// get mask
			temp = (unsigned) *ps2++;
			temp += ((unsigned) *ps2++) << 8;
			temp += ((unsigned) *ps2++) << 16;
			temp += ((unsigned) *ps2++) << 24;

			// get value
			value = (unsigned) *ps2++;
			value += ((unsigned) *ps2++) << 8;
			value += ((unsigned) *ps2++) << 16;
			value += ((unsigned) *ps2++) << 24;

			// write value by mask
			//*pd &= temp;
			//*pd |= value;
			*((unsigned *)pd) = (*((unsigned *)pd) & temp) | value;

			pd += 4;
			i -= 8;
		}

		// send positive response
		DbgStartTx(4, DBG_RESP_OK);

DbgWriteByMaskEnd:
		break;
		#pragma endregion

	#pragma region DBG_SET_MEM
	case DBG_SET_MEM:
		// set memory in chunk of specified length, chunk length can be 1,2,4 or 8 bytes
		// [3-6]: address where to start writing
		// [7]: chunk length
		// [8-11]: number of chunks
		// [12-...]: chunk data

		// get adr and len
		ps2 = & dbg_Buf[3];
		pd = (unsigned char *) ((unsigned)*ps2++);
		pd += ((unsigned) *ps2++) << 8;
		pd += ((unsigned) *ps2++) << 16;
		pd += ((unsigned) *ps2++) << 24;
		chunkLen = *ps2++;
		chunkCount = ((unsigned)*ps2++);
		chunkCount += ((unsigned)*ps2++) << 8;
		chunkCount += ((unsigned)*ps2++) << 16;
		chunkCount += ((unsigned)*ps2++) << 24;

		// check param length
		if((unsigned)chunkLen + 9u != dbg_RxDataLen)
		{
			DbgStartTx(4, DBG_RESP_INVALID_PARAM_LEN);
			break;
		}

		// check address
		if(ldrCheckAdr(LDR_CA_RAM_OR_PERIPH, (unsigned int) pd, ((unsigned)chunkLen) * chunkCount))
		{
			DbgStartTx(4, DBG_RESP_INVALID_ADR);
			break;
		}

		// write chunks
		ps = & dbg_Buf[12];
		for (i = 0; i < chunkCount; ++i)
		{
			memcpy(pd, ps, chunkLen);
			pd += chunkLen;
		}

		// send positive response
		DbgStartTx(4, DBG_RESP_OK);
		break;
		#pragma endregion

	#pragma region DBG_WRITE_MEM
	case DBG_WRITE_MEM:
		// write specified bytes to memory, can write ram and periph memory
		// [3-6]: address of first block
		// [7-8]: length of the first block
		//		  if bit 14 in length is set this means that read adr is signed offset from current sp value and read should be referenced to sp (this is used for local vars on stack)
		//		  if bit 15 in length is set this means that read should be indirect (adr is adress of pointer and not adr of value)
		// [9-...]: data to write

		// get adr and len
		ps2 = & dbg_Buf[3];
		pd = (unsigned char *) ((unsigned)*ps2++);
		pd += ((unsigned) *ps2++) << 8;
		pd += ((unsigned) *ps2++) << 16;
		pd += ((unsigned) *ps2++) << 24;
		i = (unsigned short) *ps2++;
		i += ((unsigned short) *ps2++) << 8;

#define INDIRECT_FLAG 0x8000
#define SP_RELATIVE_FLAG 0x4000

		// decode if this is sp relative read
		if(i & SP_RELATIVE_FLAG)
		{
			i &= ~SP_RELATIVE_FLAG;
			
			pd = (unsigned char *) (dbg_fp + (int) pd);
		}

		// decode if this is indirect read
		if(i & INDIRECT_FLAG)
		{
			i &= ~INDIRECT_FLAG;

			// check if adr is word aligned (this is adr of pointer)
			if(((int)pd & 0x03) != 0)
			{
				DbgStartTx(4, DBG_RESP_ADR_NOT_ALIGNED);
				break;
			}

			// check if pointer adr is valid
			if(ldrCheckAdr(LDR_CA_ANY, (unsigned int) pd, 4))
			{
				DbgStartTx(4, DBG_RESP_INVALID_ADR);
				break;
			}

			// get adr of value to read from pointer
			pd = *( (unsigned char **) pd);
		}

		// check param length
		if(i + 6 != dbg_RxDataLen)
		{
			DbgStartTx(4, DBG_RESP_INVALID_PARAM_LEN);
			break;
		}

		// check address
		if(ldrCheckAdr(LDR_CA_RAM_OR_PERIPH, (unsigned int) pd, i))
		{
			DbgStartTx(4, DBG_RESP_INVALID_ADR);
			break;
		}

		// write block
		ps = & dbg_Buf[9];
		// try to write as aligned words or half words - this is to make sure that writes to peripheral registers will work
		while(i)
		{
			if(i >= 4 && ((int)pd & 0x3)==0)
			{
				// aligned int write
				memcpy(&temp2, ps, 4);
				*((unsigned int*)pd) = temp2;
				ps += 4;
				pd += 4;
				i -= 4;
			}
			else if(i >= 2 && ((int)pd & 0x1) == 0)
			{
				// aligned short write
				memcpy(&temp2, ps, 2);
				*((unsigned short*)pd) = (unsigned short)temp2;
				ps += 2;
				pd += 2;
				i -= 2;
			}
			else
			{
				*pd++ = *ps++;
				--i;
			}
		}


		// send positive response
		DbgStartTx(4, DBG_RESP_OK);
		break;
		#pragma endregion

	#pragma region DBG_READ_MEM
	case DBG_READ_MEM:
		// read one or more memory blocks, this can read periph, ram, code, boot or configfuses
		// [3-6]: address of first block
		// [7-8]: length of the first block
		//		  if bit 15 in length is set this means that read should be indirect (adr is adress of pointer and not adr of value)
		//		  if bit 14 in length is set this means that read adr is signed offset from current sp value and read should be referenced to sp (this is used for local vars on stack)
		// [9-12]: address of second block (optional)
		// [13-14]: length of second block (optional)

		// first copy request data to temp buffer so that we can start overwriting dbg buf
		i = dbg_RxDataLen;
		pd = dbg_Temp;
		ps = &dbg_Buf[3];
		while(i--) *pd++ = *ps++;

		// get data for all blocks
		pd = & dbg_Buf[3];	// points where read data will go in dbg_Buf
		ps2 = dbg_Temp;		// points to block data from request
		txLen = 4;

		while(dbg_RxDataLen >= 6)
		{
			// get block adr and len
			ps = (unsigned char *) ((unsigned)*ps2++);
			ps += ((unsigned) *ps2++) << 8;
			ps += ((unsigned) *ps2++) << 16;
			ps += ((unsigned) *ps2++) << 24;
			i = (unsigned short) *ps2++;
			i += ((unsigned short) *ps2++) << 8;

			// decode if this is sp relative read
			if(i & SP_RELATIVE_FLAG)
			{
				i &= ~SP_RELATIVE_FLAG;
				
				ps = (unsigned char *) (dbg_fp + (int) ps);
			}

			// decode if this is indirect read
			#pragma region indirect
			if(i & INDIRECT_FLAG)
			{
				i &= ~INDIRECT_FLAG;

				// check if adr is word aligned (this is adr of pointer)
				if(((int)ps & 0x03) != 0)
				{
					DbgStartTx(4, DBG_RESP_ADR_NOT_ALIGNED);
					goto DbgReadMemEnd;
				}

				// check if pointer adr is valid
				if(ldrCheckAdr(LDR_CA_ANY, (unsigned int) ps, 4))
				{
					// send back invalid calculated adr, adr requested, length, dbg_fp
					memcpy(&dbg_Buf[3], &ps, 4);
					memcpy(&dbg_Buf[3 + 4], ps2 - 6, 6);
					memcpy(&dbg_Buf[3 + 10], &dbg_fp, 4);

					DbgStartTx(4 + 14, DBG_RESP_INVALID_ADR);
					goto DbgReadMemEnd;
				}

				// get adr of value to read from pointer
				ps = *( (unsigned char **) ps);

				// check if block adr is valid
				// if it is not valid - which happens quite often if poitner is not initialized yet
				// return dummy values instead of value
				if(ldrCheckAdr(LDR_CA_ANY, (unsigned int) ps, i))
				{
					// check if requested data fits to buffer
					if(txLen + i > DBG_MAX_MSG_LEN)
					{
						DbgStartTx(4, DBG_RESP_INVALID_PAR_VALUE);
						goto DbgReadMemEnd;
					}
					txLen += i;
		 
					// get block data
					#define DUMMY_VALUE_FOR_INVALID_POINTER_POSITION 0x77
					while(i--) *pd++ = DUMMY_VALUE_FOR_INVALID_POINTER_POSITION;
		 
					// move to next block
					dbg_RxDataLen -= 6;

					continue;
				}
			}
			#pragma endregion

			// check if block adr is valid
			if(ldrCheckAdr(LDR_CA_ANY, (unsigned int) ps, i))
			{
				// send back invalid calculated adr, adr requested, length, dbg_fp
				memcpy(&dbg_Buf[3], &ps, 4);
				memcpy(&dbg_Buf[3 + 4], ps2 - 6, 6);
				memcpy(&dbg_Buf[3 + 10], &dbg_fp, 4);

				DbgStartTx(4 + 14, DBG_RESP_INVALID_ADR);
				goto DbgReadMemEnd;
			}
 
			// check if requested data fits to buffer
			if(txLen + i > DBG_MAX_MSG_LEN)
			{
				DbgStartTx(4, DBG_RESP_INVALID_PAR_VALUE);
				goto DbgReadMemEnd;
			}
			txLen += i;
 
			// get block data
			// if this is read from aligned adr then use int pointers instead of byte transfer,
			// this is required for reading of peripheral vars - reading them as unaligned byte read will crash micro
			while(i)
			{
				if(i >= 4 && ((int)ps & 0x3)==0)
				{
					// aligned int read
					temp2 = *((unsigned int*)ps);
					ps+=4;

					*pd++ = ((unsigned char *)&temp2)[0];
					*pd++ = ((unsigned char *)&temp2)[1];
					*pd++ = ((unsigned char *)&temp2)[2];
					*pd++ = ((unsigned char *)&temp2)[3];

					i -= 4;
				}
				else if(i >= 2 && ((int)ps & 0x1) == 0)
				{
					// aligned short read
					temp2 = *((unsigned short*)ps);
					ps+=2;

					*pd++ = ((unsigned char *)&temp2)[0];
					*pd++ = ((unsigned char *)&temp2)[1];

					i -= 2;
				}
				else
				{
					*pd++ = *ps++;
					--i;
				}
			}
 
			// move to next block
			dbg_RxDataLen -= 6;
		}

		DbgStartTx(txLen, DBG_RESP_OK);

DbgReadMemEnd:
		break;
		#pragma endregion

	#pragma region DBG_READ_LOGS
	case DBG_READ_LOGS:
		// read log statements from buffer
		// request:
		// [3-6]: index of first log to read
		//
		// positive response:
		// [3-6]: index of last log in buffer + 1 (this will return 0 if there are no logs at all)
		// [7-10]: index of first log returned to debugger (this might be diferent as index of requsted if that one is not valid anymore)
		// [11-14]: number of logs returned
		// [15-...]: log entry for first returned log, log entry for second returned log, .. (each log entry is 8 bytes long)
		// [...-...]: text for fist log, text for second log, ...
		//
		// negative response DBG_RESP_LOG_DOES_NOT_EXIST
		// [3-6]: index of last log in buffer + 1 (this will return 0 if there are no logs at all)

		// get index of requested log
		memcpy(&requestedIndex, &dbg_Buf[3], 4);

		// check if we have log like this
		if(requestedIndex >= LogIndex)
		{
			// requested log was not created yet
			// case 1: micro has no new logs since debugger read them
			// case 2: (probably micro rebooted and debugger did not notice yet)
			// return index of last log
			memcpy(& dbg_Buf[3], (void *) &LogIndex, 4);
			DbgStartTx(4 + 4, DBG_RESP_LOG_DOES_NOT_EXIST);
			break;
		}

		// find first valid log - we start with oldest possible log (on position LogIndex - LOG_MAX_ENTRIES_COUNT)
		// and find first one that is valid
		oldestPossible = LogIndex > LOG_MAX_ENTRIES_COUNT ? (LogIndex - LOG_MAX_ENTRIES_COUNT) : 0;
		foundValidLog = 0;
		i = LOG_MAX_ENTRIES_COUNT;
		while(i--)
		{
			if(LogEntries[oldestPossible & LOG_ENTRY_INDEX_MASK].valid)
			{
				foundValidLog = 1;
				break;
			}

			++oldestPossible;
		}
		if(!foundValidLog)
		{
			// no valid logs
			// return index of last log
			memcpy(& dbg_Buf[3], (void *) &LogIndex, 4);
			DbgStartTx(4 + 4, DBG_RESP_NO_LOGS);
			break;
		}

		// get index of first log entry that we will return
		returnedIndex = oldestPossible > requestedIndex ? oldestPossible : requestedIndex;

		// calculate how many logs will fit to buffer
		availableLen = DBG_MAX_DATA_LEN - 3*4;
		logsCount = 0;
		lenOfText = 0;
		i = returnedIndex;
		while(i < LogIndex)
		{
			j = i & LOG_ENTRY_INDEX_MASK;
			if( ! LogEntries[j].valid || availableLen < (8u + LogEntries[j].len))
				break;

			availableLen -= (8 + LogEntries[j].len);
			++logsCount;
			lenOfText += LogEntries[j].len;
			++i;
		}

		// prepare header
		memcpy(& dbg_Buf[3], (void *) &LogIndex, 4);
		memcpy(& dbg_Buf[7], &returnedIndex, 4);
		memcpy(& dbg_Buf[11], &logsCount, 4);

		// copy log entries
		pd = & dbg_Buf[15];
		j = returnedIndex & LOG_ENTRY_INDEX_MASK;
		for(i=0; i<logsCount; ++i)
		{
			memcpy(pd, &LogEntries[j], 8);	// this will copy one log entry
			j = (j + 1) & LOG_ENTRY_INDEX_MASK;
			pd += 8;
		}

		// copy text for all returned logs
		j = LogEntries[returnedIndex & LOG_ENTRY_INDEX_MASK].pos;
		for(i=0; i<lenOfText; ++i, ++j)
			*pd++ = LogTextBuf[j & LOG_TEXT_BUF_INDEX_MASK];

		// store index of last read log
		LogLastDebuggerReadIndex = returnedIndex + logsCount - 1;

		if(LogReleaseTransferedLogs)
		{
			// release all old logs up to the last transfered one
			// start with oldest log
			j = LogIndex & LOG_ENTRY_INDEX_MASK;
			lastTransferedPlusOne = (returnedIndex + logsCount) & LOG_ENTRY_INDEX_MASK;
			do
			{
				if(LogEntries[j].valid)
				{
					LogFreeLen += LogEntries[j].len;
					LogEntries[j].valid = 0;
				}
				j = (j+1) & LOG_ENTRY_INDEX_MASK;
			} while(j != lastTransferedPlusOne);
		}

		// create count of free space from scratch - we want to do this as for long runs sometimes LogFreeLen value gets out of sync,
		// this should actually calcuate the same values as is already in LogFreeLen
		//
		// it is possible that new logs are entered as we do the calcuation,
		// if this happens then do not update LogFreeLen (it will be updated hopefully next time logs are read by PC)
		// we detect if new logs were added during calcuation by comparing LogIndex before and after calcuation
			
		temp = LogIndex;			// store value of LogIndex before calcuation started
		temp2 = LOG_TEXT_BUF_LEN;	// total free length
		for(i=0; i<LOG_MAX_ENTRIES_COUNT; ++i)
		{
			if(LogEntries[i].valid)
				temp2 -= LogEntries[i].len;
		}

		// make sure calculated value is in reasonable range (always should be unless data in LogEntries[] is not correct)
		if(temp2 > LOG_TEXT_BUF_LEN)
			temp2 = LOG_TEXT_BUF_LEN;

		// if no new entries were inserted during calculation then update the free length
		if(temp == LogIndex)
			LogFreeLen = temp2;

		// send response
		DbgStartTx(pd - dbg_Buf + 1, DBG_RESP_OK);

		break;
		#pragma endregion

	#pragma region DBG_GET_DEVICE_NAME
	//case DBG_GET_DEVICE_NAME:
	//	// return device name constant string
	//	// request:
	//	//	no data
	//	// response:
	//	// [3-...] - device name

	//	i = strlen(DeviceName);
	//	memcpy(&dbg_Buf[3], &DeviceName[0], i);

	//	DbgStartTx(4 + i, DBG_RESP_OK);
	//	break;
		#pragma endregion

	#pragma region DBG_USER_CMD
	case DBG_USER_CMD:
		// send command to main code for processing
		// [3-x]: parameter string, must be 1024 chars or less. Terminating zero not required

		// ceck if user function was defined
		if (dbg_UserFunction == NULL)
		{
			DbgStartTx(4, DBG_RESP_USER_FUNC_NOT_DEFINED);
			break;
		}

		// add terminating zero
		dbg_Buf[dbg_RxDataLen + 3] = '\0';

		// execute user function
		i = (*dbg_UserFunction)(dbg_RxDataLen, (char *)&dbg_Buf[3]);
		if (i > DBG_MAX_DATA_LEN)
			i = DBG_MAX_DATA_LEN;

		// send positive response
		DbgStartTx(4 + i, DBG_RESP_OK);
		break;
		#pragma endregion

	default:
		// unrecognized cmd - send negative response
		DbgStartTx(4, DBG_RESP_UNSUPPORTED_CMD);
		break;
	}

}
#pragma endregion

#pragma region ldrCheckAdr()
// function verifies if specified location is valid in specified region
// type - valid regions:
//		LDR_CA_RAM_OR_PERIPH	- periph or ram
//		LDR_CA_ANY				- periph or ram or flash
//
// function returns 0 if value is valid, LDR_RESP_INVALID_ADR if invalid
unsigned char ldrCheckAdr(int type, unsigned int adr, int len)
{
	if (LdrCheckAdrDisabled)
		return 0;

	unsigned char retCode = LDR_RESP_INVALID_ADR;

	int isRam = (adr >= 0x20000000 && (adr+len-1) < (0x20000000 + 32 * 1024)) ? 1 : 0;

	int isFlash = 
		(adr >= 0x08000000 && (adr+len-1) < (0x08000000 + 64 * 1024)) ||	// program memory
		(adr >= 0xE00FF000 && (adr+len-1) <= 0xE00FFFCC) ||					// ROM table
		(adr >= 0x08080000 && (adr + len - 1) <= (0x08080000 + 1024))		// EEPROM
		? 1 : 0;

	int isPeriph =
		(adr >= 0x40000000 && (adr+len-1) <= 0x50010000)
		? 1 : 0;

	if(type == LDR_CA_ANY) {  if(isRam || isFlash || isPeriph) retCode=0; }
	else if(type == LDR_CA_RAM_OR_PERIPH) {  if(isRam || isPeriph) retCode=0; }

	return retCode;
}
#pragma endregion

#pragma region ShowCode()
//
// used for debugging - show data on scope
// functions shows data using two digital pins, one used as mark (clock) pulses high in the middle of data bit
// function sends highest bit first
//
#define SHOW_CODE_MARK(d) SetPortBit1(DBG1, (d))
#define SHOW_CODE_DATA(d) SetPortBit1(DBG2, (d))
void ShowCode(unsigned int data, int count)
{
	unsigned int mask = 1 << (count - 1);

	while(1)
	{
		SHOW_CODE_DATA((data & mask) == 0 ? 0 : 1);

		nop(); nop(); nop(); nop();

		SHOW_CODE_MARK(1);
		mask >>= 1;

		nop(); nop(); nop(); nop();
		SHOW_CODE_MARK(0);

		--count;
		if(count == 0)
			break;
	}

	nop(); nop(); nop(); nop();
	SHOW_CODE_DATA(0);

	Wait(10);
}
#pragma endregion

#pragma region brk_dm()
//
// set request to halt, trigger debug monitor
//
void brk_dm()
{
#ifdef PIC32MAKE
	dm_MainCodeCmd = 1;
	dm_MainCodeRequest = 1;
	TriggerDebugMonitor();
#endif
}
#pragma endregion

#pragma region DbgModuleNames[], DbgSeverityNames[]
// names of modules, each must be 4 chars long and there need to be 8 names even if they are not used
const char * const DbgModuleNames[] = 
{
	"Test",	// 0
	"Intr",	// 1
	"Main",	// 2
	"",	// 3
	"",	// 4
	"",	// 5
	"",	// 6
	"",	// 7
};

// names of severities, each must be 1 chars long and there need to be 8 names even if they are not used
const char * const DbgSeverityNames[] = 
{
#define LOG_SEV_ALWAYS 0
#define LOG_SEV_ERROR 1
#define LOG_SEV_WARNING 2
#define LOG_SEV_PROCESS 3
#define LOG_SEV_INFO 4

	" ",	// 0 - A
	"E",	// 1 - error
	"W",	// 2 - warning
	" ",	// 3 - process info
	" ",	// 4 - info
	" ",	// 5
	" ",	// 6
	" ",	// 7
};
#pragma endregion

#pragma region DbgSendLogsToConsole
//
// function is used when debugging to console
//
// function will check if there are any new logs ready in buffer. If there are some new ones and previous message was completely transmitted already,
// then function will start transmision of oldest log.
//
void DbgSendLogsToConsole()
{
	unsigned oldestPossible;
	unsigned returnedIndex;
	unsigned availableLen;
	unsigned logsCount;
	unsigned lenOfText;
	unsigned lastTransferedPlusOne;
	char *pd;
	unsigned foundValidLog;
	struct _LogEntry le;
	int len;
	unsigned i;
	unsigned j;
	unsigned temp = 0;
	unsigned temp2 = 0;
	static int SentLength = 0;

	// speed throttling - we want to lower transmission speed to specified value to prevent loosing chars due to small buffers in USB cables FTDI chip
	#define MAX_SPEED_BYTES_PER_MS 20
	// remove one period worth od data
	SentLength -= MAX_SPEED_BYTES_PER_MS;
	if (SentLength < 0)
		SentLength = 0;
	else if (SentLength > MAX_SPEED_BYTES_PER_MS)
		return;

	// if log function is active then return so that we dont interfere with it
	if(LogCS)
		return;

	// return immediately if UART is still transmitting previous message
	if( ! __HAL_UART_GET_FLAG(&hlpuart1,UART_FLAG_TC))
		return;

	// find first valid log - we start with oldest possible log (on position LogIndex - LOG_MAX_ENTRIES_COUNT)
	// and find first one that is valid
	oldestPossible = LogIndex > LOG_MAX_ENTRIES_COUNT ? (LogIndex - LOG_MAX_ENTRIES_COUNT) : 0;
	foundValidLog = 0;
	i = LOG_MAX_ENTRIES_COUNT;
	while(i--)
	{
		if(LogEntries[oldestPossible & LOG_ENTRY_INDEX_MASK].valid)
		{
			foundValidLog = 1;
			break;
		}

		++oldestPossible;
	}
	if(!foundValidLog)
	{
		// no valid logs
		return;
	}

	// get index of first log entry that we will return
	returnedIndex = oldestPossible;

	// get length of log to send
	logsCount = 1;
	le = LogEntries[returnedIndex & LOG_ENTRY_INDEX_MASK];
	lenOfText = le.len;

	// format log entry header data
	pd = (char *) & dbg_Buf[0];
	//len = sprintf(pd, "%03d.%06d %s %s ", (le.time / 1000000) % 1000, le.time % 1000000, DbgModuleNames[le.module & 0xf], DbgSeverityNames[le.sev & 0x7]);
	len = sprintf(pd, "%03d.%06d %4s %1s ", (le.time / 1000000) % 1000, le.time % 1000000, DbgModuleNames[le.module & 0x7], DbgSeverityNames[le.sev & 0x7]);
	pd += len;

	// add text for all returned logs
	j = LogEntries[returnedIndex & LOG_ENTRY_INDEX_MASK].pos;
	for(i=0; i<lenOfText; ++i, ++j)
		*pd++ = LogTextBuf[j & LOG_TEXT_BUF_INDEX_MASK];
	len += lenOfText;

	// add new line
	*pd++ = '\r';
	*pd++ = '\n';
	*pd++ = '\0';
	len += 2;
	

	#pragma region release transfered logs
	// release all old logs up to the last transfered one
	// start with oldest log
	j = LogIndex & LOG_ENTRY_INDEX_MASK;
	lastTransferedPlusOne = (returnedIndex + logsCount) & LOG_ENTRY_INDEX_MASK;
	do
	{
		if(LogEntries[j].valid)
		{
			LogFreeLen += LogEntries[j].len;
			LogEntries[j].valid = 0;
		}
		j = (j+1) & LOG_ENTRY_INDEX_MASK;
	} while(j != lastTransferedPlusOne);

	// create count of free space from scratch - we want to do this as for long runs sometimes LogFreeLen value gets out of sync,
	// this should actually calcuate the same values as is already in LogFreeLen
	//
	// it is possible that new logs are entered as we do the calcuation,
	// if this happens then do not update LogFreeLen (it will be updated hopefully next time logs are read by PC)
	// we detect if new logs were added during calcuation by comparing LogIndex before and after calcuation
		
	temp = LogIndex;			// store value of LogIndex before calcuation started
	temp2 = LOG_TEXT_BUF_LEN;	// total free length
	for(i=0; i<LOG_MAX_ENTRIES_COUNT; ++i)
	{
		if(LogEntries[i].valid)
			temp2 -= LogEntries[i].len;
	}

	// make sure calculated value is in reasonable range (always should be unless data in LogEntries[] is not correct)
	if(temp2 > LOG_TEXT_BUF_LEN)
		temp2 = LOG_TEXT_BUF_LEN;

	// if no new entries were inserted during calculation then update the free length
	if(temp == LogIndex)
		LogFreeLen = temp2;
	#pragma endregion

	HAL_UART_Abort(&hlpuart1);
	HAL_UART_Transmit_DMA(&hlpuart1, dbg_Buf, len);

	SentLength += len;
}
#pragma endregion

#pragma region show(groupPin, value, onChange)
//
// function shows 4 bit value using DBGx pins.
//
// if onChange is set then function does nothing if value is the same as last value for the same group
//
// groupPin must be one of DBG4 to DBG7
// value can be 0 to 15 (shown using pins DBG0 to DBG3)
//
// function performs these steps:
// 1) sets the group pin to 1
// 2) shows value using value pins
// 3) sets group pin to 0
// 4) sets all value pins to 0
//
void show(unsigned groupPin, unsigned value, unsigned onChange)
{
}

//
// function shows 16 bit value using DBGx pins.
//
// if onChange is set then function does nothing if value is the same as last value for the same group
//
// groupPin must be one of DBG4 to DBG7
// value will be shown with MSB bits first and LSB bits last
//
void show16(unsigned groupPin, unsigned value, unsigned onChange)
{
}

#pragma endregion


