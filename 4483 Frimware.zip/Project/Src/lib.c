#include "lib.h"
#include "debug.h"
#include "intr.h"
#include "string.h"
#include "stddef.h"
#include "limits.h"

// version: v1.2
// date: 8/16/2019
//
// history
// --- v1.1, BB, 7/18/2016 ---
// made from 4229 project,
// added Int2StrLookup()
// added Int2IntLookup()
// added Sin2()
// ByteArrayToHexStrNoSpace
//
// --- v1.2, BB, 8/16/2019 ---
// added SuperFastHash()
// added ReadSerialNumber()
// added CalcLicenseCode()


#pragma region sprintf(), vsnprintf2()

// stdio variables declaration
//char * print_format_dest_adr;
//int print_format_max_len_minus1;
//int print_format_len;

void print_format2(const char * f, va_list ap, char * print_format_dest_adr, int print_format_max_len_minus1, int *print_format_len);

// store character to *print_format_dest_adr,
void pputch2(char c, char ** print_format_dest_adr, int *print_format_max_len_minus1, int *print_format_len)
{
	if(*print_format_len < *print_format_max_len_minus1)
	{
		**print_format_dest_adr = c;
		(*print_format_dest_adr)++;
	}
	else if(*print_format_len == *print_format_max_len_minus1)
	{
		**print_format_dest_adr = '\0';
	}

	(*print_format_len)++;
}
#define chread2(f) *f


// definitions for "sign"
#define LONG		0x80	// long integral type to be printed
#define MANSIGN		0x40	// sign must be printed
#define PADZERO		0x10	// unused width is to be padded with 0s
#define NOZEROPAD	0x04	// zero padding cannot be selected
#define ISFLOAT		0x02	// type is float and "." still to be printed
#define ISSIGNED	0x01	// number is signed, also...
#define ISNEG		0x01	// number is negative, "-" to be printed

//
// function returns the number of characters printed, not including the final `\0'
//
int sprintf(char *buf, const char * f, ...)
{
	int printFormatLen = 0;

	va_list		ap;
	va_start(ap, f);
	print_format2(f, ap, buf, 65000, &printFormatLen);

	return printFormatLen - 1;
}

//
// function will write at most n-1 of the characters printed into the output string (the n'th character then gets
// the terminating `\0'); if the return value is greater than or equal to the n argument, the string was too short
// and some of the printed characters were discarded.  The output will be always null-terminated unless size is <= 0,
// size is typically specified as sizeof(buf),
//
// function returns the number of characters that would have been printed if the n
// were unlimited (again, not including the final `\0').
//
int snprintf2(char *buf, int size, const char * f, ...)
{
	int printFormatLen = 0;

	va_list		ap;
	va_start(ap, f);
	print_format2(f, ap, buf, size-1, &printFormatLen);

	return printFormatLen - 1;
}

//
// function will write at most n-1 of the characters printed into the output string (the n'th character then gets
// the terminating `\0'); if the return value is greater than or equal to the n argument, the string was too short
// and some of the printed characters were discarded.  The output will be always null-terminated unless size is <= 0,
// size is typically specified as sizeof(buf),
//
// function returns the number of characters that would have been printed if the n
// were unlimited (again, not including the final `\0').
//
int vsnprintf2(char *buf, int size, const char * f, va_list ap)
{
	int printFormatLen = 0;

	print_format2(f, ap, buf, size-1, &printFormatLen);

	return printFormatLen - 1;
}

void print_format2(const char * f, va_list ap, char * print_format_dest_adr, int print_format_max_len_minus1, int *formatLen)
{
	char	c;
	unsigned int	sign;
	unsigned int	prec;
	unsigned int	i;
	unsigned int	j;
	char *x;
	int	width;
	unsigned int q;
	char floatBuf[21];
	//double dbl;
	//float flt;
	char *destAdr = print_format_dest_adr;
	int formatLenMinus1 = print_format_max_len_minus1;

	while((c = chread2(f++)) != '\0')
		if(c !=	'%') {
			pputch2(c,&destAdr,&formatLenMinus1,formatLen);
		} else {
			prec = 65535;	// BB: changed from 255;
			width = 0;
			sign = 0;
loop:
			switch(c = chread2(f++)) {

			case 0:
				//if(IS_RAM(print_format_dest_adr))
				//	*print_format_dest_adr = 0;
				pputch2('\0',&destAdr,&formatLenMinus1,formatLen);
				return;
			case '*':
				width = va_arg(ap, int);
				goto loop;

			case '+':
				sign |= MANSIGN;
				goto loop;
			case 'b':
				prec = 2;
				goto decimal;
			case 'x':
			case 'X':
				prec = 16;
				goto decimal;
			case 'o':
				prec = 8;
				goto decimal;
			case 'd':
				sign++;		// set ISSIGNED and fall through
				// fall through
			case 'u':
				prec = 10;
decimal:
				{

						i = va_arg(ap, int);
					if(sign & ISSIGNED) {
					       	if((int)i < 0) {
							//i = -i;	// and leave ISSIGNED SET
							// BB: modified, trying to get rid of warning: unsigned operand of unary -
							i = (unsigned int)( - (int)i);	// and leave ISSIGNED SET
							width--;
					       	} else {
						       	sign &= ~ISSIGNED; // clear ISSIGED
							if(sign & MANSIGN)
								width--;
						}
					} else {
						sign &= ~ISSIGNED;
					}
					c = (unsigned int)i % prec;	// get last character before '.'
					*(unsigned int *)&i /= prec;	// adjust to remove last character
					j = 1;
					while(j <= i) {
						j *= prec;	// scale up j to be in realm of MS digit
						if(width)
							width--;
					}
					if(!(sign & PADZERO))	// if we're not zero padding
						while(--width > 0)	// but we are padding
							pputch2(' ',&destAdr,&formatLenMinus1,formatLen);	// printf leading spaces

					if(sign & ISNEG) {		// print sign if req'd
						pputch2('-',&destAdr,&formatLenMinus1,formatLen);
					} else if(sign & MANSIGN) {
						pputch2('+',&destAdr,&formatLenMinus1,formatLen);
					}
					if(sign & PADZERO)		// we are zero padding
						while(--width > 0)
							pputch2('0',&destAdr,&formatLenMinus1,formatLen);
					while(j /= prec) {
						// Format to ASCII and print this number
						width = (i/j)%prec;
						if(width > 9)
							width += 'A'-'0'-10;
						pputch2(width+'0',&destAdr,&formatLenMinus1,formatLen);
					}
					if(c > 9)
						c += 'A'-'0'-10;
					pputch2(c+'0',&destAdr,&formatLenMinus1,formatLen);

				}
				break;

			case 'c':
				while(width > 1) {
					pputch2(' ',&destAdr,&formatLenMinus1,formatLen);
					width--;
				}
				c = va_arg(ap, int);
				pputch2(c,&destAdr,&formatLenMinus1,formatLen);
				continue;
				
			//case 'f':
			//case 'g':
			//	// this was added by BB
			//	dbl = va_arg(ap, double);
			//	flt = (float) dbl;
			//	ftoa(floatBuf, flt, prec);
			//	x = floatBuf;
			//	
			//	// get length of string
			//	q = 0; while(x[(int)q]) q++;

			//	// add estra zeros if specified width is bigger then strinf len
			//	while(width > (int)q) {
			//		pputch2(' ',&destAdr,&formatLenMinus1,formatLen);
			//		width--;
			//	}

			//	// copy string
			//	while(q--) {
			//		c = chread2(x++);
			//		pputch2(c,&destAdr,&formatLenMinus1,formatLen);
			//	}

			//	break;

			case 's':
				{

					x = va_arg(ap, char *);
					q = 0;
					while(x[(int)q])
						q++;
					if(q < prec)
						prec = q;
					while(width > (int)prec) {
						pputch2(' ',&destAdr,&formatLenMinus1,formatLen);
						width--;
					}
					while(prec--) {
						c = chread2(x++);
						pputch2(c,&destAdr,&formatLenMinus1,formatLen);
					}
					break;
				}

			case '.':
				if(chread2(f) == '*') {
					prec = va_arg(ap, int);
					f++;
				} else {
					prec = chread2(f++) - '0';
					c = chread2(f);
					if(c >= '0' && c <= '9') {
						prec = prec*10 + c - '0';
						f++;
					}
				}
				goto loop;

			case '0':
				// if we haven't been through a non-zero digit yet
				if(!(sign & NOZEROPAD)) {
					sign |= PADZERO;	// this is a leading 0
					goto loop;
				}
				// otherwise, fall through
				// fall through
			default:
				if(c >= '0' && c <= '9') {
					sign |= NOZEROPAD;	// any zeros to come do not imply zeropad
					width = width * 10 + c - '0';
					goto loop;
				}
				pputch2(c,&destAdr,&formatLenMinus1,formatLen);
				continue;
			}
		}

	//if(IS_RAM(print_format_dest_adr))
	//	*print_format_dest_adr = 0;	// add NULL terminator
	pputch2('\0',&destAdr,&formatLenMinus1,formatLen);
	return;
}

#pragma endregion

#pragma region rand

unsigned int rand_z = 521288629;
unsigned int rand_w = 362436069;

// return random number
unsigned int Rand()
{
	rand_z = 36969 * (rand_z & 0xffff) + (rand_z >> 16);
	rand_w = 18000 * (rand_w & 0xffff) + (rand_w >> 16);
	return (rand_z << 16) + rand_w;
}

// set seed for random number generator
void RandSetSeed(unsigned int seed)
{
	if(seed == 0)
		seed = 362436069;

	rand_z = 521288629;
	rand_w = seed;
}

#pragma endregion

#pragma region Sleep()
//
// wait specified time, max value is 33553 (33.55 sec), higher value will make aprox 51.1 sec wait
//
void Sleep(int milisec)
{
	Wait(milisec * 1000);
}
#pragma endregion

#pragma region isspace(), islower(), isupper(), isalpha(), isdigit(), stoupper(), stolower(), reverse()

// return non-zero if specified char is space, tab, '\r', '\n'
int isspace(int c)
{
	return (c == ' ' || c == '\t' || c == '\r' || c == '\n');
}

// test for a lower case letter
int islower(int c)
{
    return (c >= 'a' && c <= 'z');
}

// test for a upper case letter
int isupper(int c)
{
    return (c >= 'A' && c <= 'Z');
}

// test for a lowercase letter
int isalpha(int c)
{
    return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'));
}

// test for decimal digit character
int isdigit(int c)
{
    return (c >= '0' && c <= '9');
}

// convert all string chars to upper case
void stoupper(char *s)
{
	for(; *s; s++)
		if(('a' <= *s) && (*s <= 'z'))
			*s = 'A' + (*s - 'a');
}

// convert all string chars to lower case
void stolower(char *s)
{
	for(; *s; s++)
		if(('A' <= *s) && (*s <= 'Z'))
			*s = 'a' + (*s - 'A');
}

//reverse a string
void reverse(char *str)
{
    int i;
    int len = strlen(str) - 1;
    int mid = (len % 2) ? (len / 2) : ((len + 1) / 2);
    for(i = 0; i <= mid; ++i)
    {
        char buf = str[i];
        str[i] = str[len - i];
        str[len - i] = buf;
    }
}

#pragma endregion

#pragma region trim(), SkipSpace()

//
// remove all white space chars from beginning and end of string
//
void trim(char *str)
{
	int i;
	int len;
	char c;

	// get length
	len = strlen(str);

	// trim end
	while(len > 0)
	{
		c = str[len - 1];
		if( ! (c==' ' || c=='\t' || c=='\r' || c=='\n') )
			break;

		--len;
	}
	str[len] = '\0';

	// count number of white space chars at the begining
	for(i=0; i<len; ++i)
	{
		c = str[i];
		if( ! (c==' ' || c=='\t' || c=='\r' || c=='\n') )
			break;
	}

	// move string to cover empty spaces at the begining
	if(i > 0)
	{
		memcpy(str, str + i, len - i + 1);
	}

}

// skip all white space chars, after the function is called it will point to to the first non white-space char
char *SkipSpace(char *p)
{
	while(isspace(*p)) ++p;
	return p;
}
#pragma endregion

#pragma region strcmp(), strncpy, strncmp, stricmp, strnicmp

//
// compare strings,
// return <0 if first is lower, 0 is the same, >0 if s1 bigger then s2
//
int strcmp(const char *s1, const char *s2)
{
    for ( ; *s1 == *s2; s1++, s2++)
	if (*s1 == '\0')
	    return 0;
    return ((*(unsigned char *)s1 < *(unsigned char *)s2) ? -1 : +1);
}


//
// Copies the first num characters of source to destination,
// If the end of the source C string (which is signaled by a null-character) is found before num characters have been copied,
// destination is padded with zeros until a total of num characters have been written to it
// No null-character is implicitly appended at the end of destination if source is longer than num (thus, in this case, destination may not be a null terminated C string).
// destination and source shall not overlap (see memmove for a safer alternative when overlapping).
//
char *strncpy(char *dest, const char *source, size_t n)
{
  char *start = dest;

  while (n && (*dest++ = *source++)) n--;
  if (n) while (--n) *dest++ = '\0';
  return start;
}

//
// Compares up to num characters of the C string str1 to those of the C string str2,
// This function starts comparing the first character of each string,
// If they are equal to each other, it continues with the following pairs until the characters differ,
// until a terminating null-character is reached, or until num characters match in both strings, whichever happens first.
//
int strncmp(const char *s1, const char *s2, size_t n)
{
    for ( ; n > 0; s1++, s2++, --n)
	if (*s1 != *s2)
	    return ((*(unsigned char *)s1 < *(unsigned char *)s2) ? -1 : +1);
	else if (*s1 == '\0')
	    return 0;
    return 0;
}

//
// stricmp(str1,str2) compares str1 and str2 lexicographically without regards to case,
// It returns a negative value if str1<str2; 0 if str1 and str2 are identical; and positive value if str1>str2.
//
int stricmp(const char *s1, const char *s2)
{
  char f, l;

  do {
    f = ((*s1 <= 'Z') && (*s1 >= 'A')) ? *s1 + 'a' - 'A' : *s1;
    l = ((*s2 <= 'Z') && (*s2 >= 'A')) ? *s2 + 'a' - 'A' : *s2;
    s1++;
    s2++;
  } while ((f) && (f == l));

  return (int) (f - l);
}

//
// compares, at most, the first n characters of string1 and string2 without sensitivity to case.
//
int strnicmp(const char *s1, const char *s2, size_t n)
{
  int f, l;

  do {
    if (((f = (unsigned char)(*(s1++))) >= 'A') && (f <= 'Z')) f -= 'A' - 'a';
    if (((l = (unsigned char)(*(s2++))) >= 'A') && (l <= 'Z')) l -= 'A' - 'a';
  } while (--n && f && (f == l));

  return f - l;
}
#pragma endregion

#pragma region GetLine
//
// function copies next line from text to dest,
// end of line character is '\n', '\r' chars are skipped (not copied)
// function returns pointer to text after the last copies character, this will be first char or next line or '\0' at the end of text
// function will never write more then maxLenToCopy, copied text will always include '\0' at the end,
//		for example if maxLenToCopy=4 and next line is 10 chars long then dest will be "abc\0' after the call and function returns poitner to next line's first char
char *GetLine(char *dest, int maxLenToCopy, char *text)
{
	char *p;
	int len;

	// chack params
	if(maxLenToCopy <= 0)
		return text;
	else if(maxLenToCopy == 1)
	{
		*dest = '\0';
		return text;
	}

	// copy chars
	for(p=text, len=1; ; ++p, ++len)
	{
		// skip '\r'
		if(*p == '\r')
			continue;
		
		if(len < maxLenToCopy)
		{
			// if there is still space for chars in dest then copy char,
			// copy terminating '0' if this is end of line or end of text
			*dest++ = (*p == '\n' || *p == '\0') ? '\0' : *p;
		}
		else if(len == maxLenToCopy)
		{
			// end fo space in dest, store termianting '\0'
			*dest++ = '\0';
		}

		if(*p == '\0')
			return p;

		if(*p == '\n')
			return p + 1;
	}
}
#pragma endregion

#pragma region GetWord()
// copy first word to dest, words are separated by white space,
// function will write '\0; at the end of copied word,
// dest must have enough space for longerst word and terminating '\0',
// function skips spaces first, then copies word,
// function return pointer to first char after the copied word - this will be either some white space char or '\0'
char *GetWord(char *dest, char *text)
{
	char *p;

	// skip spaces first
	p = SkipSpace(text);

	// copy while non-space
	while( ! isspace(*p)) *dest++ = *p++;

	// add terminator
	*dest = '\0';

	return p;
}
#pragma endregion

#pragma region strtol(), strtoul(), strtoll(), strtoull()
//
// Convert a string to a long integer.
//
// Parses the C string str interpreting its content as an integral number of the specified base,
// which is returned as a long int value. If endptr is not a null pointer, the function also sets
// the value of endptr to point to the first character after the number.
//
// The function first discards as many whitespace characters as necessary until the first
// non-whitespace character is found. Then, starting from this character, takes as many characters as
// possible that are valid following a syntax that depends on the base parameter, and interprets them as
// a numerical value. Finally, a pointer to the first character following the integer representation in str
// is stored in the object pointed by endptr.
//
// If the value of base is zero, the syntax expected is similar to that of integer constants, which is
// formed by a succession of:
//
// An optional sign character (+ or -)
// An optional prefix indicating hexadecimal base "0x"/"0X"
// An optional prefix indicating binary base "0b"/"0B"
// function was modified on feb 2 2014 by BB to remove support of octal format when base 0 is specified (this is so that 010 is not parsed as 8)
//
// A sequence of decimal digits (if no base prefix was specified) or hexadecimal digits if a specific prefix is present
//
// If the base value is between 2 and 36, the format expected for the integral number is a succession of any
// of the valid digits and/or letters needed to represent integers of the specified radix
// (starting from '0' and up to 'z'/'Z' for radix 36). The sequence may optionally be preceded by a sign
// (either + or -) and, if base is 16, an optional "0x" or "0X" prefix.
//
// If the first sequence of non-whitespace characters in str is not a valid integral number as defined above,
// or if no such sequence exists because either str is empty or it contains only whitespace characters,
// no conversion is performed.
//
long strtol(const char *nptr, char **endptr, int base)
{
	const char *s = nptr;
	unsigned long acc;
	int c;
	unsigned long cutoff;
	int neg = 0, any, cutlim;

	/*
	 * Skip white space and pick up leading +/- sign if any.
	 * If base is 0, allow 0x for hex and 0b/0B for binary, else
	 * assume decimal; if base is already 16, allow 0x.
	 */
	do {
		c = *s++;
	} while (isspace(c));
	if (c == '-') {
		neg = 1;
		c = *s++;
	} else if (c == '+')
		c = *s++;
	if ((base == 0 || base == 16) &&
	    c == '0' && (*s == 'x' || *s == 'X')) {
		c = s[1];
		s += 2;
		base = 16;
	} else if ((base == 0 || base == 2) &&
	    c == '0' && (*s == 'b' || *s == 'B')) {
		c = s[1];
		s += 2;
		base = 2;
	}
	if (base == 0)
		base = 10;

	/*
	 * Compute the cutoff value between legal numbers and illegal
	 * numbers.  That is the largest legal value, divided by the
	 * base.  An input number that is greater than this value, if
	 * followed by a legal input character, is too big.  One that
	 * is equal to this value may be valid or not; the limit
	 * between valid and invalid numbers is then based on the last
	 * digit.  For instance, if the range for longs is
	 * [-2147483648..2147483647] and the input base is 10,
	 * cutoff will be set to 214748364 and cutlim to either
	 * 7 (neg==0) or 8 (neg==1), meaning that if we have accumulated
	 * a value > 214748364, or equal but the next digit is > 7 (or 8),
	 * the number is too big, and we will return a range error.
	 *
	 * Set any if any `digits' consumed; make it negative to indicate
	 * overflow.
	 */
	if(base != 10)
	{
		// hex or bin numbers - allow to parse negative numbers - we need to make limit one bit bigger
		cutoff = (unsigned long)ULONG_MAX / (unsigned long)base;
		cutlim = (unsigned long)ULONG_MAX % (unsigned long)base;
	}
	else
	{
		// decimal numbers
		cutoff = neg ? -(unsigned long)LONG_MIN : LONG_MAX;
		cutlim = cutoff % (unsigned long)base;
		cutoff /= (unsigned long)base;
	}

	for (acc = 0, any = 0;; c = *s++) {
		if (isdigit(c))
			c -= '0';
		else if (isalpha(c))
			c -= isupper(c) ? 'A' - 10 : 'a' - 10;
		else
			break;
		if (c >= base)
			break;
		if (any < 0 || acc > cutoff || (acc == cutoff && c > cutlim))
			any = -1;
		else {
			any = 1;
			acc *= base;
			acc += c;
		}
	}
	if (any < 0) {
		acc = neg ? LONG_MIN : LONG_MAX;
//		errno = ERANGE;
		any = 0;
	} else if (neg)
		acc = -acc;
	if (endptr != 0)
		*endptr = (char *)(any ? s - 1 : nptr);
	return (acc);
}

//
// parse long long integer value, see strtol() for more info
//
long long strtoll(const char *nptr, char **endptr, int base)
{
	const char *s = nptr;
	unsigned long long acc;
	int c;
	unsigned long long cutoff;
	int neg = 0, any, cutlim;

	/*
	 * Skip white space and pick up leading +/- sign if any.
	 * If base is 0, allow 0x for hex and 0b/0B for binary, else
	 * assume decimal; if base is already 16, allow 0x.
	 */
	do {
		c = *s++;
	} while (isspace(c));
	if (c == '-') {
		neg = 1;
		c = *s++;
	} else if (c == '+')
		c = *s++;
	if ((base == 0 || base == 16) &&
	    c == '0' && (*s == 'x' || *s == 'X')) {
		c = s[1];
		s += 2;
		base = 16;
	} else if ((base == 0 || base == 2) &&
	    c == '0' && (*s == 'b' || *s == 'B')) {
		c = s[1];
		s += 2;
		base = 2;
	}
	if (base == 0)
		base = 10;

	/*
	 * Compute the cutoff value between legal numbers and illegal
	 * numbers.  That is the largest legal value, divided by the
	 * base.  An input number that is greater than this value, if
	 * followed by a legal input character, is too big.  One that
	 * is equal to this value may be valid or not; the limit
	 * between valid and invalid numbers is then based on the last
	 * digit.  For instance, if the range for longs is
	 * [-2147483648..2147483647] and the input base is 10,
	 * cutoff will be set to 214748364 and cutlim to either
	 * 7 (neg==0) or 8 (neg==1), meaning that if we have accumulated
	 * a value > 214748364, or equal but the next digit is > 7 (or 8),
	 * the number is too big, and we will return a range error.
	 *
	 * Set any if any `digits' consumed; make it negative to indicate
	 * overflow.
	 */
	if(base != 10)
	{
		// hex or bin numbers - allow to parse negative numbers - we need to make limit one bit bigger
		cutoff = (unsigned long long)ULONG_LONG_MAX / (unsigned long long)base;
		cutlim = (unsigned long long)ULONG_LONG_MAX % (unsigned long long)base;
	}
	else
	{
		// decimal numbers
		cutoff = neg ? -(unsigned long long)LONG_LONG_MIN : LONG_LONG_MAX;
		cutlim = cutoff % (unsigned long long)base;
		cutoff /= (unsigned long long)base;
	}

	for (acc = 0, any = 0;; c = *s++) {
		if (isdigit(c))
			c -= '0';
		else if (isalpha(c))
			c -= isupper(c) ? 'A' - 10 : 'a' - 10;
		else
			break;
		if (c >= base)
			break;
		if (any < 0 || acc > cutoff || (acc == cutoff && c > cutlim))
			any = -1;
		else {
			any = 1;
			acc *= base;
			acc += c;
		}
	}
	if (any < 0) {
		acc = neg ? LONG_LONG_MIN : LONG_LONG_MAX;
//		errno = ERANGE;
		any = 0;
	} else if (neg)
		acc = -acc;

	if (endptr != 0)
		*endptr = (char *)(any ? s - 1 : nptr);
	return (acc);
}


//
// Convert a string to an unsigned long integer.
// see strtol() for details
//
unsigned long strtoul(const char *nptr,	char **endptr, int base)
{
	const char *s = nptr;
	unsigned long acc;
	int c;
	unsigned long cutoff;
	int neg = 0, any, cutlim;

	/*
	 * See strtol for comments as to the logic used.
	 */
	do {
		c = *s++;
	} while (isspace(c));
	
	//if (c == '-') {
	//	neg = 1;
	//	c = *s++;
	//} else if (c == '+')
	//	c = *s++;
	if (c == '+')
		c = *s++;

	if ((base == 0 || base == 16) &&
	    c == '0' && (*s == 'x' || *s == 'X')) {
		c = s[1];
		s += 2;
		base = 16;
	} else if ((base == 0 || base == 2) &&
	    c == '0' && (*s == 'b' || *s == 'B')) {
		c = s[1];
		s += 2;
		base = 2;
	}
	if (base == 0)
		base = 10;
	cutoff = (unsigned long)ULONG_MAX / (unsigned long)base;
	cutlim = (unsigned long)ULONG_MAX % (unsigned long)base;
	for (acc = 0, any = 0;; c = *s++) {
		if (isdigit(c))
			c -= '0';
		else if (isalpha(c))
			c -= isupper(c) ? 'A' - 10 : 'a' - 10;
		else
			break;
		if (c >= base)
			break;
		if (any < 0 || acc > cutoff || (acc == cutoff && c > cutlim))
			any = -1;
		else {
			any = 1;
			acc *= base;
			acc += c;
		}
	}
	if (any < 0) {
		acc = ULONG_MAX;
//		errno = ERANGE;
		any = 0;
	} else if (neg)
		acc = -acc;
	if (endptr != 0)
		*endptr = (char *)(any ? s - 1 : nptr);
	return (acc);
}

//
// Convert a string to an unsigned long long integer.
// see strtol() for details
//
unsigned long long strtoull(const char *nptr, char **endptr, int base)
{
	const char *s = nptr;
	unsigned long long acc;
	int c;
	unsigned long long cutoff;
	int neg = 0, any, cutlim;

	/*
	 * See strtol for comments as to the logic used.
	 */
	do {
		c = *s++;
	} while (isspace(c));

	//if (c == '-') {
	//	neg = 1;
	//	c = *s++;
	//} else if (c == '+')
	//	c = *s++;
	if (c == '+')
		c = *s++;

	if ((base == 0 || base == 16) &&
	    c == '0' && (*s == 'x' || *s == 'X')) {
		c = s[1];
		s += 2;
		base = 16;
	} else if ((base == 0 || base == 2) &&
	    c == '0' && (*s == 'b' || *s == 'B')) {
		c = s[1];
		s += 2;
		base = 2;
	}
	if (base == 0)
		base = 10;
	cutoff = (unsigned long long)ULONG_LONG_MAX / (unsigned long long)base;
	cutlim = (unsigned long long)ULONG_LONG_MAX % (unsigned long long)base;
	for (acc = 0, any = 0;; c = *s++) {
		if (isdigit(c))
			c -= '0';
		else if (isalpha(c))
			c -= isupper(c) ? 'A' - 10 : 'a' - 10;
		else
			break;
		if (c >= base)
			break;
		if (any < 0 || acc > cutoff || (acc == cutoff && c > cutlim))
			any = -1;
		else {
			any = 1;
			acc *= base;
			acc += c;
		}
	}
	if (any < 0) {
		acc = ULONG_LONG_MAX;
//		errno = ERANGE;
		any = 0;
	} else if (neg)
		acc = -acc;
	if (endptr != 0)
		*endptr = (char *)(any ? s - 1 : nptr);
	return (acc);
}
#pragma endregion

#pragma region strtod1()
/*
#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif
#ifndef NULL
#define NULL 0
#endif

static int strtod_maxExponent = 511;	// Largest possible base 10 exponent.  Any exponent larger than this will already produce underflow or overflow, so there's no need to worry about additional digits.
static double strtod_PowersOf10[] = {	// Table giving binary Powers of 10.  Entry is 10^2^i.  Used to convert decimal exponents into floating-point numbers.
    10.,
    100.,
    1.0e4,
    1.0e8,
    1.0e16,
    1.0e32,
    1.0e64,
    1.0e128,
    1.0e256
};

// strtod1 --
// This procedure converts a floating-point number from an ASCII
// decimal representation to internal double-precision format.
// Results:
// The return value is the double-precision floating-point
// representation of the characters in string.  If endPtr isn't
// NULL, then *endPtr is filled in with the address of the
// next character after the last one that was part of the
// floating-point number.
//
// char *string
// A decimal ASCII floating-point number,
// optionally preceded by white space.
// Must have form "-I.FE-X", where I is the
// integer part of the mantissa, F is the
// fractional part of the mantissa, and X
// is the exponent.  Either of the signs
// may be "+", "-", or omitted.  Either I
// or F may be omitted, or both.  The decimal
// point isn't necessary unless F is present.
// The "E" may actually be an "e".  E and X
// may both be omitted (but not just one).

// char **endPtr
// If non-NULL, store terminating character's address here.
double strtod1(char *string, char **endPtr)
{
    int sign, expSign = FALSE;
    double fraction, dblExp, *d;
    register char *p;
    register int c;
    int exp = 0;		// Exponent read from "EX" field.
    int fracExp = 0;
				 // Exponent that derives from the fractional
				 // part.  Under normal circumstatnces, it is
				 // the negative of the number of digits in F.
				 // However, if I is very long, the last digits
				 // of I get dropped (otherwise a long I with a
				 // large negative exponent could cause an
				 // unnecessary overflow on I alone).  In this
				 // case, fracExp is incremented one for each
				 // dropped digit.
    int mantSize;		// Number of digits in mantissa.
    int decPt;			// Number of mantissa digits BEFORE decimal point.
    char *pExp;		// Temporarily holds location of exponent in string.

    
    // Strip off leading blanks and check for a sign.


    p = string;
    while (isspace((unsigned char)(*p))) {
	p += 1;
    }
    if (*p == '-') {
	sign = TRUE;
	p += 1;
    } else {
	if (*p == '+') {
	    p += 1;
	}
	sign = FALSE;
    }

     // Count the number of digits in the mantissa (including the decimal
     // point), and also locate the decimal point.

    decPt = -1;
    for (mantSize = 0; ; mantSize += 1)
    {
	c = *p;
	if (!isdigit(c)) {
	    if ((c != '.') || (decPt >= 0)) {
		break;
	    }
	    decPt = mantSize;
	}
	p += 1;
    }

     // Now suck up the digits in the mantissa.  Use two integers to
     // collect 9 digits each (this is faster than using floating-point).
     // If the mantissa has more than 18 digits, ignore the extras, since
     // they can't affect the value anyway.
    
    pExp  = p;
    p -= mantSize;
    if (decPt < 0) {
	decPt = mantSize;
    } else {
	mantSize -= 1;			// One of the digits was the point.
    }
    if (mantSize > 18) {
	fracExp = decPt - 18;
	mantSize = 18;
    } else {
	fracExp = decPt - mantSize;
    }
    if (mantSize == 0) {
	fraction = 0.0;
	p = string;
	goto done;
    } else {
	int frac1, frac2;
	frac1 = 0;
	for ( ; mantSize > 9; mantSize -= 1)
	{
	    c = *p;
	    p += 1;
	    if (c == '.') {
		c = *p;
		p += 1;
	    }
	    frac1 = 10*frac1 + (c - '0');
	}
	frac2 = 0;
	for (; mantSize > 0; mantSize -= 1)
	{
	    c = *p;
	    p += 1;
	    if (c == '.') {
		c = *p;
		p += 1;
	    }
	    frac2 = 10*frac2 + (c - '0');
	}
	fraction = (1.0e9 * frac1) + frac2;
    }

    // Skim off the exponent.

    p = pExp;
    if ((*p == 'E') || (*p == 'e')) {
	p += 1;
	if (*p == '-') {
	    expSign = TRUE;
	    p += 1;
	} else {
	    if (*p == '+') {
		p += 1;
	    }
	    expSign = FALSE;
	}
	if (!isdigit((unsigned char)(*p))) {
	    p = pExp;
	    goto done;
	}
	while (isdigit((unsigned char)(*p))) {
	    exp = exp * 10 + (*p - '0');
	    p += 1;
	}
    }
    if (expSign) {
	exp = fracExp - exp;
    } else {
	exp = fracExp + exp;
    }

     // Generate a floating-point number that represents the exponent.
     // Do this by processing the exponent one bit at a time to combine
     // many Powers of 2 of 10. Then combine the exponent with the
     // fraction.
    
    if (exp < 0) {
	expSign = TRUE;
	exp = -exp;
    } else {
	expSign = FALSE;
    }
    if (exp > strtod_maxExponent) {
	exp = strtod_maxExponent;
	//errno = ERANGE;
    }
    dblExp = 1.0;
    for (d = strtod_PowersOf10; exp != 0; exp >>= 1, d += 1) {
	if (exp & 01) {
	    dblExp *= *d;
	}
    }
    if (expSign) {
	fraction /= dblExp;
    } else {
	fraction *= dblExp;
    }

done:
    if (endPtr != NULL) {
	*endPtr = (char *) p;
    }

    if (sign) {
	return -fraction;
    }
    return fraction;
}

*/
#pragma endregion

#if 0
#pragma region strtof1()

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif
#ifndef NULL
#define NULL 0
#endif

static int strtof_maxExponent = 63;	// Largest possible base 10 exponent.  Any exponent larger than this will already produce underflow or overflow, so there's no need to worry about additional digits.
static float strtof_PowersOf10[] = {	// Table giving binary Powers of 10.  Entry is 10^2^i.  Used to convert decimal exponents into floating-point numbers.
    10.f,
    100.f,
    1.0e4f,
    1.0e8f,
    1.0e16f,
    1.0e32f,
};

//
// made by BB from strtod1() code
//
// strtod1 --
// This procedure converts a floating-point number from an ASCII
// decimal representation to internal double-precision format.
// Results:
// The return value is the double-precision floating-point
// representation of the characters in string.  If endPtr isn't
// NULL, then *endPtr is filled in with the address of the
// next character after the last one that was part of the
// floating-point number.
//
// char *string
// A decimal ASCII floating-point number,
// optionally preceded by white space.
// Must have form "-I.FE-X", where I is the
// integer part of the mantissa, F is the
// fractional part of the mantissa, and X
// is the exponent.  Either of the signs
// may be "+", "-", or omitted.  Either I
// or F may be omitted, or both.  The decimal
// point isn't necessary unless F is present.
// The "E" may actually be an "e".  E and X
// may both be omitted (but not just one).

// char **endPtr
// If non-NULL, store terminating character's address here.
float strtof1(char *string, char **endPtr)
{
    int sign, expSign = FALSE;
    float fraction, dblExp, *d;
    register char *p;
    register int c;
    int exp = 0;		/* Exponent read from "EX" field. */
    int fracExp = 0;		/* Exponent that derives from the fractional
				 * part.  Under normal circumstatnces, it is
				 * the negative of the number of digits in F.
				 * However, if I is very long, the last digits
				 * of I get dropped (otherwise a long I with a
				 * large negative exponent could cause an
				 * unnecessary overflow on I alone).  In this
				 * case, fracExp is incremented one for each
				 * dropped digit. */
    int mantSize;		/* Number of digits in mantissa. */
    int decPt;			/* Number of mantissa digits BEFORE decimal
				 * point. */
    char *pExp;		/* Temporarily holds location of exponent
				 * in string. */

    /*
     * Strip off leading blanks and check for a sign.
     */

    p = string;
    while (isspace((unsigned char)(*p))) {
	p += 1;
    }
    if (*p == '-') {
	sign = TRUE;
	p += 1;
    } else {
	if (*p == '+') {
	    p += 1;
	}
	sign = FALSE;
    }

    /*
     * Count the number of digits in the mantissa (including the decimal
     * point), and also locate the decimal point.
     */

    decPt = -1;
    for (mantSize = 0; ; mantSize += 1)
    {
	c = *p;
	if (!isdigit(c)) {
	    if ((c != '.') || (decPt >= 0)) {
		break;
	    }
	    decPt = mantSize;
	}
	p += 1;
    }

    /*
     * Now suck up the digits in the mantissa.  Use two integers to
     * collect 9 digits each (this is faster than using floating-point).
     * If the mantissa has more than 18 digits, ignore the extras, since
     * they can't affect the value anyway.
     */
    
    pExp  = p;
    p -= mantSize;
    if (decPt < 0) {
	decPt = mantSize;
    } else {
	mantSize -= 1;			/* One of the digits was the point. */
    }
    if (mantSize > 18) {
	fracExp = decPt - 18;
	mantSize = 18;
    } else {
	fracExp = decPt - mantSize;
    }
    if (mantSize == 0) {
	fraction = 0.0f;
	p = string;
	goto done;
    } else {
	int frac1, frac2;
	frac1 = 0;
	for ( ; mantSize > 9; mantSize -= 1)
	{
	    c = *p;
	    p += 1;
	    if (c == '.') {
		c = *p;
		p += 1;
	    }
	    frac1 = 10*frac1 + (c - '0');
	}
	frac2 = 0;
	for (; mantSize > 0; mantSize -= 1)
	{
	    c = *p;
	    p += 1;
	    if (c == '.') {
		c = *p;
		p += 1;
	    }
	    frac2 = 10*frac2 + (c - '0');
	}
	fraction = (1.0e9f * frac1) + frac2;
    }

    /*
     * Skim off the exponent.
     */

    p = pExp;
    if ((*p == 'E') || (*p == 'e')) {
	p += 1;
	if (*p == '-') {
	    expSign = TRUE;
	    p += 1;
	} else {
	    if (*p == '+') {
		p += 1;
	    }
	    expSign = FALSE;
	}
	if (!isdigit((unsigned char)(*p))) {
	    p = pExp;
	    goto done;
	}
	while (isdigit((unsigned char)(*p))) {
	    exp = exp * 10 + (*p - '0');
	    p += 1;
	}
    }
    if (expSign) {
	exp = fracExp - exp;
    } else {
	exp = fracExp + exp;
    }

    /*
     * Generate a floating-point number that represents the exponent.
     * Do this by processing the exponent one bit at a time to combine
     * many Powers of 2 of 10. Then combine the exponent with the
     * fraction.
     */
    
    if (exp < 0) {
	expSign = TRUE;
	exp = -exp;
    } else {
	expSign = FALSE;
    }
    if (exp > strtof_maxExponent) {
	exp = strtof_maxExponent;
	//errno = ERANGE;
    }
    dblExp = 1.0f;
    for (d = strtof_PowersOf10; exp != 0; exp >>= 1, d += 1) {
	if (exp & 01) {
	    dblExp *= *d;
	}
    }
    if (expSign) {
	fraction /= dblExp;
    } else {
	fraction *= dblExp;
    }

done:
    if (endPtr != NULL) {
	*endPtr = (char *) p;
    }

    if (sign) {
	return -fraction;
    }
    return fraction;
}
#endif

#pragma endregion

#pragma region lltoa(), ulltoa(), ltoa(), ftoa()

// convert long long to string
// return length of result string
int lltoa(char *s, long long n, int base)
{
	if(n < 0 && base == 10)
	{
		*s++ = '-';
		return ulltoa(s, (unsigned long long) -n, base) + 1;
	}
	else
	{
		return ulltoa(s, (unsigned long long) n, base);
	}
}

// convert unsiged long long to string
// return length of result string
int ulltoa(char *s, unsigned long long n, int base)
{
  char *ptr;
  int len;
  int digitValue;

  ptr = s;

  do // generate digits in reverse order
  {
	digitValue = n % base;
	if(digitValue > 9)
		*ptr++ = digitValue - 10 + 'A';
	else
		*ptr++ = digitValue + '0';
  } while ((n = n / base) > 0);
  
  *ptr = '\0';
  
  reverse(s);
  return ptr - s;
}

// convert long or int to string
// return length of result string
int ltoa(char *s, long n, int base)
{
	if(n < 0 && base == 10)
	{
		*s++ = '-';
		return ultoa(s, (unsigned long) -n, base) + 1;
	}
	else
	{
		return ultoa(s, (unsigned long) n, base);
	}
}

// convert unsigned long or unsigned int to string
// return length of result string
int ultoa(char *s, unsigned long n, int base)
{
  char *ptr;
  int len;
  int digitValue;

  ptr = s;

  do // generate digits in reverse order
  {
	digitValue = n % base;
	if(digitValue > 9)
		*ptr++ = digitValue - 10 + 'A';
	else
		*ptr++ = digitValue + '0';
  } while ((n = n / base) > 0);
  
  *ptr = '\0';
  
  reverse(s);
  return ptr - s;
}

#if 0
int ftoa_worker(char *outbuf, float f, int precision);
#define _FTOA_TOO_LARGE 1
#define _FTOA_TOO_SMALL 2

//
// outbut needs to be 20+1 chars long,
// precision - how many digits after decimal point to print
//
// return 0 if conversion was OK
//
int ftoa(char *outbuf, float f, int precision)
{
	int exp = 0;
	int maxLoops = 35;
	int ret;
	int len;

	// special case for printing zero
	if(f == 0.0f)
	{
		strcpy(outbuf, "0");
		return 0;
	}

	// deal with negative sign
	if(f < 0.0f)
	{
		*outbuf++ = '-';
		f = -f;
	}

	// check exponent
	if(f >= 1e6f)
	{
		// convert to number with positive exponenet
		while(f >= 1e6f && --maxLoops)
		{
			f = f * 1e-3f;
			exp += 3;
		}

		if(maxLoops == 0)
		{
			strcpy(outbuf, "1e99");
			return _FTOA_TOO_LARGE;
		}
	}
	else if(f < 1e-6f)
	{
		// convert to number with negative exponent
		while(f < 1.0f && --maxLoops)
		{
			f = f * 1e3f;
			exp -= 3;
		}

		if(maxLoops == 0)
		{
			strcpy(outbuf, "1e-99");
			return _FTOA_TOO_SMALL;
		}
	}

	// print part before exponenet
	ret = ftoa_worker(outbuf, f, precision);

	// add exponent
	if(exp != 0)
	{
		len = strlen(outbuf);
		outbuf[len++] = 'e';
		ltoa(outbuf + len, exp, 10);
	}

	return ret;
}

typedef union 
{  
    long    L;  
    float   F;  
}       LF_t;  

//
// outbut needs to be 15+1 chars long,
//
// precision - how many digitas after decimal point to print
// return 0 if conversion was OK
//
int ftoa_worker(char *outbuf, float f, int precision)
{  
    long mantissa, int_part, frac_part;  
    short exp2;  
    LF_t x;  
    char *p;  
  
    if (f == 0.0f)  
        {  
        outbuf[0] = '0';  
        outbuf[1] = 0;  
        return 0;  
        }  
    x.F = f;  
  
    exp2 = (unsigned char)(x.L >> 23) - 127;  
    mantissa = (x.L & 0xFFFFFF) | 0x800000;  
    frac_part = 0;  
    int_part = 0;  
  
    if (exp2 >= 31)  
        {
			strcpy(outbuf,"???");
			return _FTOA_TOO_LARGE;   
        }  
    else if (exp2 < -23)  
        {  
			strcpy(outbuf,"???");
	        return _FTOA_TOO_SMALL;
        }  
    else if (exp2 >= 23)  
        int_part = mantissa << (exp2 - 23);  
    else if (exp2 >= 0)   
        {  
        int_part = mantissa >> (23 - exp2);  
        frac_part = (mantissa << (exp2 + 1)) & 0xFFFFFF;  
        }  
    else /* if (exp2 < 0) */  
        frac_part = (mantissa  & 0xFFFFFF) >> -(exp2 + 1);  
  
    p = outbuf;  
  
    if (x.L < 0)  
        *p++ = '-';  
  
    if (int_part == 0)  
        *p++ = '0';  
    else  
        {  
        ltoa(p, int_part, 10);  
        while (*p)  
            p++;  
        }  

	if(precision > 0)
	{
		*p++ = '.';  
  
		if (frac_part == 0)  
		{
			*p++ = '0';  
		}
		else  
		{  
			char m, max;  
	  
			//max = sizeof (outbuf) - (p - outbuf) - 1;  
			max = 15 - (p - outbuf) - 1;  
			if (max > 6)  
				max = 6;
			if(max > precision)
				max = precision;

			/* print BCD */  
			for (m = 0; m < max; m++)  
				{  
				/* frac_part *= 10; */  
				frac_part = (frac_part << 3) + (frac_part << 1);      
	  
				*p++ = (frac_part >> 24) + '0';  
				frac_part &= 0xFFFFFF;  
				}  
			/* delete ending zeroes */  
			for (--p; p[0] == '0' && p[-1] != '.'; --p)  
				;  
			++p;  
		}  
	}

    *p = 0;  
  
    return 0;  
}
#endif

#pragma endregion

#pragma region AppendStr(), AppendStrN(), CopyStr(), ByteArrayToHexStr(), HexCharToValue(), HexStringToByteArray(), StrReplace

// function appends characters from src to the end of string in dest,
// function will not write behind end of dest buffer,
// function will always write terminating '\0',
// if not all characters fit then function copy as much as possible and terminates dest string with '\0',
//
// DestBufLen - length of buffer, typically supplied as sizeof(buf),
// dest must contain terminated string before function is called,
// function returns length of the new string
//
// ex: char buf[5] = "ab";
// ex: AppendStr(buf, "1234", sizeof(buf))
// ex: result after: buf[]: "ab12" - 4 characters and terminating '\0'
//
int AppendStr(char *dest, char *src, int DestBufLen)
{
	return AppendStrN(dest, src, DestBufLen, INT_MAX);
}

// function appends characters from src to the end of string in dest,
// function will not write behind end of dest buffer,
// function will always write terminating '\0',
// if not all characters fit then function copy as much as possible and terminates dest string with '\0',
//
// DestBufLen - length of buffer, typically supplied as sizeof(buf),
// dest must contain terminated string before function is called,
// maxSrcCharsToAppend - function will copy maximum this number of chars from src,
// function returns length of the new string
//
// ex: char buf[5] = "ab";
// ex: AppendStr(buf, "1234", sizeof(buf), INT_MAX)
// ex: result after: buf[]: "ab12" - 4 characters and terminating '\0'
//
int AppendStrN(char *dest, char *src, int DestBufLen, int maxSrcCharsToAppend)
{
	int len;
	int freeSpace;
	int charsToCopy;

	// get length of current value in dest
	len = strlen(dest);

	if(maxSrcCharsToAppend < 1)
		return len;

	// skip there there is no more space for at least one char and terminator
	freeSpace = DestBufLen - len;
	if(freeSpace < 2)
		return len;

	charsToCopy = freeSpace - 1;
	if(maxSrcCharsToAppend < charsToCopy)
		charsToCopy = maxSrcCharsToAppend;

	CopyStr(dest + len, src, charsToCopy);
	len += charsToCopy;

	return len;
}

// function appends text from src to dest. If maxSrcCharsToAppend is copied and there is no '\0' in src found yet, function appends '\0' to dest,
// as a consequence the maximum length of appended text is (maxSrcCharsToAppend+1) and the result will be always terminated with '\0'
// if maxSrcCharsToAppend is <= 0 then function writes '\0' only,
// this function is used to append strings that might not have terminating '\0' in specified number of chars,
//
// function returns number of chars printed not including '\0', this is the same as calling strlen(dest) after the function was called
int CopyStr(char *dest, char *src, int maxSrcCharsToAppend)
{
	char *p = dest;

	while(1)
	{
		// append terminator and return if we copied specified number of chars
		if(maxSrcCharsToAppend <= 0)
		{
			*p = '\0';
			return p - dest;
		}
		--maxSrcCharsToAppend;

		// copy next char and check if it is end of str
		*p = *src;
		if(*src == '\0')
			return p - dest;

		++p;
		++src;
	}
}


// function formats byte array as hex values separated by spaces and writes them to dest
// sctLen - number of bytes in source to process
// maxDestLen - maximum number of bytes to write to dest
// function always writes terminating '\0' such that it would fit to maxDestLen
// function returns numebr of chars written (this does not include terminating '\0')
int ByteArrayToHexStr(char *dest, char *src, int srcLen, int maxDestLen)
{
	int i;
	int ret;

	if(srcLen <= 0)
	{
		*dest = '\0';
		return 0;
	}

	// find out how many formated bytes will fit to dest
	// space after last formated value will be replaced with '\0' so we do not need extra space for '\0'
	i = maxDestLen / 3;			
	if(i < srcLen) srcLen = i;
	ret = srcLen * 3 - 1;

	// format all bytes
	while(srcLen--)
	{
		sprintf(dest, "%02X ", *src);
		++src;
		dest += 3;
	}

	// replace last space with '\0'
	*(dest-1) = '\0';
	return ret;
}

//
// function has similar behavior as ByteArrayToHexStr but does not print space between hex values
//
// sctLen - number of bytes in source to process
// maxDestLen - maximum number of bytes to write to dest
// function always writes terminating '\0' such that it would fit to maxDestLen
// function returns numebr of chars written (this does not include terminating '\0')
int ByteArrayToHexStrNoSpace(char *dest, char *src, int srcLen, int maxDestLen)
{
	int i;
	int ret;

	if(srcLen <= 0)
	{
		*dest = '\0';
		return 0;
	}

	// find out how many formated bytes will fit to dest
	i = maxDestLen / 2;			
	if(i < srcLen) srcLen = i;
	ret = srcLen * 2;

	// format all bytes
	while(srcLen--)
	{
		sprintf(dest, "%02X", *src);
		++src;
		dest += 2;
	}

	return ret;
}

// function returns value of specified hexadecinal digit or -1 if value is not hex character
int HexCharToValue(char c)
{
	if(c >= '0' && c <= '9')
		return c - '0';
	if(c >= 'A' && c <= 'F')
		return c - 'A' + 10;
	if(c >= 'a' && c <= 'f')
		return c - 'a' + 10;

	return -1;
}

// function converts strign with space separated hex values to byte array,
// function returns number of bytes stored or -1 on error
int HexStringToByteArray(char *dest, char *hexStr)
{
	int count = 0;
	int val;
	int cVal;

	while(1)
	{
		// skip space
		if(*hexStr == ' ') { ++hexStr; continue; }

		// exit if we are at the src end
		if(*hexStr == '\0')
			break;

		// check if this is hex digit
		cVal = HexCharToValue(*hexStr++);
		if(cVal < 0)
			return -1;
		val = cVal;

		// process if next char is also hex char
		cVal = HexCharToValue(*hexStr);
		if(cVal >= 0)
		{
			val = val << 4 | cVal;
			++hexStr;
		}

		// store value
		*dest++ = val;
		++count;

		// there should be a space or end of src here
		if(*hexStr == '\0')
			break;
		if(*hexStr != ' ')
			return -1;
	}

	return count;
}

//
// function will replace all occurences of c_old to c_new in the string
//
void StrReplace(char *s, char c_old, char c_new)
{
	while(*s != '\0')
	{
		if(*s == c_old)
			*s = c_new;

		++s;
	}
}

#pragma endregion

#pragma region split2words
// function will split string to words at separator string by:
// inserting '\0' at the place of each separator and filling array of pointers so that each points to the begining of next word,
// function fills maximum of maxWords in table of pointers (not to write pass allocated array for pointers),
//
// special case: separator = ' ' - split at white space, multiple white space chars together will be considered as one,
//								   white space at the beggining of text and at the end will be removed before spliting,
//
// function returns number of words found (if less or equal to maxWords),
// if function finds more then maxWords words it returns maxWords+1 to indicate this error condition,
// for empty text function will return 1 and one word with "",
//
int split2words(char *text, char separator, int maxWords, char **words)
{
	char *p = text;
	char *p1;
	int count = 0;

	if(separator == ' ')
	{
		// skip space at the begining
		p = SkipSpace(p);

		// remove space at the end
		trim(p);
	}

	while(1)
	{
		if(count < maxWords)
			*words++ = p;
		++count;
		if(count > maxWords)
			return count;

		if(separator == ' ')
		{
			p1=p;
			while(!isspace(*p1))
			{
				if(*p1 == '\0')
				{
					// did not find more separators - this is the last word
					return count;
				}
				++p1;
			}

			*p1 = '\0';

			// skip all white space chars
			p = p1 + 1;
			while(isspace(*p)) ++p;
		}
		else
		{
			p1 = strchr(p, separator);
			if(p1 == NULL)
			{
				// did not find more separators - this is last word
				return count;
			}

			*p1 = '\0';
			p = p1 + 1;
		}

	}
}
#pragma endregion

#pragma region trimWords
//
// trim each word in list
//
void trimWords(char **words, int count)
{
	int i;
	for(i=0; i<count; ++i)
	{
		trim(words[i]);
	}
}
#pragma endregion

#pragma region strcspn
////
//// return number fo characters in s1 that are not in s2, (return length of word in s1 before separator - separator chars are in s2)
////
//int strcspn(char *s1, char *s2)
//{
//	char *p, *spanp;
//	char c, sc;
//
//	/*
//	 * Stop as soon as we find any character from s2.  Note that there
//	 * must be a NUL in s2; it suffices to stop when we find that, too.
//	 */
//	for (p = s1;;) {
//		c = *p++;
//		spanp = s2;
//		do {
//			if ((sc = *spanp++) == c)
//				return (p - 1 - s1);
//		} while (sc != 0);
//	}
//	/* NOTREACHED */
//}
#pragma endregion

#pragma region LookupStrInt
//
// return one of multiple value for specified key,
// lookup data is stored as one string, items separated with ';' and values separated with ':',
// function will return as many values as are specified for found key,
//
// ex: data="vin:1:7;vout:4:0xa"
// for key "vout" function will store two integers: 4 and 10 and return 0
// 
// if keyIndex if not NULL, function will se it to index of found key,
// function returns numberof found and copied values,
//
int LookupStrInt(char *table, char *key, int *results, int *keyIndex)
{
	char *p = table;
	int keyLen = strlen(key);
	char valueStr[10];
	char *p1;
	char *p2;
	int i;
	int val;
	int count = 0;
	int index = 0;


	while(1)
	{
		if(strncasecmp(key, p, keyLen) == 0 && p[keyLen] == ':')
		{
			// found key
			// store index
			if(keyIndex != NULL)
				*keyIndex = index;
			
			// parse and copy values
			p += keyLen + 1;
			while(1)
			{
				i = strcspn(p, ":;");
				
				// get value string
				memcpy(valueStr, p, i);
				valueStr[i] = '\0';
				
				// parse
				val = (int) strtol(valueStr, NULL, 0);

				// copy result
				*results++ = val;
				++count;

				p += i;
				if(*p == '\0' || *p == ';')
					return count;
				++p;
			}

		}

		// move to next key
		p = strchr(p, ';');
		if(p == NULL)
			return 0;
		
		++index;
		++p;
	}
}
#pragma endregion

#pragma region Adler32
//
// calculate  crc usign adler-32 method
//
unsigned int Adler32(unsigned char *p, int len)
{
	unsigned a = 1;
	unsigned b = 0;
	int tlen;
	unsigned int crc;

	while (len > 0)
	{
        tlen = len > 5552 ? 5552 : len;
        len -= tlen;
        do 
        {
            a += *p++;
            b += a;

        } while (--tlen);

        a %= 65521;
        b %= 65521;
	}

	crc = (b << 16) | a;
	return crc;
}
#pragma endregion

#if 0
#pragma region SqrtF()
//
// fast, aproximate square root calcuation for float,
// precise to around 5 valid digits
//
float SqrtF(float number)
{
    long i;
    float x, y;
    const float f = 1.5F;

    x = number * 0.5F;
    y  = number;
    i  = * ( long * ) &y;
    i  = 0x5f3759df - ( i >> 1 );
    y  = * ( float * ) &i;
    y  = y * ( f - ( x * y * y ) );
    y  = y * ( f - ( x * y * y ) );
    return number * y;
}
#pragma endregion
#endif

#pragma region Median
//
//  Algorithm by Torben Mogensen
//
calcMedianType CalcMedian(calcMedianType m[], int n) 
{
    int         i, less, greater, equal;
    calcMedianType  min, max, guess, maxltguess, mingtguess;

    min = max = m[0] ;
    for (i=1 ; i<n ; i++) {
        if (m[i]<min) min=m[i];
        if (m[i]>max) max=m[i];
    }

    while (1) {
        guess = (min+max)/2;
        less = 0; greater = 0; equal = 0;
        maxltguess = min ;
        mingtguess = max ;
        for (i=0; i<n; i++) {
            if (m[i]<guess) {
                less++;
                if (m[i]>maxltguess) maxltguess = m[i] ;
            } else if (m[i]>guess) {
                greater++;
                if (m[i]<mingtguess) mingtguess = m[i] ;
            } else equal++;
        }
        if (less <= (n+1)/2 && greater <= (n+1)/2) break ; 
        else if (less>greater) max = maxltguess ;
        else min = mingtguess;
    }
    if (less >= (n+1)/2) return maxltguess;
    else if (less+equal >= (n+1)/2) return guess;
    else return mingtguess;
}

#pragma endregion

#pragma region CheckValueLL(), CheckValueULL()
//
// function returns 0 if specified value fits to integer with specified length,
// function returns 1 if it does not fit
//
int CheckValueLL(long long n, int numberOfBytes)
{
	long long mask;

	if(numberOfBytes > 7)
		return 0;

	mask = (1LL << (numberOfBytes * 8)) - 1;
	mask >>= 1;

	if(n >= 0)
	{
		return (n & ~mask) == 0 ? 0 : 1;
	}
	else
	{
		return (n | mask) == -1LL ? 0 : 1;
	}
}

//
// function returns 0 if specified value fits to unsigned integer with specified length,
// function returns 1 if it does not fit
//
int CheckValueULL(unsigned long long n, int numberOfBytes)
{
	unsigned long long mask;

	if(numberOfBytes > 7)
		return 0;

	mask = (1ULL << (numberOfBytes * 8)) - 1;

	return (n & ~mask) == 0 ? 0 : 1;
}

#pragma endregion

#if 0
#pragma region CalcAvgF
//
// calculate average
//
float CalcAvgF(float *p, int count)
{
	int i = count;
	float sum = 0.0f;

	while(i--) sum += *p++;
	return sum / (float)count;
}
#pragma endregion
#endif

#pragma region Int2StrLookup()
//
// function does int to string lookup
//
// lookup function must be defined like this:
//
//Int2StrLookupItem evenIdNames[] = {
//	{0x067f, "GAP_HCI_ExtentionCommandStatus"},
//	{0x0600, "GAP_DeviceInitDone"},
//	{0x0601, "GAP_DeviceDiscoveryDone"},
//	{0, NULL},
//};
//
// last item in table must be {xxx, NULL}
//
// function returns pointer to string matching specified int value,
// function returns NULL if not found
//
//
char * Int2StrLookup(Int2StrLookupItem *p, int value)
{
	while(p->name != NULL)
	{
		if(p->value == value)
			return (char *)p->name;

		++p;
	}

	// not found
	return (char *)NULL;
}
#pragma endregion

#pragma region Int2IntLookup()
//
//
// function searches for specified value and sets *result to matching items from the same line as searched item 
//
// if searchMode is I2IL_SEARCH_KEYS_RETURN_VALUES then function looks for key (items on odd indexes) and return matching value
// if searchMode is I2IL_SEARCH_VALUES_RETURN_KEYS then function looks for values (items on even indexes) and return matching key
//
// if search items is not found then *result is set to value specified in notFoundValue and function returns -1
// if item is found function returns index of line on witch the item was found, for example below, function woudl return 0 if key1 was searched for and 1 if key2 was searched for
//
// dictNumberOfLines is number of lines in dictionary the function shoudl search for (2 in example below)
//
// int dict[] = {
//	key1, value1,
//	key2, value2
//	};
//
// indexInDict = Int2In2Lookup(dict, sizeof(dict) / 8, I2IL_SEARCH_KEYS_RETURN_VALUES, intToSearchFor, *pResult)
//
//
int Int2IntLookup(int *dictionary, int dictNumberOfLines, int searchMode, int pattern, int notFoundValue, int *result)
{
	int i;

	if(searchMode == I2IL_SEARCH_KEYS_RETURN_VALUES)
	{
		// seach for specified key
		for(i=0; i<dictNumberOfLines; ++i)
		{
			if(dictionary[i * 2] == pattern)
			{
				*result = dictionary[i * 2 + 1];
				return i;
			}
		}
	}
	else
	{
		// seach for specified value
		for(i=0; i<dictNumberOfLines; ++i)
		{
			if(dictionary[i * 2 + 1] == pattern)
			{
				*result = dictionary[i * 2];
				return i;
			}
		}
	}

	// not found
	*result = notFoundValue;
	return -1;

}
#pragma endregion

#if 0
#pragma region Sin2
//
// approximate Sin() calculation
// max error: 0.00109
//
// input in radians between 0 and 2*pi (little bit outside of this range will still return good results)
// output -1.0 to 1.0
//
// http://forum.devmaster.net/t/fast-and-accurate-sine-cosine/9648
// 
float Sin2(float x)
{
    const float pi = 3.1415927f;
    const float B = 4.0f / pi;
    const float C = -4.0f / (pi * pi);
    const float P = 0.225f;
    float y;

    if (x > pi)   // Original x > pi/2
    {
        x -= 2 * pi;   // Wrap: cos(x) = cos(x - 2 pi)
    } 
    
    y = B * x + C * x * (x >= 0.0 ? x : -x);
    y = P * (y * (y >= 0.0 ? y : -y) - y) + y;   // Q * y + P * y * abs(y)

    return y;
}
#pragma endregion
#endif

#pragma region SuperFastHash()
//
// Function calcuates hash code for specified data
// based on algorithm: Paul Hsieh
// http://www.azillionmonkeys.com/qed/hash.html
//
#undef SFH_get16bits
#define SFH_get16bits(d) (*((const unsigned short *) (d)))

unsigned SuperFastHash(const char * data, int len) 
{
	unsigned hash = len, tmp;
	int rem;

	if (len <= 0 || data == NULL) return 0;

	rem = len & 3;
	len >>= 2;

	/* Main loop */
	for (; len > 0; len--) {
		hash += SFH_get16bits(data);
		tmp = (SFH_get16bits(data + 2) << 11) ^ hash;
		hash = (hash << 16) ^ tmp;
		data += 2 * sizeof(unsigned short);
		hash += hash >> 11;
	}

	/* Handle end cases */
	switch (rem) {
	case 3: hash += SFH_get16bits(data);
		hash ^= hash << 16;
		hash ^= ((signed char)data[sizeof(unsigned short)]) << 18;
		hash += hash >> 11;
		break;
	case 2: hash += SFH_get16bits(data);
		hash ^= hash << 11;
		hash += hash >> 17;
		break;
	case 1: hash += (signed char)*data;
		hash ^= hash << 10;
		hash += hash >> 1;
	}

	/* Force "avalanching" of final 127 bits */
	hash ^= hash << 3;
	hash += hash >> 5;
	hash ^= hash << 4;
	hash += hash >> 17;
	hash ^= hash << 25;
	hash += hash >> 6;

	return hash;
}
#pragma endregion

#pragma region ReadChipId(), CalcLicenseCode()
//
// function reads 12 bytes long unique micro serial number
//
void ReadChipId(char *dest)
{
	memcpy(dest, (void *)SERIAL_NUMBER_ADR, 12);
}

//
// function calcualate value of license code from specified project number (32 bits), licenseType (32 bits) and micro serial number (96 bits)
//
unsigned CalcLicenseCode(unsigned project, unsigned licenseType)
{
	char buf[4 + 4 + 12];
	memcpy(buf, &project, 4);
	memcpy(buf + 4, &licenseType, 4);
	ReadChipId(buf + 8);

	unsigned hash = SuperFastHash(buf, 4 + 4 + 12);
	return hash;
}
#pragma endregion