#include "stm32l0xx_hal.h"
#include "intr.h"
#include "vars.h"
#include "debug.h"
#include "string.h"
#include "lib.h"
#include "A7129reg.h"
#include "stm32l0xx_ll_bus.h"
#include "stm32l0xx_ll_gpio.h"
#include "stm32l0xx_ll_system.h"
#include "stm32l0xx_ll_spi.h"
#include "main.h"

#pragma region logging macros
// 
#define loge(args...) Log(LOG_SEV_ERROR, LOG_INTR, args)
#define logw(args...) Log(LOG_SEV_WARNING, LOG_INTR, args)
#define logp(args...) Log(LOG_SEV_PROCESS, LOG_INTR, args)
#pragma endregion

#pragma region Init()
//
// initilaize ports, ...
//
void Initialize(void)
{
	// init vars

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* Configure the system clock */
	SystemClock_Config();

	// set default values for output pins

	/* Initialize all configured peripherals */
	MX_GPIO_Init();

	// init peripherals DMA
	MX_DMA_Init();

	// init timers
	MX_LPTIM1_Init();
	MX_TIM2_Init();		// log time stamp
	MX_TIM21_Init();	// 1ms periodic interrupt
	MX_TIM22_Init();	// timer used by Wait()

	MX_LPUART1_UART_Init();	// debugger connection
	MX_USART2_UART_Init();	// PC connection

	// configure debugging and UART for debugging
	DbgInit();

	// ADC
	MX_ADC_Init();

	// SPI
	MX_SPI1_Init();

	#pragma region set all interrupt priorities

	
	// LPUART1 - debugger
	HAL_NVIC_SetPriority(DMA1_Channel2_3_IRQn, 8, 0); // LPUART1-DMA TX, low priority

	// USART2 - PC connection
	HAL_NVIC_SetPriority(DMA1_Channel4_5_6_7_IRQn, 9, 0); // USART2-DMA PC TX, low priority

	// ADC1
	HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 11, 0);	// ADC1, very low priority

	// TIM2
	HAL_NVIC_SetPriority(TIM2_IRQn, 0, 0);	// log time stamp timer overflow interrupt - highest priority

	// TIM21
	HAL_NVIC_SetPriority(TIM21_IRQn, 13, 0);	// 1milisec periodic interrupt, very low priority


	
	#pragma endregion

}


#pragma endregion

#pragma region HAL Driver Init Functions

#if stm32l_053
void SystemClock_Config(void)
{
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };
	RCC_PeriphCLKInitTypeDef PeriphClkInit = { 0 };

	/** Configure the main internal regulator output voltage
	*/
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
	/** Initializes the RCC Oscillators according to the specified parameters
	* in the RCC_OscInitTypeDef structure.
	*/
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLMUL = RCC_PLLMUL_8;
	RCC_OscInitStruct.PLL.PLLDIV = RCC_PLLDIV_2;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	/** Initializes the CPU, AHB and APB buses clocks
	*/
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
		| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2 | RCC_PERIPHCLK_LPUART1;
	PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
	PeriphClkInit.Lpuart1ClockSelection = RCC_LPUART1CLKSOURCE_PCLK1;
	if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
}
#else
void SystemClock_Config(void)
{
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };
	RCC_PeriphCLKInitTypeDef PeriphClkInit = { 0 };

	/** Configure the main internal regulator output voltage
	*/
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
	/** Configure LSE Drive Capability
	*/
	HAL_PWR_EnableBkUpAccess();
	__HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

	// initialize HSI first by inteself
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.LSEState = RCC_LSE_ON;
	RCC_OscInitStruct.HSIState = RCC_HSI_DIV4;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
	RCC_OscInitStruct.PLL.PLLMUL = RCC_PLLMUL_16;
	RCC_OscInitStruct.PLL.PLLDIV = RCC_PLLDIV_2;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	// try to initialize HSE too, continue if it failed
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		LSE_InitFailed = 1;
		//_Error_Handler(__FILE__, __LINE__);
	}

	/** Initializes the CPU, AHB and APB buses clocks
	*/
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
		| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2 | RCC_PERIPHCLK_LPUART1
		| RCC_PERIPHCLK_I2C1 | RCC_PERIPHCLK_RTC;
	PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
	PeriphClkInit.Lpuart1ClockSelection = RCC_LPUART1CLKSOURCE_PCLK1;
	PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
	PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSE;
	if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
}

#endif

/**
  * @brief LPTIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_LPTIM1_Init(void)
{

	/* USER CODE BEGIN LPTIM1_Init 0 */

	/* USER CODE END LPTIM1_Init 0 */

	/* USER CODE BEGIN LPTIM1_Init 1 */

	/* USER CODE END LPTIM1_Init 1 */
	hlptim1.Instance = LPTIM1;
	hlptim1.Init.Clock.Source = LPTIM_CLOCKSOURCE_APBCLOCK_LPOSC;
	hlptim1.Init.Clock.Prescaler = LPTIM_PRESCALER_DIV1;
	hlptim1.Init.Trigger.Source = LPTIM_TRIGSOURCE_SOFTWARE;
	hlptim1.Init.OutputPolarity = LPTIM_OUTPUTPOLARITY_HIGH;
	hlptim1.Init.UpdateMode = LPTIM_UPDATE_IMMEDIATE;
	hlptim1.Init.CounterSource = LPTIM_COUNTERSOURCE_INTERNAL;
	if (HAL_LPTIM_Init(&hlptim1) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	/* USER CODE BEGIN LPTIM1_Init 2 */

	/* USER CODE END LPTIM1_Init 2 */

}

//
// lpuart is used by debugger
//
static void MX_LPUART1_UART_Init(void)
{

	hlpuart1.Instance = LPUART1;
	hlpuart1.Init.BaudRate = 2000000; // 2 MBit is valid only if timer clk is 8 MHz or more. Use 1Mbit for 4MHz timer clock
	hlpuart1.Init.WordLength = UART_WORDLENGTH_8B;
	hlpuart1.Init.StopBits = UART_STOPBITS_1;
	hlpuart1.Init.Parity = UART_PARITY_NONE;
	hlpuart1.Init.Mode = UART_MODE_TX_RX;
	hlpuart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	hlpuart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_ENABLE;
	hlpuart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_DMADISABLEONERROR_INIT;
	hlpuart1.AdvancedInit.DMADisableonRxError = UART_ADVFEATURE_DMA_DISABLEONRXERROR;
	if (HAL_UART_Init(&hlpuart1) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	__HAL_UART_ENABLE(&hlpuart1);

	// enable DMA_TC interrupt for TX only
	__HAL_DMA_DISABLE_IT(&hdma_lpuart1_tx, DMA_IT_HT | DMA_IT_TE);
	__HAL_DMA_ENABLE_IT(&hdma_lpuart1_tx, DMA_IT_TC);
	__HAL_DMA_DISABLE_IT(&hdma_lpuart1_rx, DMA_IT_TC | DMA_IT_HT | DMA_IT_TE);

	// enable DMA
	__HAL_DMA_ENABLE(&hdma_lpuart1_tx);
	__HAL_DMA_ENABLE(&hdma_lpuart1_rx);
}

//
// UART2 used by PC conenction
//
static void MX_USART2_UART_Init(void)
{

	huart2.Instance = USART2;
	huart2.Init.BaudRate = 115200;
	huart2.Init.WordLength = UART_WORDLENGTH_8B;
	huart2.Init.StopBits = UART_STOPBITS_1;
	huart2.Init.Parity = UART_PARITY_NONE;
	huart2.Init.Mode = UART_MODE_TX_RX;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_RXOVERRUNDISABLE_INIT | UART_ADVFEATURE_DMADISABLEONERROR_INIT;
	huart2.AdvancedInit.OverrunDisable = UART_ADVFEATURE_OVERRUN_DISABLE;
	huart2.AdvancedInit.DMADisableonRxError = UART_ADVFEATURE_DMA_DISABLEONRXERROR;
	if (HAL_UART_Init(&huart2) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	__HAL_UART_ENABLE(&huart2);

	// enable DMA
	//__HAL_DMA_ENABLE(&hdma_usart2_tx);
	//__HAL_DMA_ENABLE(&hdma_usart2_rx);

	PC_StartRx();
}

//
// Log() time stamp
//
static void MX_TIM2_Init(void)
{
	TIM_ClockConfigTypeDef sClockSourceConfig = { 0 };
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };

	htim2.Instance = TIM2;
	htim2.Init.Prescaler = (uint16_t)((SystemCoreClock) / 1000000) - 1;
	htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim2.Init.Period = 0xffff;
	htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	// start timer
	HAL_TIM_Base_Start_IT(&htim2);
}

//
// TIM21 - 1ms periodic interrupt
//
static void MX_TIM21_Init(void)
{
	TIM_ClockConfigTypeDef sClockSourceConfig = { 0 };
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };

	htim21.Instance = TIM21;
	htim21.Init.Prescaler = (uint16_t)((SystemCoreClock) / 1000000) - 1;
	htim21.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim21.Init.Period = 1000 - 1;
	htim21.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim21.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim21) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim21, &sClockSourceConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim21, &sMasterConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	
	HAL_TIM_Base_Start_IT(&htim21);
}

static void MX_TIM22_Init(void)
{
	TIM_ClockConfigTypeDef sClockSourceConfig = { 0 };
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };

	htim22.Instance = TIM22;
	htim22.Init.Prescaler = 1;
	htim22.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim22.Init.Period = 1;
	htim22.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim22.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim22) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim22, &sClockSourceConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim22, &sMasterConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = { 0 };

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOH_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();

	ConfPortAsOutputPP(STAT_LED, 0);
	ConfPortAsOutputPP(LED2, 0);
	//ConfPortAsOutputPP(DBG1, 0);
	//ConfPortAsOutputPP(DBG2, 0);
	ConfPortAsInput(GPIO1, GPIO_PULLDOWN);
	ConfPortAsInput(GPIO2, GPIO_PULLDOWN);

	//ConfPortAsInput(BUTTON, GPIO_NOPULL);

	ConfPortAsOutputPP(VINMEASCTRL, 0); // low to turn on
	ConfPortAsOutputPP(CTRL, 1);		// hi to turn on
	ConfPortAsOutputPP(SCS, 1);			// hi is idle

	ConfPortAsOutputPP(TIM2CH1, 0);
	ConfPortAsOutputPP(TIM2CH2, 0);
	ConfPortAsOutputPP(MOT_EN, 0);
}

void _Error_Handler(char *file, int line)
{
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	ErrorHandlerLine = line;
	loge("ENTERED _Error_Handler(): %s: %d", file, line);
	while (1)
	{
		;
	}
	/* USER CODE END Error_Handler_Debug */
}

static void MX_DMA_Init(void)
{

	/* DMA controller clock enable */
	__HAL_RCC_DMA1_CLK_ENABLE();

	/* DMA interrupt init */
	/* DMA1_Channel2_3_IRQn interrupt configuration */
	// this is used by debug port LPUART1
	HAL_NVIC_SetPriority(DMA1_Channel2_3_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(DMA1_Channel2_3_IRQn);

	/* DMA interrupt init */
	/* DMA1_Channel4_5_6_7_IRQn interrupt configuration */
	// this is used by USART2 PC conenction
	HAL_NVIC_SetPriority(DMA1_Channel4_5_6_7_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(DMA1_Channel4_5_6_7_IRQn);

	/* DMA1_Channel1_IRQn interrupt configuration */
	// ADC
	HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

static void MX_ADC_Init(void)
{
	ADC_ChannelConfTypeDef sConfig = { 0 };


	// read Vref calibration value from system memory, shift to have this right aligned as ADC counts 
	VrefIntCal = *((unsigned short*)0x1ff80078) << 4;

	hadc.Instance = ADC1;
	hadc.Init.OversamplingMode = DISABLE;
	hadc.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV8;
	hadc.Init.Resolution = ADC_RESOLUTION_12B;
	hadc.Init.SamplingTime = ADC_SAMPLETIME_160CYCLES_5;
	hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
	hadc.Init.DataAlign = ADC_DATAALIGN_LEFT; // ADC_DATAALIGN_RIGHT;
	hadc.Init.ContinuousConvMode = ENABLE; // DISABLE;
	hadc.Init.DiscontinuousConvMode = DISABLE;
	hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	hadc.Init.DMAContinuousRequests = ENABLE; // DISABLE;
	hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	hadc.Init.Overrun = ADC_OVR_DATA_PRESERVED;
	hadc.Init.LowPowerAutoWait = DISABLE;
	hadc.Init.LowPowerFrequencyMode = DISABLE;
	hadc.Init.LowPowerAutoPowerOff = DISABLE;
	if (HAL_ADC_Init(&hadc) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	// calibrate ADC
	if (HAL_ADCEx_Calibration_Start(&hadc, ADC_SINGLE_ENDED) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	// configure channels
	sConfig.Channel = ADC_CHANNEL_0;
	sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	sConfig.Channel = ADC_CHANNEL_1;
	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	sConfig.Channel = ADC_CHANNEL_4;
	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	sConfig.Channel = ADC_CHANNEL_6;
	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	sConfig.Channel = ADC_CHANNEL_7;
	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	sConfig.Channel = ADC_CHANNEL_VREFINT;
	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	// start conversions
	if (HAL_ADC_Start_DMA(&hadc, (uint32_t*)&Adc1DmaBuf, 6) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}

	// disable half transfer interrupt
	__HAL_DMA_DISABLE_IT(&hdma_adc, DMA_IT_HT);
}

static void MX_SPI1_Init(void)
{

#if 0
	hspi1.Instance = SPI1;
	hspi1.Init.Mode = SPI_MODE_MASTER;
	hspi1.Init.Direction = SPI_DIRECTION_1LINE;
	hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
	hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
	hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
	hspi1.Init.NSS = SPI_NSS_SOFT;
	hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_32;
	hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
	hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
	hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	hspi1.Init.CRCPolynomial = 7;
	if (HAL_SPI_Init(&hspi1) != HAL_OK)
	{
		_Error_Handler(__FILE__, __LINE__);
	}
#endif

	LL_SPI_InitTypeDef SPI_InitStruct = { 0 };

	LL_GPIO_InitTypeDef GPIO_InitStruct = { 0 };

	/* Peripheral clock enable */
	LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_SPI1);

	LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOB);
	/**SPI1 GPIO Configuration
	PB13   ------> SPI1_SCK
	PB15   ------> SPI1_MOSI
	*/
	GPIO_InitStruct.Pin = LL_GPIO_PIN_13;
	GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
	GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
	GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
	GPIO_InitStruct.Alternate = LL_GPIO_AF_0;
	LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = LL_GPIO_PIN_15;
	GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
	GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
	GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
	GPIO_InitStruct.Alternate = LL_GPIO_AF_0;
	LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/* SPI1 parameter configuration*/
	SPI_InitStruct.TransferDirection = LL_SPI_HALF_DUPLEX_TX;
	SPI_InitStruct.Mode = LL_SPI_MODE_MASTER;
	SPI_InitStruct.DataWidth = LL_SPI_DATAWIDTH_8BIT;
	SPI_InitStruct.ClockPolarity = LL_SPI_POLARITY_LOW;
	SPI_InitStruct.ClockPhase = LL_SPI_PHASE_1EDGE;
	SPI_InitStruct.NSS = LL_SPI_NSS_SOFT;
	SPI_InitStruct.BaudRate = LL_SPI_BAUDRATEPRESCALER_DIV4; // LL_SPI_BAUDRATEPRESCALER_DIV4;
	SPI_InitStruct.BitOrder = LL_SPI_MSB_FIRST;
	SPI_InitStruct.CRCCalculation = LL_SPI_CRCCALCULATION_DISABLE;
	SPI_InitStruct.CRCPoly = 7;
	LL_SPI_Init(SPI1, &SPI_InitStruct);
	LL_SPI_SetStandard(SPI1, LL_SPI_PROTOCOL_MOTOROLA);

	LL_SPI_Enable(SPI1);

}

#pragma endregion

#pragma region HAL Interrupt Handlers

/**
* @brief This function handles System tick timer.
*/
void SysTick_Handler(void)
{
	HAL_IncTick();
}

//
// TIM2 - log time stamp timer overflow
//
void TIM2_IRQHandler(void)
{
	__HAL_TIM_CLEAR_IT(&htim2, TIM_IT_UPDATE);
	++Tim2HighCnt;
}

//
// function handles LPUART1 DMA interrupts
//
void DMA1_Channel2_3_IRQHandler(void)
{
	HAL_DMA_IRQHandler(&hdma_lpuart1_tx);
	HAL_DMA_IRQHandler(&hdma_lpuart1_rx);

	// enable receive
	dbg_TxTimer = 0;
	EnableDebugRx();
}

//
// function handles USART2 DMA interrupts
//
void DMA1_Channel4_5_6_7_IRQHandler(void)
{
	if (__HAL_DMA_GET_FLAG(&hdma_usart2_tx, __HAL_DMA_GET_TC_FLAG_INDEX(&hdma_usart2_tx)) != 0)
	{
		PC_TxActive = 0;
	}

	HAL_DMA_IRQHandler(&hdma_usart2_tx);
	HAL_DMA_IRQHandler(&hdma_usart2_rx);
}

//
// ADC1 DMA interrupt
//
// When running on internal HSI/PLL at 32MHZ ADC clock, DMA interrutps peiord is aprox 2.08 milisec. Functiontakes around 48 us to execute
//
// Adc1DmaBuf[0]: Vin
// Adc1DmaBuf[1]: T3
// Adc1DmaBuf[2]: MotCurrent
// Adc1DmaBuf[3]: T1
// Adc1DmaBuf[4]: T2
// Adc1DmaBuf[5]: Vref
//
void DMA1_Channel1_IRQHandler(void)
{
	int i;
	unsigned alpha;
	unsigned beta;
	unsigned val;

	//SetPortBit1(DBG2, 1);

	if (__HAL_DMA_GET_FLAG(&hdma_adc, __HAL_DMA_GET_TC_FLAG_INDEX(&hdma_adc)) == 0)
		goto End;

	++Adc1DmaInterruptCounter;

	#pragma region apply filter

	if (Adc1FilterCounter < 100)
	{
		// load first measuremnt straing to init filter
		for (i = 0; i < 6; ++i)
		{
			Adc1FilteredCounts[i] = Adc1DmaBuf[i];
		}
		++Adc1FilterCounter;
	}
	else
	{
		// apply filter
		for (i = 0; i < 6; ++i)
		{
			// out = alpha * (prev + 0.5 counts) + beta * in
			// alpha is fitler constant from eeprom, 0-no filter, 0xffff-max filter
			// beta = 1 - alpha
			alpha = ee.AdcFilter[i];
			beta = 65536 - alpha;
			Adc1FilteredCounts[i] = (unsigned short)(((alpha * ((unsigned)Adc1FilteredCounts[i] + (unsigned)(Adc1DmaInterruptCounter & 0x01))) + (beta * (unsigned)Adc1DmaBuf[i])) >> 16);
		}

	}
	#pragma endregion

	// Vdda voltage in mv calcuated from measuring internal Vref and using STM calibration value from system memory
	Vdda = ((unsigned)VrefIntCal * 3000u) / ((unsigned)Adc1FilteredCounts[5]);

	// calc temperatures
	val = Adc1FilteredCounts[3];
	t1 = (unsigned short)(val * val / 2225476u + ((val * 6774) >> 16) - 1369 + (unsigned)ee.TempAdjust[0]);
	val = Adc1FilteredCounts[4];
	t2 = (unsigned short)(val * val / 2225476u + ((val * 6774) >> 16) - 1369 + (unsigned)ee.TempAdjust[1]);
	val = Adc1FilteredCounts[1];
	t3 = (unsigned short)(val * val / 2225476u + ((val * 6774) >> 16) - 1369 + (unsigned)ee.TempAdjust[2]);

	// calc Vin
	Vin = (unsigned short)(   (  ((unsigned)Adc1FilteredCounts[0] * VrefIntCal / (unsigned)Adc1FilteredCounts[5]) * 3000u) >> 15);

	// calc MotCurrent in mA
	const unsigned shunt_estimated_resistance = 53;
	MotCurrentMA = (unsigned short)((((unsigned)Adc1DmaBuf[2] * VrefIntCal / (unsigned)Adc1FilteredCounts[5]) * (3000u * 1000u / shunt_estimated_resistance)) >> 16);

	End:
	HAL_DMA_IRQHandler(&hdma_adc);
	//SetPortBit1(DBG2, 0);
}

#pragma endregion

#pragma region ConfPortAsInput(), ConfPortAsOutputPP()

//
// funxtion will retirmn one of GPIOA pointers matching specified port index
//
GPIO_TypeDef* GetPortAdr(int port)
{
	GPIO_TypeDef  *GPIOx;

	switch (port)
	{
	case PORT_A: GPIOx = GPIOA; break;
	case PORT_B: GPIOx = GPIOB; break;
	case PORT_C: GPIOx = GPIOC; break;
	//case PORT_D: GPIOx = GPIOD; break;
	//case PORT_E: GPIOx = GPIOE; break;
	//case PORT_F: GPIOx = GPIOF; break;
	//case PORT_G: GPIOx = GPIOG; break;
	case PORT_H: GPIOx = GPIOH; break;
	default: GPIOx = GPIOH; break;
	}

	return GPIOx;
}

//
// configure pin as input
// pullups: GPIO_NOPULL, GPIO_PULLUP or GPIO_PULLDOWN
//
void ConfPortAsInput(int portbit, int pullups)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_TypeDef  *GPIOx;

	int port = PORTBIT_GET_PORT(portbit);
	int bit = PORTBIT_GET_BIT(portbit);

	GPIO_InitStruct.Pin = 1 << bit;				//GPIO_PIN_5;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = pullups;

	GPIOx = GetPortAdr(port);

	HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

//
// Configure pin as push-pull output and set it to specified state
//
void ConfPortAsOutputPP(int portbit, int outputState)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_TypeDef  *GPIOx;

	int port = PORTBIT_GET_PORT(portbit);
	int bit = PORTBIT_GET_BIT(portbit);

	GPIO_InitStruct.Pin = 1 << bit;				//GPIO_PIN_5;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;

	GPIOx = GetPortAdr(port);

	// set pin poutput state before and after
	SetPortBit1(portbit, outputState);

	HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);

	SetPortBit1(portbit, outputState);
}


#pragma endregion 

#pragma region ReadPortBit1()
//
// return value of specified port bit
//
// portbit shoudl be create using PORTBIT() macro
int ReadPortBit1(int portbit)
{
	int port = PORTBIT_GET_PORT(portbit);
	int bit = PORTBIT_GET_BIT(portbit);
	return (((GPIO_TypeDef *)(GPIOA_BASE + (0x0400 * port)))->IDR & (1 << bit)) == 0 ? 0 : 1;
}
#pragma endregion

#pragma region 1 milisecond interrupt TIM6

// https://stackoverflow.com/questions/38618440/retrieving-return-address-of-an-exception-on-arm-cortex-m0
__attribute__((naked)) void TIM21_IRQHandler()
{
	asm volatile (
		"MRS R0, MSP\n\t"
		"MOV R1, LR\n\t"
		"MOV R2, #4\n\t"
		"TST R1, R2\n\t"
		"BEQ call_c_func\n\t"
		"MRS R0, PSP\n"
		"call_c_func:\n\t"
		"LDR R1, =TIM21_IRQHandler_c\n\t"
		"BX  R1"
		);
}

//
// 1 milisecond interrupt
//
void TIM21_IRQHandler_c(uint32_t* sp)
{
	// get address of PC before this interrupt handler was called - this is code address that was running before the handler was triggered
	dm_pc1 = sp[6];

	//SetPortBit1(DBG1, 1);

	__HAL_TIM_CLEAR_IT(&htim21, TIM_IT_UPDATE);

	++lowInterruptCounter;
	if (Led1BlinkTimer)
	{
		// turn off LED when timer gets to 0
		--Led1BlinkTimer;
		if (Led1BlinkTimer == 0)
			SetPortBit1(STAT_LED, 0);
	}
	if (Led2BlinkTimer)
	{
		// turn off LED when timer gets to 0
		--Led2BlinkTimer;
		if (Led2BlinkTimer == 0)
			SetPortBit1(LED2, 0);
	}
	if (Gpio2Timer) --Gpio2Timer;
	if (TxDelayTimer) --TxDelayTimer;
	if (PeriodicMsgTimer) --PeriodicMsgTimer;
	if (Timer1) --Timer1;

	// MM logic 
	MM_Logic();

	// process debuger Rx and Tx logic
	DbgRxTx();

	gpio1 = ReadPortBit1(GPIO1);
	gpio2 = ReadPortBit1(GPIO2);

	// motor code
	Mot_Logic();

	//SetPortBit1(DBG1, 0);
}

#pragma endregion

#pragma region Flash functions
// convert int version to string
// will copy "v2.13A" for 0x213a
void ConvVerInt2Str(char* dest, int ver)
{
	if (ver < 0x000a)
	{
		strcpy(dest, "v?.???");
		return;
	}

	*dest++ = 'v';
	*dest++ = '0' + ((ver >> 12) & 0x0f);
	*dest++ = '.';
	*dest++ = '0' + ((ver >> 8) & 0x0f);
	*dest++ = '0' + ((ver >> 4) & 0x0f);
	*dest++ = 'A' + ((ver >> 0) & 0x0f) - 0xa;
	*dest = '\0';
}
#pragma endregion

#pragma region Wait()
void Wait(int microsec)
{
	uint16_t period;

#define WAIT_OVERHEAD_US 11 // it takes this time for this function to process commands
							// overhead for STM32L0 running at 32MHz and optimized for speed: around 11.9 us 

	// freq after prescaler = 1 MHz
	uint16_t PrescalerValue = (uint16_t)((SystemCoreClock) / 1000000);

	// compensate for function code overhead
	microsec -= WAIT_OVERHEAD_US;

	// select range
	if (microsec < 2)
	{
		// value 2 is shortest the timer can wait, with value 0 it waits 65535
		// for some reason with value 1 it never reaches target
		period = 2;
	}
	else if (microsec <= 65535)
	{
		// after prescaler 1 count = 1 microsec
		period = microsec;
	}
	else if (microsec <= (65535 << 4))
	{
		// up to 1.048 seconds
		// after prescaler 1 count = 16 microsec
		period = microsec >> 4;
		PrescalerValue <<= 4;
	}
	else if (microsec <= (65535 << 9))
	{
		// up to 33.55 seconds
		// after prescaler 1 count = 512 microsec
		period = microsec >> 9;
		PrescalerValue <<= 9;
	}
	else
	{
		// invalid value - wait as long as possible (aprox 51.1 sec)
		period = 0xffff;
		PrescalerValue = 0xffff;
	}

	//log("Wait(): microsec: %d, prescaler: %d, period: %d", microsec, PrescalerValue, period);


	// disable counter
	TIM_HandleTypeDef *htim = &htim22;
	__HAL_TIM_DISABLE(htim);

	// configure
	TIM_MasterConfigTypeDef sMasterConfig;
	htim->Instance = TIM22;
	htim->Init.Prescaler = PrescalerValue - 1;
	htim->Init.CounterMode = TIM_COUNTERMODE_UP;
	htim->Init.Period = period - 1;
	HAL_TIM_OnePulse_Init(htim, TIM_OPMODE_SINGLE);

	// clear update flag
	__HAL_TIM_CLEAR_FLAG(htim, TIM_FLAG_UPDATE);

	// TIM enable counter
	__HAL_TIM_ENABLE(htim);


	// wait until the pulse is done
	while (!__HAL_TIM_GET_FLAG(htim, TIM_FLAG_UPDATE));
}

//
// function waits minimum 1 microsecond but it might take few microseconds if interrupts are running
// in average function takes 2.3 microsec
//
void Wait1MicroSec()
{
	Wait(1);
}

//
// function waits minimum 200 ns but it might take much longer if interrupts are running
//
void Wait200NanoSec()
{
	nop();
}

#pragma endregion

#pragma region PC

//
// Function will appends "\r\n" and send string to PC
// message must be preapred in PC_TxBuf[] before the function is called
//
void PC_Send()
{
	int len;
	int logLen;

	len = strlen(PC_TxBuf);

	// append "\r\n"
	PC_TxBuf[len] = '\r';
	++len;
	PC_TxBuf[len] = '\n';
	++len;
	PC_TxBuf[len] = '\0';

	PC_TxActive = 1;

	HAL_UART_AbortTransmit(&huart2);
	HAL_UART_Transmit_DMA(&huart2, (uint8_t*)PC_TxBuf, len);

	// wait until msg is completely transmitted
	PC_TxTimer = 600;
	while (PC_TxActive && PC_TxTimer > 0);
	if (PC_TxTimer == 0)
	{
		// tx timeout happended
		++PC_TxTimeoutsCounter;
	}

	//logp("finished PC_Send");
}

//
// function starts new DMA RX transfer
//
void PC_StartRx()
{
	// clear overrun flag
	UART_HandleTypeDef* huart = &huart2;
	__HAL_UART_CLEAR_OREFLAG(huart);

	// enable Rx DMA
	HAL_UART_AbortReceive(huart);
	HAL_UART_Receive_DMA(huart, (uint8_t*)PC_RxBuf, PC_RX_BUF_LEN);

	PC_RxActive = 0;
}

//
// function check if complete msg is read in PC_RxBuf
// if msg ic complte function removes trailing '\r' or '\n' from the end, terminates it with '\0' and returns 1
// function also handles RX timeouts
//
int PC_IsMsgReady()
{
	int i;
	int msgComplete;

	// get number of bytes received
	PC_DmaRxLen = PC_RX_BUF_LEN - __HAL_DMA_GET_COUNTER(huart2.hdmarx);

	if (!PC_RxActive)
	{
		// check if new msg started
		if (PC_DmaRxLen == 0)
			return 0;

		// start timeout timer
		PC_RxTimer = PC_RX_TIMEOUT_MS;
		PC_RxActive = 1;
	}

	// msg is in progress, check if it is complete
	// search for '\r' or '\n'
	i = 0;
	while (i < PC_DmaRxLen)
	{
		if (PC_RxBuf[i] == '\r' || PC_RxBuf[i] == '\n')
		{
			PC_RxBuf[i] = '\0';
			HAL_UART_AbortReceive(&huart2);
			return 1;
		}

		++i;
	}

	// msg is not complet yet, check for timeout
	if (PC_RxTimer == 0)
	{
		// timeout
		PC_RxBuf[PC_DmaRxLen] = '\0';
		++PC_RxTimeoutsTimer;
		logw("PC Rx Timeout, received so far %d chars: %s", PC_DmaRxLen, PC_RxBuf);

		// restart Rx
		PC_StartRx();
	}

	return 0;
}

#pragma endregion

#pragma region LEDs
//
// start LED2 blink, LED2 will be turned off by interrupt
//
void Led2Blink()
{
	SetPortBit1(LED2, 1);
	Led2BlinkTimer = 100;
}

//
// start LED1 blink, LED1 will be turned off by interrupt
//
void Led1Blink()
{
	SetPortBit1(STAT_LED, 1);
	Led1BlinkTimer = 100;
}
#pragma endregion

#pragma region A7129

const char* A7129RegNames[] = {
	"SysClock",
	"PLL1",
	"PLL2",
	"PLL3",
	"PLL4",
	"PLL5",
	"PLL6",
	"Crystal",
	"",
	"",
	"Rx1",
	"Rx2",
	"ADC",
	"PinCtrl",
	"CAL",
	"Mode",
};
const char* A7129RegNamesPageA[] = {
	"TX1",
	"WOR1",
	"WOR2",
	"RFI",
	"PM",
	"RTH",
	"AGC1",
	"AGC2",
	"GIO",
	"CKO",
	"VCB",
	"CHG1",
	"CHG2",
	"FIFO",
	"CODE",
	"WCAL",
};
const char* A7129RegNamesPageB[] = {
	"TX2",
	"IF1",
	"IF2",
	"ACK",
	"ART",
};

//
// write value to specified register, data is written MSB first, len must be 0 to 4
//
// function returns ERR_xxx code
//
int A7129_WriteReg1(unsigned reg, unsigned value, int len)
{
	unsigned char buf[4];
	int ret;
	int i;
	unsigned char* p = ((unsigned char*)&value) + len - 1;

	for (i = 0; i < len; ++i)
	{
		buf[i] = *p;
		--p;
	}

	ret = A7129_WriteData(reg, buf, len);
	return ret;
}

//
// write cmd, then data
//
// function returns ERR_xxx code
//
int A7129_WriteData(unsigned cmd, unsigned char* p, int dataLen)
{
	int ret;
	int i;

	// set Tx direction
	LL_SPI_SetTransferDirection(SPI1, LL_SPI_HALF_DUPLEX_TX);

	// CS
	SetPortBit1(SCS, 0);

	// write cmd
	while (!LL_SPI_IsActiveFlag_TXE(SPI1));
	LL_SPI_TransmitData8(SPI1, cmd);

	// write data
	for (i = 0; i < dataLen; ++i)
	{
		// wait for SPI Tx buf empty
		while (!LL_SPI_IsActiveFlag_TXE(SPI1));

		LL_SPI_TransmitData8(SPI1, *p++);
	}

	// wait until all is out
	Wait200NanoSec();
	while (LL_SPI_IsActiveFlag_BSY(SPI1));

	// CS
	SetPortBit1(SCS, 1);

	return ERR_OK;
}

//
// write data to fifo
//
// function returns ERR_xxx code
//
int A7129_WriteFifo(unsigned char* p, int dataLen)
{
	int ret;

	// reset FIFO pointer
	ret = A7129_WriteReg1(CMD_TFR, 0, 0);
	if (ret != ERR_OK)
		return ret;

	// write data
	ret = A7129_WriteData(CMD_FIFO_W, p, dataLen);
	return ret;
}

//
// read data from fifo
//
// function returns ERR_xxx code
//
int A7129_ReadFifo(unsigned char* p, int dataLen)
{
	int ret;

	// reset FIFO pointer
	ret = A7129_WriteReg1(CMD_RFR, 0, 0);
	if (ret != ERR_OK)
		return ret;

	// read data
	ret = A7129_ReadData(CMD_FIFO_R, p, dataLen);
	p[dataLen] = '\0';
	return ret;
}

//
// read value from specified register
// len must be 1 to 4 bytes
//
// function returns ERR_xxx code
//
int A7129_ReadReg1(unsigned reg, unsigned *pValue, int len)
{
	int ret;
	int i;
	unsigned char buf[4];
	unsigned char* p = ((unsigned char*)pValue) + len - 1;

	ret = A7129_ReadData(reg, buf, len);

	*pValue = 0;
	for (i = 0; i < len; ++i)
	{
		*p = buf[i];
		--p;
	}

	return ret;
}

//
// read data
//
// function returns ERR_xxx code
//
int A7129_ReadData(unsigned cmd, unsigned char *pData, int dataLen)
{
	int ret;
	int i;
	unsigned c;
	LL_GPIO_InitTypeDef GPIO_InitStruct = { 0 };

	// set Tx direction
	LL_SPI_SetTransferDirection(SPI1, LL_SPI_HALF_DUPLEX_TX);

	// wait for SPI Tx buf empty
	while (!LL_SPI_IsActiveFlag_TXE(SPI1));

	// CS
	SetPortBit1(SCS, 0);

	// send cmd
	LL_SPI_TransmitData8(SPI1, cmd | CMD_Reg_R);

	// wait until all is out
	Wait200NanoSec();
	while (LL_SPI_IsActiveFlag_BSY(SPI1));

	// we have trouble reading data fast enough,
	// we need to optimize code so it can read characters faster then they come,
	// we also nmeed to enable interrupts to make sure we do not loose chars
	// disable interrupts 
	__disable_irq();

	// set Rx direction

	// SDIO
	GPIO_InitStruct.Pin = LL_GPIO_PIN_15;
	GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
	GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
	LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	// SCK
	SetPortBit1(SCK, 0);
	GPIO_InitStruct.Pin = LL_GPIO_PIN_13;
	GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
	GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
	LL_GPIO_Init(GPIOB, &GPIO_InitStruct);


	for (i = 0; i < dataLen; ++i)
	{
		// read byte
		*pData++ = SPI_ReadByte();
	}

	// enable interrupts
	__enable_irq();

	// CS
	SetPortBit1(SCS, 1);

	// set pins as SPI
	GPIO_InitStruct.Pin = LL_GPIO_PIN_13;
	GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
	GPIO_InitStruct.Alternate = LL_GPIO_AF_0;
	LL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	GPIO_InitStruct.Pin = LL_GPIO_PIN_15;
	LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	return ERR_OK;
}

//
// clock-in one byte from SDIO/SCK lines
//
unsigned SPI_ReadByte(void)
{
	unsigned val = 0;
	int i;

	for (i = 0; i < 8; i++)
	{
		Wait200NanoSec();

		if (ReadPortBit1(SDIO))
			val = (val << 1) | 0x01;
		else
			val = val << 1;

		SetPortBit1(SCK, 1);
		Wait200NanoSec();
		SetPortBit1(SCK, 0);
	}

	return val;
}

//
// send cmd to reset radio
//
// function returns ERR_xxx code
//
int A7129_Reset()
{
	int ret;

	ret = A7129_WriteReg1(CMD_RF_RST, 0, 0);
	Wait(100);

	return ret;
}

//
// write 4 ID bytes to radio
//
// function returns ERR_xxx code
//
int A7129_WriteID(unsigned id)
{
	int ret;

	ret = A7129_WriteReg1(CMD_ID_W, id, 4);
	
	return ret;
}

//
// read 4 ID bytes from radio
//
// function returns ERR_xxx code
//
int A7129_ReadID(unsigned *pid)
{
	int ret;

	ret = A7129_ReadReg1(CMD_ID_R, pid, 4);

	return ret;
}

//
// write 16 bit register
//
void A7129_WriteReg(unsigned address, unsigned dataWord)
{
	A7129_WriteReg1(address, dataWord, 2);
}


//
// read 16 bit register
//
unsigned A7129_ReadReg(unsigned address)
{
	unsigned value = 0;
	A7129_ReadReg1(address, &value, 2);
	return value;
}

//
// write 16 bit register in Page A
//
void A7129_WritePageA(unsigned address, unsigned dataWord)
{
	unsigned tmp;

	tmp = address;
	tmp = ((tmp << 12) | A7129Config[CRYSTAL_REG]);
	A7129_WriteReg(CRYSTAL_REG, tmp);
	A7129_WriteReg(PAGEA_REG, dataWord);
}

//
// Read 16 bit register from Page A
//
unsigned A7129_ReadPageA(unsigned address)
{
	unsigned tmp;

	tmp = address;
	tmp = ((tmp << 12) | A7129Config[CRYSTAL_REG]);
	A7129_WriteReg(CRYSTAL_REG, tmp);
	tmp = A7129_ReadReg(PAGEA_REG);
	return tmp;
}

//
// write 16 bit register in Page B
//
void A7129_WritePageB(unsigned address, unsigned dataWord)
{
	unsigned tmp;

	tmp = address;
	tmp = ((tmp << 7) | A7129Config[CRYSTAL_REG]);
	A7129_WriteReg(CRYSTAL_REG, tmp);
	A7129_WriteReg(PAGEB_REG, dataWord);
}

//
// Read 16 bit register from Page B
//
unsigned A7129_ReadPageB(unsigned address)
{
	unsigned tmp;

	tmp = address;
	tmp = ((tmp << 7) | A7129Config[CRYSTAL_REG]);
	A7129_WriteReg(CRYSTAL_REG, tmp);
	tmp = A7129_ReadReg(PAGEB_REG);
	return tmp;
}

//
// Function configures A7129
//
// function returns on of ERR_xxx codes
//
int A7129_Config(void)
{
	int i;
	unsigned tmp;

	A7129_Reset();

	for (i = 0; i < 8; i++)
		A7129_WriteReg(i, A7129Config[i]);

	for (i = 10; i < 16; i++)
		A7129_WriteReg(i, A7129Config[i]);

	for (i = 0; i < 16; i++)
	{
		tmp = A7129Config_PageA[i];
		if (i == 13)
		{
			// set Tx/Rx FIFO len
			tmp = (tmp & 0xff00) | ((unsigned)ee.FifoLen - 1);
		}
		A7129_WritePageA(i, tmp);
	}

	// Tx power
	R_CurrentTxPower = ee.TxPwr;
	R_tbg_tdc_pac = ee.HwVer == 0 ? A7139_TxPowerSettings[R_CurrentTxPower % 9] : A7129_TxPowerSettings[R_CurrentTxPower % 9];
	tmp = ((unsigned)A7129Config_PageB[0] & ~0x007f) | R_tbg_tdc_pac;
	logp("TX2: %04x", tmp);
	A7129_WritePageB(TX2_PAGEB, tmp);

	for (i = 1; i < 5; i++)
		A7129_WritePageB(i, A7129Config_PageB[i]);

	// check           
	tmp = A7129_ReadReg(SYSTEMCLOCK_REG);
	if (tmp != A7129Config[SYSTEMCLOCK_REG])
	{
		loge("SYSTEMCLOCK ERR: %x %x", tmp, A7129Config[SYSTEMCLOCK_REG]);
		return ERR_INVALID_VALUE;
	}
	//logp("SYSTEMCLOCK: %x %x", tmp, A7129Config[SYSTEMCLOCK_REG]);

	// wait to let crystal stabilize
	Sleep(10);

	//logp("A7129 Config OK");
	return ERR_OK;
}

//
// A7129_Cal
//
// function returns ERR_xxx code
//
int A7129_Cal(void)
{
	uint8_t fb, fcd, fbcf;    //IF Filter   
	uint8_t vb, vbcf;      //VCO Current   
	uint8_t vcb, vccf;    //VCO Band   
	uint8_t dvt;
	uint16_t tmp;

	Timer1 = 300;

	//IF calibration procedure @STB state   
	A7129_WriteReg(MODE_REG, A7129Config[MODE_REG] | 0x0802);    //IF Filter & VCO Current Calibration   
	do {
		tmp = A7129_ReadReg(MODE_REG);
		if (Timer1 == 0)
		{
			loge("Timeout S1");
			return ERR_TIMEOUT;
		}
		Sleep(1);
	} while (tmp & 0x0802);

	//for check(IF Filter)   
	tmp = A7129_ReadReg(CALIBRATION_REG);
	fb = tmp & 0x0F;
	fcd = (tmp >> 11) & 0x1F;
	fbcf = (tmp >> 4) & 0x01;
	if (fbcf)
	{
		loge("A7129 Cal Failed, fbcf set, CalReg:%x, f dev:%d", tmp, fcd);
		return ERR_CALL_FAILED_FBCF;
	}
	logp("fbcf:%d, CalReg: 0x%04x, f dev:%d", fbcf, tmp, fcd);

	//for check(VCO Current)   
	tmp = A7129_ReadPageA(VCB_PAGEA);
	vcb = tmp & 0x0F;
	vccf = (tmp >> 4) & 0x01;
	if (vccf)
	{
		logp("A7129 Cal Failed, vccf set, VcbReg:%x", tmp);
		return ERR_CALL_FAILED_VCCF;
	}
	logp("vccf:%d, VcbReg:0x%04x", vccf, tmp);


	//RSSI Calibration procedure @STB state   
	A7129_WriteReg(ADC_REG, 0x4C00);                    //set ADC average=64   
	A7129_WritePageA(WOR2_PAGEA, 0xF800);                   //set RSSC_D=40us and RS_DLY=80us   
	A7129_WritePageA(TX1_PAGEA, A7129Config_PageA[TX1_PAGEA] | 0xE000); //set RC_DLY=1.5ms   
	A7129_WriteReg(MODE_REG, A7129Config[MODE_REG] | 0x1000);           //RSSI Calibration   
	do {
		tmp = A7129_ReadReg(MODE_REG);
		if (Timer1 == 0)
		{
			loge("Timeout S2");
			return ERR_TIMEOUT;
		}
		Sleep(1);
	} while (tmp & 0x1000);
	A7129_WriteReg(ADC_REG, A7129Config[ADC_REG]);
	A7129_WritePageA(WOR2_PAGEA, A7129Config_PageA[WOR2_PAGEA]);
	A7129_WritePageA(TX1_PAGEA, A7129Config_PageA[TX1_PAGEA]);


	//VCO calibration procedure @STB state   
	A7129_WriteReg(MODE_REG, A7129Config[MODE_REG] | 0x0004);   //VCO Band Calibration   
	do {
		tmp = A7129_ReadReg(MODE_REG);
		if (Timer1 == 0)
		{
			loge("Timeout S3");
			return ERR_TIMEOUT;
		}
		Sleep(1);
	} while (tmp & 0x0004);

	//check VCO Band
	tmp = A7129_ReadReg(CALIBRATION_REG);
	vb = (tmp >> 5) & 0x07;
	vbcf = (tmp >> 8) & 0x01;
	dvt = (tmp >> 9) & 0x03;
	if (vbcf)
	{
		loge("A7129 Cal Failed, vbcf set, CalReg:%x, vb:%d", tmp, vb);
		return ERR_CALL_FAILED_VBCF;
	}
	logp("CalReg:0x%04x, vb:%d, dvt:%s", tmp, vb, dvt==0 ? "low" : dvt==1 ? "ok" : dvt==2 ? "???" : "high");

	logp("Cal OK");
	return ERR_OK;
}

void SendMsg();

//
// Initialize radio, calibrate and write ID
//
// function returns ERR_xx code
//
int A7129_Init()
{
	int ret;
	const int MAX_TRY = 10;
	int tr = 0;
	int successCount = 0;

	while (1)
	{
		ret = A7129_Init1();
		if (ret == ERR_OK)
		{
			++successCount;
			if(successCount >= 1)
				break;
		}

		//sprintf((char*)R_TxBuf, "init #%d", tr);
		//SendMsg();

		++tr;
		if (tr > MAX_TRY)
		{
			loge("Init failed too many times");
			return ret;
		}

		//Sleep(20);
	}

	return ret;
}

//
// worker function for A7129_Init(). This might be called multiple timed from A7129_Init()
//
// function returns ERR_xx code
//
int A7129_Init1()
{
	int ret;

	// configure
	ret = A7129_Config();
	if (ret != ERR_OK)
		return ret;

	//A7129_SetTxPower(ee.TxPwr);

	// write ID
	ret = A7129_WriteID(R_DEFAULT_ID);
	if (ret != ERR_OK)
		return ret;

	// calibrate
	ret = A7129_Cal();
	if (ret == ERR_OK)
		return ret;

	logp("Radio Init OK");
	return ERR_OK;
}

//
// read and log all regs
//
void A7129_LogRegs()
{
	int i;
	unsigned val;

	for (i = 0; i < 16; ++i)
	{
		if (i == 8 || i == 9)
			continue;
		val = A7129_ReadReg(i);
		logd("%x %s: 0x%04x", i, A7129RegNames[i], val);
	}
	logp(" ");

	for (i = 0; i < 16; ++i)
	{
		val = A7129_ReadPageA(i);
		logd("%x %s: 0x%04x", i, A7129RegNamesPageA[i], val);
	}
	logp(" ");

	for (i = 0; i < 5; ++i)
	{
		val = A7129_ReadPageB(i);
		logd("%x %s: 0x%04x", i, A7129RegNamesPageB[i], val);
	}
}

//
// set transmit power
// parameter should be in format: tbg << 4 | tdc << 2 | pac
//
void A7129_SetTxPower(unsigned txPowerIndex)
{
	unsigned val;

	R_CurrentTxPower = txPowerIndex;
	R_tbg_tdc_pac = ee.HwVer == 0 ? A7139_TxPowerSettings[R_CurrentTxPower % 9] : A7129_TxPowerSettings[R_CurrentTxPower % 9];
	val = (A7129Config_PageB[TX2_PAGEB] & ~0x7f) | R_tbg_tdc_pac;
	logp("A7129_SetTxPower(%d), writing %04x", txPowerIndex, val);
	A7129_WritePageB(TX2_PAGEB, val);
}

#pragma region A7129 tables
//#define MHz470
#define Mhz915

#ifdef MHz470
// 470 MHz setings
const uint16_t A7129Config[] =     //470MHz, 10kbps (IFBW = 100KHz, Fdev = 37.5KHz)   
{
	0x1221,     // 0: SYSTEM CLOCK register,   
	0x0A24,     // 1: PLL1 register,   
	0xB805,     // 2: PLL2 register,    470.001MHz   
	0x0000,     // 3: PLL3 register,	AFC=off   
	0x0A20,     // 4: PLL4 register,    MD1=0 (low freq range)
	0x0024,     // 5: PLL5 register,   
	0x0000,     // 6: PLL6 register,   RFC=0
	0x0001,     // 7: CRYSTAL register,   
	0x0000,     // 8: PAGEA,   
	0x0000,     // 9: PAGEB,   
	0x18D4,     // A: RX1 register,     IFBW=100KHz, ETH=1     
	0x7009,     // B: RX2 register,     by preamble   
	0x4400,     // C: ADC register,        
	0x0800,     // D: PIN CONTROL register,     Use Strobe CMD   
	0x4845,     // E: CALIBRATION register,   
	0x20C0      // F: MODE CONTROL register,    Use FIFO mode   
};

const uint16_t A7129Config_PageA[] =   //470MHz, 10kbps (IFBW = 100KHz, Fdev = 37.5KHz)   
{
	0x1706,     // 0: TX1 register,     Fdev = 37.5kHz   
	0x0000,     // 1: WOR1 register,   
	0x0000,     // 2: WOR2 register,   
	0x1187,     // 3: RFI register,     Enable Tx Ramp up/down     
	0x8160,     // 4: PM register,      CST=1   
	0x0302,     // 5: RTH register,   
	0x400F,     // 6: AGC1 register,       
	0x0AC0,     // 7: AGC2 register,    
	0x0045,     // 8: GIO register,     GIO2=WTR, GIO1=FSYNC   
	0xD281,     // 9: CKO register   
	0x0004,     // A: VCB register,   
	0x0825,     // B: CHG1 register,    480MHz   
	0x0127,     // C: CHG2 register,    500MHz   
	0x003F,     // D: FIFO register,    FEP=63+1=64bytes   
	0x1507,     // E: CODE register,    Preamble=4bytes, ID=4bytes   
	0x0000      // F: WCAL register,   
};

const uint16_t A7129Config_PageB[] =   //470MHz, 10kbps (IFBW = 100KHz, Fdev = 37.5KHz)   
{
	0x0B7F,     // 0: TX2 register,     Tx power=13dBm   
	0x8400,     // 1: IF1 register,     Enable Auto-IF, IF=200KHz   
	0x0000,     // 2: IF2 register,     Fr. offset FPA=0
	0x0000,     // 3: ACK register,   
	0x0000      // 4: ART register,   
};

const uint16_t Freq_Cal_Tab[] =
{
	0x0A24, 0xB805, //470.001MHz   
	0x0A26, 0x4805, //490.001MHz   
	0x0A27, 0xD805  //510.001MHz   
};
#else
	// 915 MHz settings
const uint16_t A7129Config[] =     //915MHz, 10kbps (IFBW = 100KHz, Fdev = 37.5KHz)   
{
	0x1221,     // 0: SYSTEM CLOCK register,   
	0x0A47,     // 1: PLL1 register,    0x0A00 + FreqSelect integer part IP = 71dec = 0x47
	0x7c05,     // 2: PLL2 register,    FreqSelect fractional part FP = 31749dec = 0x7c05
	0x0000,     // 3: PLL3 register,	AFC=off   
	0x1A20,     // 4: PLL4 register,    MD1=1 (hi freq range), LO Buf High Current
	0x0024,     // 5: PLL5 register,   
	0x0000,     // 6: PLL6 register,   RFC=0
	0x0001,     // 7: CRYSTAL register,   
	0x0000,     // 8: PAGEA,   
	0x0000,     // 9: PAGEB,   
	0x18D4,     // A: RX1 register,     IFBW=100KHz, ETH=1     
	0x7009,     // B: RX2 register,     by preamble   
	//0x4400,     // C: ADC register,     auto RSSI disabled   
	0xc400,     // C: ADC register,     auto RSSI enabled
	0x0800,     // D: PIN CONTROL register,     Use Strobe CMD   
	0x4845,     // E: CALIBRATION register, CRC filtering disabled: 0x4845, CRC filtering enabled: 0xc845
	0x20C0      // F: MODE CONTROL register,    Use FIFO mode   
};

const uint16_t A7129Config_PageA[] =   //915MHz, 10kbps (IFBW = 100KHz, Fdev = 37.5KHz)   
{
	0x1706,     // 0: TX1 register,     Fdev = 37.5kHz   
	0x0000,     // 1: WOR1 register,   
	0x0000,     // 2: WOR2 register,   
	0x1187,     // 3: RFI register,     Enable Tx Ramp up/down     
	0x8160,     // 4: PM register,      CST=1   
	0x0302,     // 5: RTH register,		AGC high and low threshold
	0x400F,     // 6: AGC1 register,    AGC disabled, LNA set to max gain, mixer set to max gain   
	0x0AC0,     // 7: AGC2 register,    
	0x0045,     // 8: GIO register,     GIO2=WTR, GIO1=FSYNC   
	0xD281,     // 9: CKO register   
	0x0004,     // A: VCB register,   
	0x0b46,     // B: CHG1 register,    905MHz   This seems to be IP part in low 8 bits + top 4 bits of FP part
	0x0448,     // C: CHG2 register,    925MHz   This seems to be IP part in low 8 bits + top 4 bits of FP part
	0x003F,     // D: FIFO register,    FEP=63+1=64bytes   
	0x153F,     // E: CODE register,    Preamble=4bytes, ID=4bytes, disable CRC,WHT,FEC:0x1507. Enable CRC+WHT:0x152f. Enable CRC+WHT+FEC:0x153F  
	0x0000      // F: WCAL register,   
};

const uint16_t A7129Config_PageB[] =   //915MHz, 10kbps (IFBW = 100KHz, Fdev = 37.5KHz)   
{
	0x0B7F,     // 0: TX2 register,     Max Tx power
	0x8400,     // 1: IF1 register,     Enable Auto-IF, IF=200KHz   
	0x0000,     // 2: IF2 register,     Fr. offset FPA=0
	0x0000,     // 3: ACK register,   
	0x0000      // 4: ART register,   
};
#endif

// power settings for A7129
const unsigned char A7129_TxPowerSettings[9] =
{
	// ttt : TBG
	//  dd : TDC
	//  pp : PAC
	//ppddttt
	0b0000000,	// 0: -43.4 dB,  5.6 mA
	0b0000001,	// 1: -15.5 dB,  5.9 mA
	0b0000010,	// 2: -12.3 dB,  6.1 mA
	0b0000100,	// 3:  -6.1 dB,  7.0 mA
	0b0000101,	// 4:  -3.7 dB,  7.8 mA
	0b0001101,	// 5:   1.3 dB, 11.9 mA
	0b0001111,	// 6:   4.3 dB, 14.9 mA
	0b0010111,	// 7:   6.0 dB, 18.0 mA
	0b0011111,	// 8:   6.9 dB, 20.3 mA
};

// power settings for A7139
const unsigned char A7139_TxPowerSettings[9] =
{
	// ttt : TBG
	//  dd : TDC
	//  pp : PAC
	//ppddttt
	0b0000000,	// 0: -34.7 dB, 14.0 mA
	0b0000001,	// 1:  -7.6 dB, 14.4 mA
	0b0000010,	// 2:  =4.4 dB, 14.7 mA
	0b0000100,	// 3:   1.7 dB, 16.3 mA
	0b0000101,	// 4:   4.0 dB, 17.6 mA
	0b0000110,	// 5:  5.7  dB, 19.4 mA
	0b0000111,	// 6:  6.4  dB, 20.8 mA
	0b0001111,	// 7:  9.4  dB, 26.8 mA
	0b0011111,	// 8: 11.6  dB, 34.6 mA
};

#pragma endregion

#pragma endregion

#pragma region Motor

//
// start motor in specified direction
// direction 0: turn on IN1/OUT1
//
void Mot_Start(int direction, int travelTimeMs)
{
	MaxMotCurrentMA = 0;
	MotOvercurrentTime = 0;
	MotStallTime = 0;

	SetPortBit1(TIM2CH1, !direction);
	SetPortBit1(TIM2CH2, direction);
	MotTimer = travelTimeMs;
}

//
// stop motor
//
void Mot_Stop()
{
	MotTimer = 0;
	SetPortBit1(MOT_EN, 0);
}

//
// function is called from 1ms periodic interrupt and contains motor timing and safety logic
//
void Mot_Logic()
{
	if (MotTimer)
	{
		--MotTimer;

		if (MotCurrentMA > MaxMotCurrentMA)
			MaxMotCurrentMA = MotCurrentMA;

		// overcurrent logic
		if (MotOvercurrOffTimer)
		{
			--MotOvercurrOffTimer;
			++MotOvercurrentTime;
			++MotStallTime;
		}
		else
		{
			if (MotCurrentMA > MOT_OVERCURRENT_LIMIT_MA)
			{
				// motor current higher then overcurrent limit
				// turn off motor for some time
				MotOvercurrOffTimer = MOT_OVERCURRENT_OFF_TIME_MS;
				++MotOvercurrEventCounter;
				++MotOvercurrentTime;
				++MotStallTime;
			}
			else if (MotCurrentMA > ee.MotStallCurrentMA)
			{
				// motor current higher then stall limit
				++MotStallTime;
			}
		}

		if (MotStallTime >= MOT_STALL_TIME_TO_TURN_OFF_MS)
		{
			// we were stalled for enough time to turn off motor
			MotTimer = 0;
		}

	}

	// motor is on when main timer is running and overcurrent timer is not active
	SetPortBit1(MOT_EN, MotTimer && !MotOvercurrOffTimer);

}
#pragma endregion