	#pragma region includes
#include "intr.h"
#include "vars.h"
#include "debug.h"
#include "main.h"
#include "pc.h"
#include "string.h"
#include "lib.h"
#include "limits.h"
#include "eeprom.h"

#pragma endregion

extern volatile int q; // main code test variable

#pragma region logging macros
// 
#define loge(args...) Log(LOG_SEV_ERROR, LOG_PC, args)
#define logw(args...) Log(LOG_SEV_WARNING, LOG_PC, args)
#define logp(args...) Log(LOG_SEV_PROCESS, LOG_PC, args)
#pragma endregion

#pragma region CmdWordsCountLookup
// value1: minimum number of words for command including word for command
// value2: maximum number of words for command including word for command
const char CmdWordsCountLookup[] = 
"ping:1:2;"			// 0		ping
"xxxxx:1:1;"		// 1		
"fwver:1:1;"		// 2		read firmware version
"get:2:2;"			// 3		get value of parameter or variable
"set:3:10;"			// 4		set value of parameter or variable
"reset:1:1;"		// 5		reset micro
"logee:1:1;"		// 6		log EEPROM content
"initee:1:1;"		// 7		clear eeprom completely
"caltemp:2:2;"		// 8		calibrate all temp sensors to show specified value
"tx:2:8;"			// 9		transmit radio msg
"temp:1:1;"			// 10		get temperature reading of all channels AND rssi
"test:1:2;"			// 11		test command, param value: 1:send long constant msg
"regs:1:1;"			// 12		read and log all regs
"wr:3:3;"			// 13		write value to register with specified adr (hex)
"wra:3:3;"			// 14		write value to Page A register
"wrb:3:3;"			// 15		write value to Page B register
"txpwr:2:2;"		// 16		set tx power, 0-min, 8-max
"left:2:2;"			// 17		start motor in left direction for specified time in ms
"right:2:2;"		// 18		start motor in right direction for specified time in ms
"stop:1:1;"			// 19		stop motor
"mm:2:8;"			// 20		transmit mesh message sequence, e.g. mm 1,9,temp
"m:1:2;"			// 21		transmit mesh command request, e.g. "m" or "m 2"
//"r:1:1;" - this will repeat last cmd
"";
#pragma endregion


#pragma region ErrDescr
//const char *ErrDescr[] = {
//	"unrecognized command",				// ERR_UNRECOGNIZED_CMD 1
//	"invalid number of params",			// ERR_INVALID_NUMBER_OF_PARAMS 2
//	"unknown error",					// ERR_UNKNOWN_ERROR
//	"invalid value",					// ERR_INVALID_VALUE 4
//	"command failed",					// ERR_COMMAND_FAILED 5
//	"internal HW error",				// ERR_INTERNAL_HW_ERROR 6
//	"",									// 7
//	"Invalid param value",				// ERR_INVALID_PARAM_VALUE 8
//	"I2C write failed",					// ERR_I2C_WRITE_FAILED 9
//	"I2C read failed",					// ERR_I2C_READ_FAILED 10
//	"set DAC failed",					// ERR_SET_DAC_FAILED 11
//	"EEPROM test mismatch",				// ERR_SET_EEPROM_TEST_MISMATCH 12
//	"data not ready yet",				// ERR_ACC_NEW_DATA_NOT_READY_YET 13
//	"CRC mismatch",						// ERR_CRC_MISMATCH 14
//	"unrecognized param name",			// ERR_UNRECOGNIXED_PARAM_NAME 15
//	"invalid length",					// ERR_INVALID_LENGTH 16
//	"failed to set date and time",		// ERR_SET_DATE_TIME_FAILED 17
//	"spi operation failed",				// ERR_SPI_ERR 18
//	"flash manuf id mismatch",			// ERR_MANUF_ID_MISMATCH 19
//	"timeout",							// ERR_TIMEOUT 20
//	"EEPROM error",						// ERR_EEPROM_ERR 21
//	"Invalid array index",				// ERR_INVALID_ARRAY_INDEX 22
//};
#pragma endregion

#pragma region PARAMDATA
#define PARAMDATA_T_INVALID 0
#define PARAMDATA_T_EEPROM_UINT 1		//	1: EEPROM value, unsigned char, short, int
#define PARAMDATA_T_EEPROM_HALFFLOAT 2	//	2: EEPROM value, halffloat
#define PARAMDATA_T_EEPROM_STRING 3		//	3: EEPROM value, string
#define PARAMDATA_T_EEPROM_CHAR_ARRAY 4	//	4: EEPROM value, unsigned char[]
#define PARAMDATA_T_DATETIME 5			//	5: set RTC date and time
#define PARAMDATA_T_EPOCH 6				//	6: set RTC date and time using linux epoch value
#define PARAMDATA_T_EEPROM_INT 7		//	7: EEPROM value, signed char, short, int
#define PARAMDATA_T_EEPROM_FLOAT 8		//	8: EEPROM value, float
#define PARAMDATA_T_RAM_UINT 9			//	9: RAM value, unsigned char, short, int
#define PARAMDATA_T_RAM_INT 10			//	10: RAM value, signed char, short, int
#define PARAMDATA_T_EEPROM_BYTE_ARRAY 11//	11: EEPROM value, byte array as hex string
#define PARAMDATA_T_DIO 12				//	12: DO point
#define PARAMDATA_T_RAM_FLOAT 13		//	13: RAM value, float
//#define PARAMDATA_T_RAM_DOUBLE 14		//	14: RAM value, double

#define PARAMDATA_READONLY 0		// read only
#define PARAMDATA_CALIB 1			// read, write if calibration mode is active
#define PARAMDATA_READWRITE 2		// read and write


typedef struct
{
	char * name;
	unsigned char type;
	unsigned short len;			// number of bytes
	unsigned char readwrite;	// 0: read only, 1:read-write
	void * adr;					// parameter address in memory
	unsigned short arrayLen;	// 0 for scalars, positive value for arrays
} PARAMDATA;

//
const PARAMDATA ParamData[] = {

	{"PCB_SN",	PARAMDATA_T_EEPROM_STRING, 7, PARAMDATA_CALIB, &ee.PCB_SN, 0},
	{"DEVICE_SN",	PARAMDATA_T_EEPROM_STRING, 7, PARAMDATA_CALIB, &ee.PCB_SN, 0},
	{"Mode",	PARAMDATA_T_EEPROM_UINT, 1, PARAMDATA_CALIB, &ee.Mode, 0},
	{"TempAdjust",	PARAMDATA_T_EEPROM_INT, 2, PARAMDATA_CALIB, &ee.TempAdjust, 3},
	{"AdcFilter",	PARAMDATA_T_EEPROM_UINT, 2, PARAMDATA_CALIB, &ee.AdcFilter, 6},
	{"StationID",	PARAMDATA_T_EEPROM_UINT, 1, PARAMDATA_CALIB, &ee.StationID, 0},
	{"TxPwr",	PARAMDATA_T_EEPROM_UINT, 1, PARAMDATA_CALIB, &ee.TxPwr, 0},
	{"PollPeriod",	PARAMDATA_T_EEPROM_UINT, 2, PARAMDATA_CALIB, &ee.PollPeriod, 0},
	{"FifoLen",	PARAMDATA_T_EEPROM_UINT, 1, PARAMDATA_CALIB, &ee.FifoLen, 0},
	{"RejectMsgsWithCRCError",	PARAMDATA_T_EEPROM_UINT, 1, PARAMDATA_CALIB, &ee.RejectMsgsWithCRCError, 0},
	{"HwVer",	PARAMDATA_T_EEPROM_UINT, 1, PARAMDATA_CALIB, &ee.HwVer, 0},
	{"MotStallCurrentMA",	PARAMDATA_T_EEPROM_UINT, 2, PARAMDATA_CALIB, &ee.MotStallCurrentMA, 0},

	// RAM vars
	{"q",	PARAMDATA_T_RAM_INT, 4, PARAMDATA_CALIB, (unsigned char*)&q, 0},
	{"Rssi",	PARAMDATA_T_RAM_UINT, 1, PARAMDATA_CALIB, (unsigned char *)&Rssi, 0},
	{"Vin",	PARAMDATA_T_RAM_UINT, 2, PARAMDATA_CALIB, (unsigned short*)&Vin, 0},
	{"Vdda",	PARAMDATA_T_RAM_UINT, 2, PARAMDATA_CALIB, (unsigned short*)&Vdda, 0},
	{"lic",	PARAMDATA_T_RAM_UINT, 4, PARAMDATA_CALIB, (unsigned *)&lowInterruptCounter, 0},

	// last item to mark end of list
	{"", PARAMDATA_T_INVALID, 0, 0, 0, 0}
};
#pragma endregion

#pragma region helper functions
//
// function tries to find param-data for parameter with specified name
// name comparison is not case sensitive
// function returns NULL if not found
// arrayIndex will be set to -1 for non-arrays or to specified index if this is array (PGA_Mult[2])
//
PARAMDATA * GetParamData(char *name, int *arrayIndex)
{
	char *p1;
	char *p2;
	unsigned len;
	char nameBuf[32];


	*arrayIndex = 0;

	// find if this is array
	len = strlen(name);
	if (len >= sizeof(nameBuf))
	{
		loge("parameter name too long: %s", name);
		return NULL;
	}
	strcpy(nameBuf, name);

	if (len >= 3 && nameBuf[len - 1] == ']')
	{
		// this seems to be array
		nameBuf[len - 1] = '\0';

		p1 = strchr(nameBuf, '[');
		if (p1 == NULL)
		{
			loge("Invalid Array Name: %s", name);
			return NULL;
		}

		*arrayIndex = strtol(p1 + 1, &p2, 10);
		if (*p2 != '\0')
		{
			loge("failed to parse array index: %s", name);
			return NULL;
		}
		if (*arrayIndex < 0)
		{
			loge("invalid array index: %s", name);
			return NULL;
		}

		*p1 = '\0';
	}
	else
	{
		// not an array
		*arrayIndex = -1;
	}

	PARAMDATA *p = (PARAMDATA *)ParamData;
	while (p->type != PARAMDATA_T_INVALID)
	{
		if (strcasecmp(p->name, nameBuf) == 0)
			return p;

		++p;
	}

	return NULL;
}

//
// function tries to parse boolean value
// valid values result 1 are: yes,y,true,1
// valid values result 0 are: no,n,false,0
//
// case is not sensitive
//
// function returns ERR_xxx code
//
int ParseBoolValue(char *p, int *pResult)
{
	if (strcasecmp(p, "yes") == 0 || strcasecmp(p, "y") == 0 || strcasecmp(p, "true") == 0 || strcasecmp(p, "1") == 0)
	{
		*pResult = 1;
		return ERR_OK;
	}
	else if (strcasecmp(p, "no") == 0 || strcasecmp(p, "n") == 0 || strcasecmp(p, "false") == 0 || strcasecmp(p, "0") == 0)
	{
		*pResult = 0;
		return ERR_OK;
	}
	else
	{
		return ERR_INVALID_VALUE;
	}
}
#pragma endregion

#pragma region PC_ProcessMsgs()
// function processes all messages coming from PC
void PC_ProcessMsgs(char *cmd, char *resp, int log)
{

	int status;
	int cmdsCount;
	int values[2];
	int ci;
	int ret;
	char *pCmd;
	int errNo;
	int cmdIndex;
	int value;
	int values2[4];
	char *p;
	char *p1;
	char *p2;
	char *pResp;
	int i;
	char chipId[12];
	int licType;
	int licCode;
	unsigned expectedLicCode;
	int varArrayIndex;	// 0 if this is not array, otherwise array index
	PARAMDATA *pd;
	unsigned uval;
	int found;
	int len;
	unsigned mask;
	int ch;
	char strBuf[256];
	unsigned adr;


	#pragma region split to commands
	// we have msg with one or more commands
	if(log)
		logp("PCRX: %s", cmd);

	// remove trailing semicolons
	trim(cmd);

	// check if this is repeat cmd
	if (strcasecmp(cmd, "r") == 0)
		cmd = PC_LastCmd;
	else
		strcpy(PC_LastCmd, cmd);

	value = strlen(cmd);
	if(value > 0 && cmd[value - 1] == ';')
		cmd[value - 1] = '\0';

	if(stop) brk();

	// initialize response
	pResp = resp;
	*pResp = '\0';

	// split to commands
	cmdsCount = split2words(cmd, ';', MAX_CMDS_COUNT, cmds);
	if(cmdsCount > MAX_CMDS_COUNT)
	{
		loge("too many commands");
	}
	#pragma endregion

	for(ci=0; ci<cmdsCount; ++ci)
	{
		#pragma region split to words, check number of words
		//logp("- %s", cmds[ci]);

		// add separator to resp
		if(ci > 0)
			*pResp++ = ';';
		*pResp = '\0';

		// clear response data string
		respDataStr[0] = '\0';

		// check if empty command was received
		if(cmds[ci][0] == '\0')
		{
			loge("empty command received");
			continue;
		}

		// split cmd to words
		cmdWordsCount = split2words(cmds[ci], ' ', MAX_WORDS_COUNT, cmdWords);
		pCmd = cmdWords[0];
		stolower(pCmd);
		
		// find min and max number of words that is valid for this cmd
		ret = LookupStrInt((char *)CmdWordsCountLookup, pCmd, values, &cmdIndex);
		if(ret != 2)
		{
			errNo =  ERR_UNRECOGNIZED_CMD;
			goto ErrLabel;
		}

		// check number of words
		if(cmdWordsCount < values[0] || cmdWordsCount > values[1])
		{
			errNo =  ERR_INVALID_NUMBER_OF_PARAMS;
			goto ErrLabel;
		}

		#pragma endregion

		switch(cmdIndex)
		{
		#pragma region ping
		case 0:	// ping
				//"ping:1:2;"			// 0

			// if there is parameter send it back
			if (cmdWordsCount > 1)
				sprintf(respDataStr, "%s", cmdWords[1]);

			break;
		#pragma endregion

		#pragma region fwver
		case 2:
			// fwver

			sprintf(respDataStr,"%x.%x%x%x", (SW_VER_NUMBER >> 12) & 0x0f, (SW_VER_NUMBER >> 8) & 0x0f, (SW_VER_NUMBER >> 4) & 0x0f, (SW_VER_NUMBER >> 0) & 0x0f);
			
			break;
		#pragma endregion

		#pragma region get
		case 3:
			//	"get:2:2;"			// 4
			// "get LoggingInterval"
			// "get PGA_Gain[2]

			pd = GetParamData(cmdWords[1], &varArrayIndex);
			if (pd == NULL)
			{
				loge("unknown param name: %s", cmdWords[1]);
				errNo = ERR_UNRECOGNIZED_PARAM_NAME;
				goto ErrLabel;
			}

			// process array
			if (pd->arrayLen > 0)
			{
				if(varArrayIndex < 0 || varArrayIndex >= pd->arrayLen)
				{
					loge("missing of invalid array index: %s", cmdWords[1]);
					errNo = ERR_INVALID_ARRAY_INDEX;
					goto ErrLabel;
				}
			}
			else
			{
				if (varArrayIndex >= 0)
				{
					loge("var is not an array: %s", cmdWords[1]);
					errNo = ERR_INVALID_ARRAY_INDEX;
					goto ErrLabel;
				}

				varArrayIndex = 0;
			}

			switch (pd->type)
			{
			//case PARAMDATA_T_EEPROM_BYTE_ARRAY:
			//	ByteArrayToHexStrNoSpace(respDataStr, pd->adr, pd->len, sizeof(respDataStr));
			//	break;

			case PARAMDATA_T_EEPROM_INT:
			case PARAMDATA_T_RAM_INT:
				value = 0;
				memcpy(&value, pd->adr + pd->len * (unsigned)varArrayIndex, pd->len);
				sprintf(respDataStr, "%s %d", cmdWords[1], value);
				break;

			case PARAMDATA_T_EEPROM_UINT:
			case PARAMDATA_T_RAM_UINT:
				uval = 0;
				memcpy(&uval, pd->adr + pd->len * (unsigned)varArrayIndex, pd->len);
				sprintf(respDataStr, "%s %u", cmdWords[1], uval);
				break;

			//case PARAMDATA_T_EEPROM_FLOAT:
			//case PARAMDATA_T_RAM_FLOAT:
			//	memcpy(&floatVal, pd->adr + pd->len * (unsigned)varArrayIndex, 4);
			//	sprintf(respDataStr, "%s %f", cmdWords[1], floatVal);
			//	break;

			//case PARAMDATA_T_RAM_DOUBLE:
			//	memcpy(&dblVal, pd->adr + pd->len * (unsigned)varArrayIndex, 8);
			//	sprintf(respDataStr, "%s %f", cmdWords[1], dblVal);
			//	break;

			case PARAMDATA_T_EEPROM_STRING:
				i = strlen(pd->adr);
				if (i > 100)
				{
					loge("string too long: %d", i);
					errNo = ERR_INVALID_LENGTH;
					goto ErrLabel;
				}
				sprintf(respDataStr, "%s %s", cmdWords[1], pd->adr);
				break;

			default:
				loge("unsupported param type");
				errNo = ERR_INVALID_VALUE;
				goto ErrLabel;
			}
			break;
			#pragma endregion

		#pragma region set
		case 4:
			//	"set:3:10;"			// 5
			// e.g. "set LoggingInterval 5"
			// e.g. "set NOR_LastUploadedBlockID 0xabcd1234"

			pd = GetParamData(cmdWords[1], &varArrayIndex);
			if (pd == NULL)
			{
				loge("unknown param name: %s", cmdWords[1]);
				errNo = ERR_UNRECOGNIZED_PARAM_NAME;
				goto ErrLabel;
			}

			// process array
			if (pd->arrayLen > 0)
			{
				if (varArrayIndex < 0 || varArrayIndex >= pd->arrayLen)
				{
					loge("missing of invalid array index: %s", cmdWords[1]);
					errNo = ERR_INVALID_ARRAY_INDEX;
					goto ErrLabel;
				}
			}
			else
			{
				if (varArrayIndex >= 0)
				{
					loge("var is not an array: %s", cmdWords[1]);
					errNo = ERR_INVALID_ARRAY_INDEX;
					goto ErrLabel;
				}

				varArrayIndex = 0;
			}


			switch (pd->type)
			{
			//case PARAMDATA_T_EEPROM_BYTE_ARRAY:
			//	if (strlen(cmdWords[2]) != pd->len * 2)
			//	{
			//		loge("value length does not match variable length: value len:%d, variable len:%d", strlen(cmdWords[2]), pd->len);
			//		errNo = ERR_INVALID_LENGTH;
			//		goto ErrLabel;
			//	}

			//	for (i = 0; i < pd->len; ++i)
			//	{
			//		strBuf[0] = cmdWords[2][i * 2];
			//		strBuf[1] = cmdWords[2][i * 2 + 1];
			//		strBuf[2] = '\0';
			//		value = strtol(strBuf, &p1, 16);
			//		if(*p1 != '\0')
			//		{
			//			loge("failed to parse value: %s", strBuf);
			//			errNo = ERR_INVALID_VALUE;
			//			goto ErrLabel;
			//		}

			//		// set
			//		memcpy(pd->adr + i, &value, 1);
			//	}


			//	if (pd->type == PARAMDATA_T_EEPROM_BYTE_ARRAY)
			//	{
			//		// store to EEPROM
			//		ret = EE_Store(pd->adr + pd->len * (unsigned)varArrayIndex, pd->len);
			//		if (ret != ERR_OK)
			//		{
			//			errNo = ret;
			//			goto ErrLabel;
			//		}
			//	}

			//	sprintf(respDataStr, "%s %s", cmdWords[1], cmdWords[2]);
			//	break;

			case PARAMDATA_T_EEPROM_INT:

				// parse as decimal or hex number
				if (strncmp(cmdWords[2], "0x", 2) == 0)
				{
					// hex number
					value = strtol(cmdWords[2], &p1, 16);
				}
				else
				{
					// decimal number
					value = strtol(cmdWords[2], &p1, 10);
				}
				if (*p1 != '\0')
				{
					loge("failed to parse value: %s", cmdWords[2]);
					errNo = ERR_INVALID_VALUE;
					goto ErrLabel;
				}

				// set
				memcpy(pd->adr + pd->len * (unsigned)varArrayIndex, &value, pd->len);

				if (pd->type == PARAMDATA_T_EEPROM_INT)
				{
					// store to EEPROM
					ret = EE_Store(pd->adr + pd->len * (unsigned)varArrayIndex, pd->len);
					if (ret != ERR_OK)
					{
						errNo = ret;
						goto ErrLabel;
					}
				}

				sprintf(respDataStr, "%s %d", cmdWords[1], value);
				break;

			case PARAMDATA_T_EEPROM_UINT:
			case PARAMDATA_T_RAM_UINT:

				// parse as decimal or hex number
				if (strncmp(cmdWords[2], "0x", 2) == 0)
				{
					// hex number
					uval = strtoul(cmdWords[2], &p1, 16);
				}
				else
				{
					// decimal number
					uval = strtoul(cmdWords[2], &p1, 10);
				}
				if(*p1 != '\0')
				{
					loge("failed to parse value: %s", cmdWords[2]);
					errNo = ERR_INVALID_VALUE;
					goto ErrLabel;
				}

				// check if too big
				mask = pd->len == 1 ? 0xffffff00 : pd->len == 2 ? 0xffff0000 : 0;
				if((uval & mask) != 0)
				{
					loge("value too big: %s", cmdWords[2]);
					errNo = ERR_INVALID_VALUE;
					goto ErrLabel;
				}

				// set
				memcpy(pd->adr + pd->len * (unsigned)varArrayIndex, &uval, pd->len);

				if (pd->type == PARAMDATA_T_EEPROM_UINT)
				{
					// store to EEPROM
					ret = EE_Store(pd->adr + pd->len * (unsigned)varArrayIndex, pd->len);
					if (ret != ERR_OK)
					{
						errNo = ret;
						goto ErrLabel;
					}
				}

				sprintf(respDataStr, "%s %u", cmdWords[1], uval);
				break;

			//case PARAMDATA_T_EEPROM_FLOAT:
			//case PARAMDATA_T_RAM_FLOAT:

			//	// parse
			//	floatVal = strtof1(cmdWords[2], &p1);
			//	if (*p1 != '\0')
			//	{
			//		loge("failed to parse value: %s", cmdWords[2]);
			//		errNo = ERR_INVALID_VALUE;
			//		goto ErrLabel;
			//	}

			//	// set
			//	memcpy(pd->adr + pd->len * (unsigned)varArrayIndex, &floatVal, 4);

			//	if (pd->type == PARAMDATA_T_EEPROM_FLOAT)
			//	{
			//		// store to EEPROM
			//		ret = EE_Store(pd->adr + pd->len * (unsigned)varArrayIndex, 4);
			//		if (ret != ERR_OK)
			//		{
			//			errNo = ret;
			//			goto ErrLabel;
			//		}
			//	}

			//	sprintf(respDataStr, "%s %f", cmdWords[1], floatVal);
			//	break;

			//case PARAMDATA_T_RAM_DOUBLE:

			//	// parse
			//	dblVal = strtod1(cmdWords[2], &p1);
			//	if (*p1 != '\0')
			//	{
			//		loge("failed to parse value: %s", cmdWords[2]);
			//		errNo = ERR_INVALID_VALUE;
			//		goto ErrLabel;
			//	}

			//	// set
			//	memcpy(pd->adr + pd->len * (unsigned)varArrayIndex, &dblVal, 8);

			//	sprintf(respDataStr, "%s %f", cmdWords[1], dblVal);
			//	break;

			case PARAMDATA_T_EEPROM_STRING:

				// check length
				i = strlen(cmdWords[2]);
				if (i + 1 > pd->len)
				{
					loge("string too long: %d, max len: %d", i, pd->len - 1);
					errNo = ERR_INVALID_LENGTH;
					goto ErrLabel;
				}

				// set
				strcpy(pd->adr, cmdWords[2]);

				// store to EEPROM
				ret = EE_Store(pd->adr, i + 1);
				if (ret != ERR_OK)
				{
					errNo = ret;
					goto ErrLabel;
				}

				sprintf(respDataStr, "%s %s", cmdWords[1], cmdWords[2]);
				break;

			default:
				loge("unsupported param type");
				errNo = ERR_INVALID_VALUE;
				goto ErrLabel;
			}
			break;
#pragma endregion

		#pragma region reset
		case 5:

			// reset micro, there will be no response

			// reset micro, this code is copy of NVIC_SystemReset() for cortex-M3
			#define __dsb() __asm volatile ("dsb 0xF":::"memory")
			__dsb();
			*((unsigned *)0xE000ED0C) = 0x5FA0304;
			__dsb();

			while (1);

			break;
		#pragma endregion

		#pragma region logee
		case 6:	// "logee:1:1;"			// 	log EEPROM content

			EE_Log(&ee);

			break;
		#pragma endregion

		#pragma region initee
		case 7:	// "initee:1:1;"			// clear eeprom completely

			EE_Init(&ee);
			EE_Store((char *)&ee + 4, 256 - 4);
			ret = EE_Read(&ee);
			if (ret != ERR_OK)
			{
				loge("failed to read from EEPROM: %", ret);
				
				errNo = ret;
				goto ErrLabel;
			}

			break;
		#pragma endregion

		#pragma region caltemp
		case 8:
			//"caltemp:2:2;"		// 8		calibrate all temp sensors to show specified value

			uval = 0;
			p1 = strchr(cmdWords[1], '.');
			if (p1 != NULL)
			{
				*p1 = '\0';
				++p1;
				uval += 10 * (unsigned)(*p1 - '0');
				++p1;
				if (*p1 != '\0')
					uval += (unsigned)(*p1 - '0');
			}
			uval += 100 * (unsigned)strtoul(cmdWords[1], &p2, 10);

			// adjust
			ee.TempAdjust[0] += (uval - (unsigned)t1);
			ee.TempAdjust[1] += (uval - (unsigned)t2);
			ee.TempAdjust[2] += (uval - (unsigned)t3);
			EE_Store(&ee.TempAdjust, sizeof(ee.TempAdjust));

			break;
		#pragma endregion

		#pragma region tx
		case 9:
		case 20:
			//"tx:3:8;"			// 9		transmit radio msg
			// e.g. "tx 1,*,temp"
			//"mm:2:8;"			// 20		transmit mesh message sequence
			// e.g. "mm 1,9,temp"

			// prepare msg in TxBuf
			p = (char *)R_TxBuf;
			for (i = 1; i < cmdWordsCount; ++i)
			{
				if (i > 1)
					*p++ = ' ';
				p += sprintf(p, "%s", cmdWords[i]);
			}

			// at this point the R_TxBuf[] looks like "1,*,temp"
			uval = strlen((char *)R_TxBuf);
			if (uval < 5 || !MM_IsValidCharValue(R_TxBuf[0], MM_SLOTS_COUNT - 1) || R_TxBuf[1] != ',' || R_TxBuf[3] != ',' || 
				!(MM_IsValidCharValue(R_TxBuf[2], MM_SLOTS_COUNT - 1) || (cmdIndex == 9 && R_TxBuf[2]=='*'))
				)
			{
				errNo = ERR_INVALID_PARAM_VALUE;
				goto ErrLabel;
			}

			if (cmdIndex == 9)
			{
				// send
				SendMsg();
			}
			else
			{
				// start MM msg sequence
				MM_ComposeAndSend(mmNextSeqNum, MM_CMD_REQUEST, MM_DEFAULT_CYCLES - 1, MM_Char2Value(R_TxBuf[0]), MM_Char2Value(R_TxBuf[2]), uval - 4, R_TxBuf + 4);

				// update seq number
				mmNextSeqNum = (mmNextSeqNum + 1) % 36;
			}

			break;
		#pragma endregion

		#pragma region m
		case 21:
			// "m:1:2;"			// 21		transmit mesh command request, e.g. "m" or "m 2"

			uval = MM_CMD_TEMP_REPORT;
			if (cmdWordsCount > 1)
				uval = MM_Char2Value(cmdWords[1][0]);

			// start MM msg sequence
			MM_ComposeAndSend(mmNextSeqNum, uval, MM_DEFAULT_CYCLES - 1, ee.StationID, ee.StationID, 0, (unsigned char*)"");

			// update seq number
			mmNextSeqNum = (mmNextSeqNum + 1) % 36;

			break;
		#pragma endregion


		#pragma region test
		case 11:
			//"test:2:2;"			// 11		test command, param value: 1:send long constant msg

			// prepare msg in TxBuf
			for (i = 0; i < 64; ++i)
				R_TxBuf[i] = '_';

			// send
			SendMsg();

			break;
		#pragma endregion

		#pragma region temp
		case 10:
			//"temp:1:1;"			// 10		get temperature reading of all channels, Vin, rssi

			sprintf(respDataStr, ",%4d,%4d,%4d,%4d,%03d", t1, t2, t3, Vin, Rssi);
			break;
		#pragma endregion

		#pragma region regs
		case 12:
			//"regs:1:1;"			// 12		read and log all regs

			A7129_LogRegs();
			break;
		#pragma endregion

		#pragma region wr
		case 13:
			//"wr:3:3;"			// 13		write value to register with specified adr (hex)

			// parse adr
			adr = strtoul(cmdWords[1], &p1, 16) & 0x0f;

			// parse value
			uval = strtoul(cmdWords[2], &p1, 16);

			// write
			A7129_WriteReg(adr, uval);
			sprintf(respDataStr, "wr %x %s = 0x%04x", adr, A7129RegNames[adr], uval);

			break;
		#pragma endregion

		#pragma region wra
		case 14:
			//"wra:3:3;"			// 14		write value to Page A register

			// parse adr
			adr = strtoul(cmdWords[1], &p1, 16) & 0x0f;

			// parse value
			uval = strtoul(cmdWords[2], &p1, 16);

			// write
			A7129_WritePageA(adr, uval);
			sprintf(respDataStr, "wra %x %s = 0x%04x", adr, A7129RegNamesPageA[adr], uval);

			break;
		#pragma endregion

		#pragma region wrb
		case 15:
			//"wrb:3:3;"			// 15		write value to PAge B register

			// parse adr
			adr = strtoul(cmdWords[1], &p1, 16) & 0x07;

			// parse value
			uval = strtoul(cmdWords[2], &p1, 16);

			// write
			A7129_WritePageB(adr, uval);
			sprintf(respDataStr, "wrb %x %s = 0x%04x", adr, A7129RegNamesPageB[adr], uval);

			break;
		#pragma endregion

		#pragma region txpwr
		case 16:
			//"txpwr:2:2;"		// 16		set tx power, 0-min, 8-max

			// parse value
			ee.TxPwr = (unsigned char) strtoul(cmdWords[1], &p1, 10);

			// set power
			A7129_SetTxPower(ee.TxPwr);

			break;
		#pragma endregion

		#pragma region left, right
		case 17:
		case 18:
			//"left:2:2;"			// 17		start motor in left direction for specified time in ms
			//"right:2:2;"		// 18		start motor in right direction for specified time in ms

			// parse value
			uval = strtoul(cmdWords[1], &p1, 10);
			if (*p1 != '\0' || uval > 60000)
			{
				loge("invalid travel time: %s", cmdWords[1]);

				errNo = ERR_INVALID_PARAM_VALUE;
				goto ErrLabel;
			}

			Mot_Start(cmdIndex == 17 ? 0 : 1, uval);

			break;
		#pragma endregion

		#pragma region stop
		case 19:
			//	"stop:1:1;"			// 19		stop motor

			Mot_Stop();

			break;
		#pragma endregion
		}

		#pragma region prepare positive response

		// cmd OK
		// prepare positive response
		if(respDataStr[0] != '\0')
			sprintf(pResp, "%s OK %s", pCmd, respDataStr);
		else
			sprintf(pResp, "%s OK", pCmd);

		//logp("  %s", pResp);
		pResp += strlen(pResp);
		#pragma endregion
	}

	// cmd OK
	goto TxStart;

ErrLabel:
	#pragma region prepare error msg

	if(respDataStr[0] != '\0')
		//sprintf(pResp, "%s ERR %d %s: %s", pCmd, errNo, ErrDescr[errNo - 1], respDataStr);
		sprintf(pResp, "%s ERR %d: %s", pCmd, errNo, respDataStr);
	else
		//sprintf(pResp, "%s ERR %d %s", pCmd, errNo, ErrDescr[errNo - 1]);
		sprintf(pResp, "%s ERR %d", pCmd, errNo);
	loge("  %s", pResp);
	pResp += strlen(pResp);
	#pragma endregion

TxStart:
	#pragma region send response
	//logp("> %s", resp);

	;
	#pragma endregion
}
#pragma endregion
