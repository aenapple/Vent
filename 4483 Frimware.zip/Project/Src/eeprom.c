#include "stm32l0xx_hal.h"
#include "debug.h"
#include "vars.h"
#include "lib.h"
#include "main.h"
#include "intr.h"
#include "string.h"

#define loge(args...) Log(LOG_SEV_ERROR, LOG_MAIN, args)
#define logw(args...) Log(LOG_SEV_WARNING, LOG_MAIN, args)
#define logp(args...) Log(LOG_SEV_PROCESS, LOG_MAIN, args)

//
// init ee structure with default, safe values
//
void EE_Init(EEPROM *p)
{
	if(sizeof(EEPROM) != 64)
		loge("size of ee must be 64 bytes, current size is: %d", sizeof(ee));

	memset(p, 0, sizeof(ee));

	EE_UpdateCRC(p);
}

//
// function updates crc in ee structure
//
void EE_UpdateCRC(EEPROM *p)
{
	p->crc = EE_CalcCRC(p);
}

unsigned EE_CalcCRC(EEPROM *p)
{
	return Adler32((unsigned char *)p + sizeof(p->crc), sizeof(EEPROM) - sizeof(p->crc));
}

//
// function write to EEPROM
// function returns ERR_xxx code
//
int EE_WriteBlock(unsigned ee_adr, char* src, unsigned len)
{
	unsigned ret;

	ret = HAL_FLASHEx_DATAEEPROM_Unlock();
	if (ret != 0)
	{
		loge("EE_WriteBlock(): unlock failed:%d", ret);
		return ERR_EEPROM_ERR;
	}

	while (len--)
	{
		ret = HAL_FLASHEx_DATAEEPROM_Program(FLASH_TYPEPROGRAMDATA_BYTE, DATA_EEPROM_BASE + ee_adr, *src);
		if (ret != 0)
		{
			loge("EE_WriteBlock(): write failed:%d, adr:%u", ret, ee_adr);
			return ERR_EEPROM_ERR;
		}

		++ee_adr;
		++src;
	}

	ret = HAL_FLASHEx_DATAEEPROM_Lock();
	if (ret != 0)
	{
		loge("EE_WriteBlock(): lock failed:%d", ret);
		return ERR_EEPROM_ERR;
	}

	return ERR_OK;
}

//
// function writes specified number of bytes from ee structure member to EEPROM chip
// pointer p must point to some member of ee structure
// function also updates EEPROM crc in chip
//
// usage: EE_Store(&ee.LoggingInterval, sizeof(ee.LoggingInterval))
//
// function returns one of ERR_xxx codes
//
int EE_Store(void *p, unsigned len)
{
	unsigned adr;
	int ret;
	char buf[49];

	// check that pointer is inside structure ee
	if ((char *)p < (char *)&ee || ((char*)p + len) > (char *)&ee + sizeof(ee))
	{
		loge("invalid pointer value, p:%x, &ee:%x", p, &ee);
		return ERR_INVALID_PARAM_VALUE;
	}

	// get adr where this member sits in EEPROM
	adr = (char *)p - (char *)&ee;

	// write to chip
	ret = EE_WriteBlock(adr, p, len);
	if (ret != ERR_OK)
		return ret;

	// update crc
	EE_UpdateCRC(&ee);
	ret = EE_WriteBlock(0, (char *)&ee.crc, sizeof(ee.crc));
	if (ret != ERR_OK)
		return ret;

	ByteArrayToHexStr(buf, p, len, sizeof(buf));
	logp("EE_Store(): adr:%d, size:%d, data:%s, crc:%x", adr, len, buf, ee.crc);
	return ERR_OK;
}

//
// function fills specified structure by reading from EEPROM chip
// function checks crc
//
// function returns one of ERR_xxx codes
//
int EE_Read(EEPROM *p)
{
	int i;
	unsigned crc;
	unsigned char* dest;
	unsigned char* src;

	// read all
	src = (unsigned char*)DATA_EEPROM_BASE;
	dest = (unsigned char*)p;
	i = sizeof(EEPROM);
	while (i--) *dest++ = *src++;

	// check crc
	crc = EE_CalcCRC(p);
	if (p->crc != crc)
	{
		loge("EE CRC mismatch, read:%x, expecting:%x", p->crc, crc);
		return ERR_CRC_MISMATCH;
	}

	return ERR_OK;
}

//
// function verifies that critical variables have reasonable values and sets them if they do not
//
void EE_CheckValues(EEPROM *p)
{
	int i;
	int errors = 0;

	// reference voltage for micro analog circuits
	//if (p->R2V5 < 2.4f) { ++errors;  p->R2V5 = 2.500f; }

	if (p->AdcFilter[0] == 0) { ++errors;  p->AdcFilter[0] = 65500; } // Vin
	if (p->AdcFilter[1] == 0) { ++errors;  p->AdcFilter[1] = 60000; } // T3
	if (p->AdcFilter[2] == 0) { ++errors;  p->AdcFilter[2] = 60000; } // MotCur
	if (p->AdcFilter[3] == 0) { ++errors;  p->AdcFilter[3] = 60000; } // T1
	if (p->AdcFilter[4] == 0) { ++errors;  p->AdcFilter[4] = 60000; } // T2
	if (p->AdcFilter[5] == 0) { ++errors;  p->AdcFilter[5] = 65500; } // Vref

	// in this version the fifo len is fixed
	if (p->FifoLen != MM_MSG_LEN) { ++errors;  p->FifoLen = MM_MSG_LEN; }
	if (p->MotStallCurrentMA == 0 || p->MotStallCurrentMA > 400) { ++errors;  p->MotStallCurrentMA = 400; }

	if (errors)
	{
		EE_Store((char *)&ee + 4, sizeof(ee) - 4);
	}
}

//
// log content of ee structure
//
void EE_Log(EEPROM *p)
{
	char buf[256];
	int i;

	unsigned crc = EE_CalcCRC(p);

	logd("crc: 0x%x, %s", p->crc, p->crc == crc ? "ok" : "MISMATCH");
	logd("PCB_SN: %s", p->PCB_SN);
	logd("Mode: %d", p->Mode);

	sprintf(buf, "TempAdjust:");
	for (i = 0; i < 3; ++i)
		sprintf(buf + strlen(buf), " %d", p->TempAdjust[i]);
	logd(buf);

	logd("AdcFilter[0] (Vin):    %d", p->AdcFilter[0]);
	logd("AdcFilter[1] (T3):     %d", p->AdcFilter[1]);
	logd("AdcFilter[2] (MotCur): %d", p->AdcFilter[2]);
	logd("AdcFilter[3] (T1):     %d", p->AdcFilter[3]);
	logd("AdcFilter[4] (T2):     %d", p->AdcFilter[4]);
	logd("AdcFilter[5] (Vref):   %d", p->AdcFilter[5]);

	logd("StationID: %d", p->StationID);
	logd("TxPwr: %d", p->TxPwr);
	logd("PollPeriod: %d", p->PollPeriod);
	logd("FifoLen: %d", p->FifoLen);
	logd("RejectMsgsWithCRCError: %d", p->RejectMsgsWithCRCError);
	logd("HwVer: %d", p->HwVer);
	logd("MotStallCurrentMA: %d", p->MotStallCurrentMA);
}
