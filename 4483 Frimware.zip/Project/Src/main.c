#pragma region includes
#include "intr.h"
#include "vars.h"
#include "debug.h"
#include "main.h"
#include "string.h"
#include "lib.h"
#include "limits.h"
#include "stdarg.h"
#include "eeprom.h"
#include "pc.h"
#include "A7129reg.h"

#pragma endregion

#pragma region logging macros
// 
#define loge(args...) Log(LOG_SEV_ERROR, LOG_MAIN, args)
#define logw(args...) Log(LOG_SEV_WARNING, LOG_MAIN, args)
#define logp(args...) Log(LOG_SEV_PROCESS, LOG_MAIN, args)
#pragma endregion

#pragma region test vars
// test and development variables
volatile int w, q, ret, d1, d2;
volatile unsigned u1;
unsigned mainLoopCounter;
int regVal;

#pragma endregion

#pragma region Main
int main(void)
{
	#pragma region Initialize
	// initialize all hardware
	Initialize();

	// setup debugger user function
	dbg_UserFunction = DbgUserFunction;

	// set initial circuit values

	ConvVerInt2Str(msg, SW_VER_NUMBER);
	logp("----- Application Starting: %s    "  __DATE__ " " __TIME__ "  -----", msg);

	// sleep to make sure that low interrupt executes at least once
	Sleep(1);

	#pragma endregion

	#pragma region read EEPROM
	if (sizeof(ee) != 64)
	{
		loge("sizeof(ee):%d", sizeof(ee));
		while (1);
	}

	// read EEPROM
	ret = EE_Read(&ee);
	if (ret != ERR_OK)
	{
		// failed to read or un-initialized eeprom

		// initialize eeprom structure with default values
		EE_Init(&ee);
		logp("sizeof(ee):%d, ee.crc:%x", sizeof(ee), ee.crc);

		// write complete structure to eeprom
		logp("trying to initialize EEPROM");
		EE_Store((char*)&ee + 4, sizeof(ee) - 4);

		// read it all back again
		ret = EE_Read(&ee);
		if (ret != ERR_OK)
		{
			loge("failed to read from EEPROM: %d", ret);
			StatusFlags.EEPROM_Error = 1;
		}
	}

	if (!StatusFlags.EEPROM_Error)
		logp("EEPROM ok, %s, StationID:%d", ee.PCB_SN, ee.StationID);

	// make sure EE values are reasonable
	EE_CheckValues(&ee);

	#pragma endregion

	#pragma region process EEPROM values

	#pragma endregion

	#pragma region init vars
	// init vars
	#pragma endregion

	#pragma region Init Radio
	ret = A7129_Init();
	if (ret == ERR_OK)
	{
		mode = ee.Mode;
		if (mode == 1)
		{
			logp("starting MASTER");

		}
		if (mode == 2)
		{
			logp("starting SLAVE");
		}

		// start Rx
		StartRx();
	}
	#pragma endregion

	Led1Blink();
	Led2Blink();
	Sleep(102);


	while (1)
	{
		++mainLoopCounter;

		if (q == 0 && Led1BlinkTimer == 0)
		{
			ConfPortAsInput(BUTTON, GPIO_NOPULL);
			if (ReadPortBit1(BUTTON) != 0)
				q = 1;
			ConfPortAsOutputPP(BUTTON, 0);
		}

		#pragma region test commands
		// test commands

		if (q)
		{
			if (q < 100)
				logp("q = %d", q);
			while (stop);

			switch (q % 100)
			{
			#pragma region 1: test
			case 1:

				for (w = 0x7f; w >= 0; --w)
				{
					if(((w >> 5) & 3) > 1)
						continue;

					A7129_WritePageB(0, 0x0b00 | w);

					sprintf((char*)R_TxBuf, "txp,%d,%02b %02b %03b", w, (w >> 5) & 3, (w >> 3) & 3, w & 7);

					for (int ww = 0; ww < 1; ++ww)
					{
						SendMsg();
						Sleep(100);
					}
					//sprintf((char*)R_TxBuf, " ");
					//SendMsg();
					//Sleep(50);

				}

				break;
			#pragma endregion

			#pragma region 2: A7129_ReadID
			case 2:

				u1 = 0;
				ret = A7129_ReadID((unsigned*)&u1);
				if (ret != ERR_OK)
					break;
				logp("read ID: 0x%x", u1);

				break;
			#pragma endregion

			#pragma region 3: A7129_Reset
			case 3:

				ret = A7129_Reset();
				if (ret != ERR_OK)
					break;
				logp("reset ok");
				break;
			#pragma endregion

			#pragma region 4: A7129_Write ID
			case 4:

				u1 = 0xDEADBABE;
				ret = A7129_WriteID(u1);
				if (ret != ERR_OK)
					break;
				logp("wrote ID: 0x%x", u1);
				break;
			#pragma endregion

			#pragma region 5: read ID million times and check if it maches
			case 5: // check SPI Rx
				d1 = 1000000;
				while (d1)
				{
					--d1;
					ret = A7129_ReadID((unsigned*)&u1);
					if (ret != ERR_OK || u1 != 0xdeadbabe)
						break;
				}
				if (d1 != 0)
					loge("ERR d1:%d, u1:%x", d1, u1);
				else
					logp("OK d1:%d, u1:%x", d1, u1);

				break;
			#pragma endregion

			#pragma region 6: write random content to fifo and transmit msg
			case 6:

				sprintf((char *)R_TxBuf, "abc %u", lowInterruptCounter);
				SendMsg();

				break;
			#pragma endregion

			#pragma region 7: read fifo
			case 7:

				ret = A7129_ReadFifo(R_RxBuf, ee.FifoLen);
				break;
			#pragma endregion

			#pragma region 8: start Rx
			case 8:

				StartRx();
				break;
			#pragma endregion

			#pragma region 20: A7129 Init
			case 20:

				A7129_Init();
				break;
			#pragma endregion

			#pragma region 21: A7129 Cal
			case 21:

				A7129_Cal();
				break;
			#pragma endregion

			#pragma region 22: send CMD_STBY
			case 22:

				ret = A7129_WriteReg1(CMD_STBY, 0, 0);

				break;
			#pragma endregion

			#pragma region 23: send CMD_RX
			case 23:

				ret = A7129_WriteReg1(CMD_RX, 0, 0);

				break;
			#pragma endregion
					
			#pragma region 24: send CMD_TX
			case 24:

				ret = A7129_WriteReg1(CMD_TX, 0, 0);

				break;
			#pragma endregion

			#pragma region 25: set TxPower to d1
			case 25:

				A7129_SetTxPower(d1);

				break;
			#pragma endregion
			}

			if (q < 100) q = 0;
		}
		#pragma endregion

		#pragma region process user commands from debugger
		if (StatusFlags.DbgRequestActive)
		{
			StatusFlags.DbgRequestActive = 0;
			logp("UCReq: %s", PC_RxBuf);

			// process msg
			PC_ProcessMsgs(PC_RxBuf, PC_TxBuf, 0);

			// log response
			logp("UCResp: %s", PC_TxBuf);
		}
		#pragma endregion

		#pragma region process PC commands
		if (PC_IsMsgReady())
		{
			// hook-up secondary log function so code that send lot of data back to service console
			dbg_SecondaryLogFunction = ServicePortSecondaryLogFunction;

			// process msg
			PC_ProcessMsgs(PC_RxBuf, PC_TxBuf, 1);

			// disconnect secondary log
			dbg_SecondaryLogFunction = NULL;

			// reset Rx and start waiting for next msg
			PC_StartRx();

			// log response
			logp("PCTX: %s", PC_TxBuf);

			// send msg
			PC_Send();
		}
		#pragma endregion

		#pragma region Modes Logic
		if (mode == 1)
		{
			// master
			if (ee.PollPeriod > 0 && PeriodicMsgTimer == 0)
			{
				sprintf((char*)R_TxBuf, "%c,*,temp", (char)MM_Value2Char(ee.StationID));
				SendMsg();
				PeriodicMsgTimer = ee.PollPeriod;
			}

			// send rx msgs to PC
			CheckIfReceivedMsg(1);
		}
		else if (mode == 2)
		{
			// slave

			// process rx msgs, send response back over radio
			CheckIfReceivedMsg(2);
		}
		#pragma endregion

		#pragma region MM logic
		if (mmSeqCompleteFlag)
		{
			mmSeqCompleteFlag = 0;
			MM_CycleComplete();
		}
		else if (mmSendRepeatFlag)
		{
			mmSendRepeatFlag = 0;
			MM_SendRepeatMsg();
		}
		#pragma endregion
	}
}


#pragma endregion

#pragma region DbgUserFunction
//
// function is called when PC debugger send some request to be executed by main code
// buf is contain zerop terminated string with command to execute
// len is number of chars in buf
//
// if function has data to be returned to debugger, it must copy it to buf (max 1024 chars). It does not have to be zero terminated
// function returns number of chars copied to buf
//
int DbgUserFunction(int len, char* buf)
{
	//logp("user cmd, len:%d, cmd:%s", len, buf);

	// store request, this will make main() code to execute this cmd later
	CopyStr(PC_RxBuf, buf, sizeof(PC_RxBuf) - 1);
	StatusFlags.DbgRequestActive = 1;

	// do not wait for command to execute as this might take long time and debugger is blocked until we return from here
	return 0;
}
#pragma endregion

#pragma region Service Port Secondary log function
//
// this function can be used to send strings back to service port
// 
void ServicePortSecondaryLogFunction(int len, char* buf)
{
	memcpy(PC_TxBuf, buf, len);
	PC_TxBuf[len] = '\0';

	PC_Send();
}

#pragma endregion

#pragma region WaitForGPIO2(), CheckIfReceivedMsg(), SendMsg(), StartRx()
//
// wait until GPIO2 goes high then low
//
// function returns ER_OK or ERR_TIMEOUT
//
int WaitForGPIO2(int waitForGpio2GoHighFirst, int timeoutMS)
{
	Gpio2Timer = timeoutMS + 1;
	
	if (waitForGpio2GoHighFirst)
	{
		while (ReadPortBit1(GPIO2) == 0 && Gpio2Timer != 0);
	}

	while (ReadPortBit1(GPIO2) != 0 && Gpio2Timer != 0);

	if (Gpio2Timer == 0)
	{
		loge("timeout, GPIO2:%d", ReadPortBit1(GPIO2));
		return ERR_TIMEOUT;
	}

	return ERR_OK;
}

//
// function checks if msg from radio is received
//
// howToProcess=0: do nothing with received msg
// howToProcess=1: send rx msg to PC
// howToProcess=2: process msg and send response back over radio
//
// function returns 0 if no msg was receveid, and 1 if msgs was recevied
//
int CheckIfReceivedMsg(int howToProcess)
{
	unsigned destStationID;
	unsigned msgIsForUs;
	char* p1;
	unsigned val;
	int ret = 0;
	int crcError = 0;

	gpio2 = ReadPortBit1(GPIO2);
	if (StatusFlags.RadioRxActive && gpio2 == 0)
	{
		// check CRC
		val = A7129_ReadReg(MODE_REG);
		if (val & (1 << 10))
		{
			++R_FecErrCount;
		}
		if (val & (1 << 9))
		{
			// crc error
			crcError = 1;
			++R_CrcErrCount;

			if(ee.RejectMsgsWithCRCError)
				goto StartRx;
		}

		// read RSSI
		Rssi = A7129_ReadReg(ADC_REG) & 0xff;

		ret = A7129_ReadFifo(R_RxBuf, ee.FifoLen);
		++R_RxCount;

		if (R_RxBuf[0] == '#')
		{
			// this is MM message
			//logp("RSSI:%03d, Rx: %s%s", Rssi, R_RxBuf, crcError ? ", CRC_ERR" : "");
			//Led2Blink();

			// skip msgs with CRC errors
			if (crcError)
				goto StartRx;
			
			MM_ProcessRxMsg();
		}
		else if (howToProcess == 1)
		{
			// just send rx msgs to PC, append RSSI

			// log
			logp("RSSI:%03d, Rx: %s%s", Rssi, R_RxBuf, crcError ? ", CRC_ERR" : "");
			Led2Blink();
	
			sprintf(PC_TxBuf, "%s,%03d%s", R_RxBuf, Rssi, crcError ? ", CRC_ERR" : "");
			PC_Send();
		}
		else if (howToProcess == 2)
		{
			// if this msg is for us then process msg and send response back over radio

			// check if this msg is for our station:
			// msg format is SourceStationID,DestStationID,Cmd
			// StationIDs is one character: 0-9 or A-Z if msg is for particular station, or '*' if this is broadcast msg
			//		e.g. "1,3,temp" or "1,C,temp"
			//		e.g. "1,*,get PCB_SN"
			if (R_RxBuf[1] != ',' || R_RxBuf[3] != ',')
				goto StartRx;
			if (R_RxBuf[2] == '*')
			{
				// broadcast
				// calculate delay based on our station ID
				TxDelayTimer = 1 + MM_SLOT_TIME_MS * ee.StationID;
			}
			else
			{
				destStationID = strtoul((char *)R_RxBuf + 2, &p1, 36);
				if (p1 != (char *)R_RxBuf + 3)
					goto StartRx;
				if (destStationID != ee.StationID)
					goto StartRx;
				TxDelayTimer = 1;
			}

			// log
			logp("RSSI:%03d, Rx: %s", Rssi, R_RxBuf);
			Led2Blink();

			// process request
			PC_ProcessMsgs((char *)R_RxBuf + 4, PC_TxBuf, 0);
			sprintf((char *)R_TxBuf, "%c,%c,%s", (char)MM_Value2Char(ee.StationID), R_RxBuf[0], PC_TxBuf);

			// wait calculated Tx delay
			while (TxDelayTimer);

			// send response
			SendMsg();
		}

		// msg received ok
		ret = 1;

StartRx:
		// re-start receiving
		StartRx();

		return ret;
	}

	return 0;
}

//
// send radio msg from R_TxBuf, wait for it to be sent, restart Rx if it was active before
//
void SendMsg()
{
	unsigned RxWasActive = StatusFlags.RadioRxActive;

	// if receive is active then stop it first
	if (RxWasActive)
	{
		ret = A7129_WriteReg1(CMD_STBY, 0, 0);
		WaitForGPIO2(0, 20);
	}

	// transmit msg
	StatusFlags.RadioRxActive = 0;
	ret = A7129_WriteFifo(R_TxBuf, ee.FifoLen);

	ret = A7129_WriteReg1(CMD_TX, 0, 0);
	++R_TxCount;
	R_LastTxTime = lowInterruptCounter;
	Led1Blink();

	// log
	if (R_TxBuf[0] == '#')
	{
		MM_PrepareLog(R_TxBuf);
		logp("mt: %s", msg);
	}
	else
		logp("tx: %s", R_TxBuf);

	// wait until tx msg is gone
	WaitForGPIO2(1, 200);

	// start rx
	if (RxWasActive)
	{
		StartRx();
	}
}

//
// function starts Rx mode
//
void StartRx()
{
	ret = A7129_WriteReg1(CMD_RX, 0, 0);
	Wait(2);
	StatusFlags.RadioRxActive = 1;
}
#pragma endregion

#pragma region MM functions
//
// function converts numeric value to character
// valid values are:
//  0 to 9 converted to '0' to '9' and
// 10 to 35 converted to 'A' to 'Z'
//
unsigned char MM_Value2Char(unsigned val)
{
	return val >= 10 ? 'A' + (val - 10) : '0' + val;
}

//
// function converts character to numeric value
// valid values are:
//  '0' to '9' converted to 0 to 9 and
// 'A' to 'Z' converted to 10 to 35
//
unsigned MM_Char2Value(unsigned char c)
{
	return c >= 'a' ? 10 + c - 'a' : c >= 'A' ? 10 + c - 'A' : c - '0';
}

//
// function puts together MM message and sends it
//
void MM_ComposeAndSend(unsigned seqNum, unsigned cmd, unsigned cycleIndex, unsigned from, unsigned to, unsigned dataLen, unsigned char* pData)
{
	// compose msg in R_TxBuf
	// sometimes the code that calls this fucntion already put the payload in R_TxBuf, so we want to move it first to create space for MM header
	if (dataLen > MM_PAYLOAD_LEN_MAX)
		dataLen = MM_PAYLOAD_LEN_MAX;
	memmove(R_TxBuf + MM_HEADER_LEN, pData, dataLen);
	while (dataLen < MM_PAYLOAD_LEN_MAX)
	{
		R_TxBuf[MM_HEADER_LEN + dataLen] = 0;
		++dataLen;
	}

	R_TxBuf[0] = '#';							// mm mark
	R_TxBuf[1] = MM_Value2Char(seqNum);			// sequence number
	R_TxBuf[2] = MM_Value2Char(cmd);			// cmd
	R_TxBuf[3] = MM_Value2Char(cycleIndex);		// cycle index
	R_TxBuf[4] = MM_Value2Char(ee.StationID);	// Station index
	R_TxBuf[5] = MM_Value2Char(from);			// from adr
	R_TxBuf[6] = MM_Value2Char(to);				// to adr

	// store msg
	memcpy(mmRxBuf, R_TxBuf, sizeof(mmRxBuf));

	// update MM timer, this will also activate MM resend logic
	MM_UpdateTimer(cycleIndex, ee.StationID, 0);

	// send msg
	SendMsg();

	// sequence is active
	mmSequenceActive = 1;
}

//
// update MM timer
//
void MM_UpdateTimer(unsigned cycleIndex, unsigned slotIndex, unsigned Offset)
{
	__disable_irq();

	mmCycleIndex = cycleIndex;
	mmSlotIndex = slotIndex;
	mmTimer = MM_SLOT_TIME_MS + 1 - Offset;

	__enable_irq();

}

//
// function is called from periodic interrupt
//
void MM_Logic()
{
	if (mmTimer == 0)
		return;
	
	--mmTimer;
	if (mmTimer == 0)
	{
		// slot timer is over
		mmTimer = MM_SLOT_TIME_MS;
		
		// move to next slot/cycle
		++mmSlotIndex;
		if (mmSlotIndex >= MM_SLOTS_COUNT)
		{
			mmSlotIndex = 0;
			
			if (mmCycleIndex == 0)
			{
				// MM sequence is complete
				mmTimer = 0;
				mmSeqCompleteFlag = 1;
				return;
			}
			else
			{
				--mmCycleIndex;
			}
		}

		// check if we need to send our repeat message
		if (mmSlotIndex == ee.StationID)
		{
			// send repeat msg
			mmSendRepeatFlag = 1;
		}
	}
}

//
// function converts from temperature counts to character
// lower then 1020 -> 1
// 1020 -> 1
// 6210 -> 255
// higher then 6210 -> 255
//
unsigned char MM_TempCounts2Char(unsigned temp)
{
	if (temp < MM_MIN_TEMP) temp = MM_MIN_TEMP;
	if (temp > MM_MAX_TEMP) temp = MM_MAX_TEMP;
	return (temp + 10 - MM_MIN_TEMP) / 20;
}

//
// function converts temperate as character to counts
//
unsigned MM_Char2TempCounts(unsigned char c)
{
	return c == 0 ? 0u : ((unsigned)c) * 20 + MM_MIN_TEMP;
}

//
// function checks is character value would convert correctly to numeric value and if it is in valid range
// e.g. is maxValidVal is 15, then valid chars are '0' to '9' and 'A' to 'F' and 'a' to 'f'
//
// function returns 0 is not valid, 1 if valid
//
int MM_IsValidCharValue(char c, unsigned maxValidVal)
{
	unsigned val;

	if (c < '0' || c > 'z' || (c > '9' && c < 'A') || (c > 'Z' && c < 'a'))
		return 0;

	val = MM_Char2Value(c);
	if (val > maxValidVal)
		return 0;

	return 1;
}

//
// function is called to send repeat msg
//
void MM_SendRepeatMsg()
{
	unsigned cmd;

	cmd = MM_Char2Value(mmRxBuf[2]);

	if (cmd <= MM_CMD_RESPONSE)
	{
		// cmd=0: Request
		// cmd=1: Response
	}
	else if (cmd == MM_CMD_TEMP_REPORT)
	{
		// temperature collection
		
		// fill our temperature
		mmRxBuf[MM_HEADER_LEN + ee.StationID * 3 + 0] = MM_TempCounts2Char(t1);
		mmRxBuf[MM_HEADER_LEN + ee.StationID * 3 + 1] = MM_TempCounts2Char(t2);
		mmRxBuf[MM_HEADER_LEN + ee.StationID * 3 + 2] = MM_TempCounts2Char(t3);
	}

	// set cycle index and slot index
	mmRxBuf[3] = MM_Value2Char(mmCycleIndex);
	mmRxBuf[4] = MM_Value2Char(mmSlotIndex);

	// copy to radio Tx buf
	memcpy(R_TxBuf, mmRxBuf, sizeof(mmRxBuf));

	// send msg
	SendMsg();
}

//
// prepare description of MM msg in msg[]
//
void MM_PrepareLog(unsigned char *p)
{
	unsigned cmd;
	int i;
	unsigned tempCounts;

	cmd = MM_Char2Value(p[2]);
	sprintf(msg, "sq:%c, cmd:%c, ci:%c, si:%c, from:%c, to:%c", p[1], p[2], p[3], p[4], p[5], p[6]);
	if (cmd <= MM_CMD_RESPONSE)
		sprintf(msg + strlen(msg), ", data: %s", p+MM_HEADER_LEN);
	else if (cmd == MM_CMD_TEMP_REPORT)
	{
		for (i = 0; i < MM_SLOTS_COUNT; ++i)
		{
			tempCounts = MM_Char2TempCounts(p[MM_HEADER_LEN + i * 3]);
			if(tempCounts == 0)
				sprintf(msg + strlen(msg), ",t%d:____", i);
			else
				sprintf(msg + strlen(msg), ",t%d:%d.%d", i, tempCounts / 100, (tempCounts / 10) % 10);
		}
	}
}

//
// function is called when MM sequence was finished
// mm msg is in mmRxBuf[]
//
void MM_CycleComplete()
{
	unsigned cmd;
	unsigned to;
	int i;
	unsigned counts;
	int j;

	mmSequenceActive = 0;

	// check if this is request for us
	cmd = MM_Char2Value(mmRxBuf[2]);
	to = MM_Char2Value(mmRxBuf[6]);
	if (to != ee.StationID)
		return;

	if (cmd == MM_CMD_REQUEST)
	{
		MM_PrepareLog(mmRxBuf);
		logp("MM received request: %s", msg);

		// process request
		PC_ProcessMsgs((char*)mmRxBuf + MM_HEADER_LEN, PC_TxBuf, 0);
		//sprintf((char*)R_TxBuf, "%c,%c,%s", (char)MM_Value2Char(ee.StationID), R_RxBuf[0], PC_TxBuf);

		logp("starting MM response sequence");
		MM_ComposeAndSend(MM_Char2Value(mmRxBuf[1]), MM_CMD_RESPONSE, MM_DEFAULT_CYCLES - 1, ee.StationID, MM_Char2Value(mmRxBuf[5]), strlen(PC_TxBuf), (unsigned char*)PC_TxBuf);
	}
	else if (cmd == MM_CMD_RESPONSE)
	{
		sprintf(PC_TxBuf, "resp from %c: %s", mmRxBuf[5], (char *)mmRxBuf + MM_HEADER_LEN);
		PC_Send();
	}
	else if (cmd == MM_CMD_TEMP_REPORT)
	{
		for (i = 0; i < MM_SLOTS_COUNT; ++i)
		{
			sprintf(PC_TxBuf, "temp from %c: ", MM_Value2Char(i));
			counts = MM_Char2TempCounts(mmRxBuf[MM_HEADER_LEN + i * 3 + 0]);
			if (counts == 0)
			{
				sprintf(PC_TxBuf + strlen(PC_TxBuf), "???");
			}
			else
			{
				sprintf(PC_TxBuf + strlen(PC_TxBuf), "%d.%d", counts / 100, (counts / 10) % 10);
				counts = MM_Char2TempCounts(mmRxBuf[MM_HEADER_LEN + i * 3 + 1]);
				sprintf(PC_TxBuf + strlen(PC_TxBuf), ", %d.%d", counts / 100, (counts / 10) % 10);
				counts = MM_Char2TempCounts(mmRxBuf[MM_HEADER_LEN + i * 3 + 2]);
				sprintf(PC_TxBuf + strlen(PC_TxBuf), ", %d.%d", counts / 100, (counts / 10) % 10);
			}
			PC_Send();
		}
	}
}

//
// process received MM msg
//
void MM_ProcessRxMsg()
{
	unsigned cmd;
	int i;
	unsigned char* pSrc;
	unsigned char* pDest;
	unsigned cycleIndex;
	unsigned stationID;

	cmd = MM_Char2Value(R_RxBuf[2]);
	if (cmd > MM_CMD_TEMP_REPORT)
		return;

	// update MM timer, this will also activate MM resend logic
	cycleIndex = MM_Char2Value(R_RxBuf[3]);
	stationID = MM_Char2Value(R_RxBuf[4]);
	MM_UpdateTimer(cycleIndex, stationID, MM_MSG_TIME_MS);

	MM_PrepareLog(R_RxBuf);
	logp("mr: %s", msg);

	if (cmd <= MM_CMD_RESPONSE)
	{
		// store everything
		memcpy(mmRxBuf, R_RxBuf, MM_MSG_LEN);
	}
	else if (cmd == MM_CMD_TEMP_REPORT)
	{
		// store header
		memcpy(mmRxBuf, R_RxBuf, MM_HEADER_LEN);

		// if this is frist msg in seauence we need to clear temperatures
		if (!mmSequenceActive)
			memset(mmRxBuf + MM_HEADER_LEN, 0, MM_PAYLOAD_LEN_MAX);

		// store all valid temperatures
		pSrc = R_RxBuf + MM_HEADER_LEN;
		pDest = mmRxBuf + MM_HEADER_LEN;
		for (i = 0; i < MM_PAYLOAD_LEN_MAX; ++i)
		{
			if (*pSrc != 0)
				*pDest = *pSrc;

			++pSrc;
			++pDest;
		}
	}

	// sequence is active
	mmSequenceActive = 1;
}
#pragma endregion