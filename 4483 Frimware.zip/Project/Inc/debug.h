#ifndef _DBG_H_
#define _DBG_H_

//
// debug code version: 1.0
//
// --- history ---
//
// --- v1.0, BB, 2020-10-11 ---
// made from STM32H7 debug v4.3
//

#define DBG_DEBUG_TO_CONSOLE 0					// if set then we expect that pic32make debugger is not connected and debug logs should be formated as text and sent out on debug uart port without request. Logs can be then shown in stadard console or teminal app like putty
#define DBG_DEBUGGER_CONNECTION_TIMEOUT_MS 600	// if debugger does not send anything for this time after reset, then we consider that it is not connected
#define DBG_MSG_LEN 256
#define DBG_MAX_DATA_LEN (DBG_MSG_LEN + 8)
#define DBG_MAX_MSG_LEN (4 + DBG_MAX_DATA_LEN)	// msg overhead and max data length
#define DBG_TX_TIMEOUT_MS 300					// how long to wait for tx to complete
#define DBG_CMD_PROCESSING_TIMEOUT_MILLISEC 200	// how long to wait for d() to process cmd before timeout
#define DBG_SYSTEM_BUSY_TIME_MS 500				// if d() is not called longer then this time we consider system busy and enable processing some debugger request in DbgProcessFastCmds() in stead of processing them in d()
#define DBG_MAX_BREAKPOINTS_COUNT 4				// maximum number of breakpoints

//*****************************************************************************
// Logging module defines
//*****************************************************************************
#define LOG_MAX_ENTRIES_COUNT 128				// max number of entries/lines that the log can hold - must be power of 2
#define LOG_ENTRY_INDEX_MASK (LOG_MAX_ENTRIES_COUNT - 1)	// mask for indexes to LogEntries
#define LOG_TEXT_BUF_LEN (1*1024)				// length of text buffer for all entries - must be Power of 2 and less or equal to 16K so that position fits in _LogEntry.pos
#define LOG_TEXT_BUF_INDEX_MASK (LOG_TEXT_BUF_LEN - 1)	// mask for indexes to LogTextBuf
#define LOG_MAX_ENTRY_TEXT_LEN 240				// max number of characters in one entry - must be less then 1024 so that it fits in  _LogEntry.len
//#define LOG_RELEASE_TRANSFERED_LOGS 0				// if true then entries that were transfered to PC are marked invalid (to release space of their text)

//*****************************************************************************
// Logging 
//*****************************************************************************
#define LOG_MODULES_COUNT 16		// this is always fixed

// module defines
#define LOG_DBG 0
#define LOG_INTR 1
#define LOG_MAIN 2
#define LOG_FLASH 3
#define LOG_PARAMS 4
#define LOG_PC 5
#define LOG_OPEN_NEW_DATA_FILE 14	// this will show in debugger but also open new data file and write there
#define LOG_ADD_TO_DATA_FILE 15		// this will show in debugger and also append to data file
#define DBG_REQ_TEST_FIXTURE 3
// loging severity
#define LOG_SEV_ALWAYS 0
#define LOG_SEV_ERROR 1
#define LOG_SEV_WARNING 2
#define LOG_SEV_PROCESS 3
#define LOG_SEV_INFO 4
#define LOG_SEV_MOST 5
#define LOG_SEV_STORE_SAMPLES_NEW_BATCH_START 6
#define LOG_SEV_STORE_SAMPLES_NEW_BATCH_CONT 7

#define logdn(args...) do{ Log(LOG_SEV_PROCESS, LOG_OPEN_NEW_DATA_FILE, args); } while(0)
#define logd(args...) do{ Log(LOG_SEV_PROCESS, LOG_ADD_TO_DATA_FILE, args); } while(0)

// debugger commands
#define DBG_CMD_PING			0x01 // ping request
#define DBG_CMD_LOADER			0x02 // request to start loader
#define DBG_CMD_RESET			0x03 // request to reset
#define DBG_GET_LAST_ADR		0x04 // get address of code that called d() last time
#define DBG_STEP				0x06 // step into
#define DBG_NEXT				0x07 // step over
#define DBG_FINISH				0x08 // step out
#define DBG_HALT				0x09 // stop running
#define DBG_CONTINUE			0x0a // start running
#define DBG_READ_MEM			0x0b // read one or more memory blocks, this can read periph, ram, code, boot or configfuses
#define DBG_WRITE_MEM			0x0c // write specified bytes to memory, can write ram and periph memory
#define DBG_WRITE_BY_MASK		0x0d // write specified bits in 4 byte words
#define DBG_TOGGLE_BIT			0x0e // toggle bit by mask
#define DBG_SET_BREAKPOINTS		0x0f // set breakpoints
#define DBG_READ_LOGS			0x10 // read logs from log buffer
#define DBG_EMULATE_KNOB		0x11 // emulate knob
#define DBG_SET_PAR				0x12 // set parameter
#define DBG_STORE_PARS			0x13 // write parameters to EEPROM
#define DBG_GET_PAR_BY_NAME		0x14 // read parameter by name
#define DBG_GET_PARS_COUNT		0x15 // get number of defined paramters
#define DBG_GET_DEVICE_NAME		0x16 // return device name
#define DBG_USER_MSG			0x17 // used to pass messages to main code
#define DBG_GET_PAR_BY_INDEX	0x18 // read parameter by index
#define DBG_RESET_PARS			0x19 // reset all aprams to defautl value
#define DBG_CLEAR_RESET_FLAG	0x1a // clear DBG_Flags.
#define DBG_CALC_BLOCKS_CRC		0x1b // calc crc32 for one or more blocks
#define DBG_ERASE_AND_WRITE_FLASH 0x1c // erase flash sector and write data to it
#define DBG_WRITE_FLASH			0x1d // write data to flash sector, must have been erased before
#define DBG_SET_MEM				0x1e // set memory in 1,2,4 or 8 byte chunks
#define DBG_USER_CMD			0x1f // command passed to main code for execution
#define DBG_TRACE_CLEAR			0x20 // initialize tracing

#define DBG_DM_CMDS_MASK		0xf0 // mask for detection of DM commands
#define DBG_DM_CMDS_VALUE		0x30 // value of dm cmds after masking
#define DBG_DM_CMD_MICROSTEP	0x31 // step into
//#define DBG_DM_CMD_STEP			0x32 // step into
//#define DBG_DM_CMD_NEXT			0x33 // step over
#define DBG_DM_CMD_FINISH		0x34 // step out - set breakpoint on current function return address and run
#define DBG_DM_CMD_HALT			0x35 // stop running
#define DBG_DM_CMD_CONTINUE		0x36 // start running
#define DBG_DM_CMD_GET_LAST_ADR	0x37 // get last adr and flags from debug monitor
#define DBG_DM_RUN_TO_BRK		0x38 // place breakpoint at spec. adr and run
#define DBG_DM_RUN_TO_BRK_AND_MICROSTEP		0x39 // place breakpoint at spec. adr, run until brk is hit, then microstep
#define DBG_DM_SET_FLAG_BREAKPOINTS_SET 0x3A
#define DBG_DM_MICROSTEP_WITHIN_RANGE 0x3B // keep microstepping until we exit the specified address range, used by 's3' command

// debugger response codes
#define DBG_RESP_OK					0x00 // success
#define DBG_RESP_UNSUPPORTED_CMD	0x01 // unrecognixed cmd
#define DBG_RESP_INVALID_ADR		0x02 // invalid address, probably detected by ldrCheckAdr()
#define DBG_RESP_INVALID_PAR_VALUE	0x03 // some of parameters were invalid, e.g. requested mem lengh to read does not fit to buf, ...
#define DBG_RESP_INVALID_PARAM_LEN	0x04 // invalid number of parameters in request
#define DBG_RESP_ADR_NOT_ALIGNED	0x05 // specified adr is not aligned correctly, e.g. pointer adr is not word aligned
#define DBG_RESP_LOG_DOES_NOT_EXIST	0x06 // requested log was not created yet (probably micro rebooted and debugger did not notice yet)
#define DBG_RESP_UNKNOWN_PAR_NAME	0x07 // setpar failed - unrecognized parameter name
#define DBG_RESP_EEPROM_ERROR		0x08 // failed to read or write to EERPOM
#define DBG_RESP_RESTART			0x09 // send to debuger on start-up to force reload
#define DBG_RESP_CMD_FAILED			0x0a // requested debuger cmd failed
#define DBG_RESP_NO_LOGS			0x0b // no valid logs found
#define DBG_RESP_FLASH_ERROR		0x0c // failed to erase or write to flash
#define DBG_RESP_USER_FUNC_NOT_DEFINED 0x0d // user function was not defined

#define LDR_CA_ANY 0
#define LDR_CA_RAM_OR_PERIPH 1

#define LDR_RESP_INVALID_ADR			0xE7	// invalid address, probably detected by ldrCheckAdr()

#define DBG_REQ_NOT_ACTIVE 0
#define DBG_REQ_DBG_UART 1

struct _DBG_Flags {
	unsigned RxMsgSource:3;		// 0: where did the last rx debug request come from, one of DBG_REQ_xxx
	unsigned PCUartRedirect:1;	// 3: true when PC UART is used as debug port
	unsigned USBRedirect:1;		// 4: true when USB is used as debug port
	unsigned TxActiveSource:3;	// 5: shows if any tx is in progress and on which source, one of DBG_REQ_xxx
	unsigned TxPtr:12;			// 8: pointer to next byte to send
	unsigned :5;				// 20:
	unsigned ResetAcknowledged:1;// 25: clear after reset, set by debuger DBG_CLEAR_RESET_FLAG cmd
	unsigned ReceivingMsg:1;	// 26: 1 when we are in the middle of receiving of msg
	unsigned :1;				// 27: DebugTxReqrequest to send debug msg to PC
	unsigned DebugRxEnabled:1;	// 28: DebugRxEnabled - request to receive debug from PC
	unsigned BreakpointsSet:1;	// 29: BreakpointsSet used to detect when micro rebooted and breakpoints need to be set again
	unsigned ProcessingCmd:1;	// 30: set when request for debugger is received and we are waiting for d() to process it, used for timeout logic that allows to recover when code enteres loop where d() is not called
	unsigned :1;				// 31:
};

extern volatile unsigned int dbg_RxTimer;
extern volatile unsigned int dbg_OverrunCounter;
extern volatile unsigned LogIndex;
extern volatile int LoggingDisabled;
extern volatile unsigned int dbg_TxTimer;
extern volatile struct _DBG_Flags DBG_Flags;

// user commands received from debugger will be passed for processing to function pointed to by dbg_UserFunction
// parameters pass in will be
//	len: string length in buf
//	buf: zero terminated string
// if function has data to be returned to debugger, it must copy it as string to buf
// function must return the length of string copied to buf
extern int(*dbg_UserFunction)(int len, char *buf);	

// if this is set then logd() will call this function with resolved string
// parameters pass in will be
//	len: string length in buf
//	buf: resolved string, might not be null terminated.
extern void(*dbg_SecondaryLogFunction)(int len, char *buf);


#ifndef ABS
#define ABS(x) ((x)<0 ? -(x):(x))
#endif
#ifndef MIN
#define MIN(a,b) ((a)<(b) ? (a):(b))
#endif
#ifndef MAX
#define MAX(a,b) ((a)>(b) ? (a):(b))
#endif

void DbgInit();
void DbgStartTx(unsigned int txLen, unsigned char respCode);
void DbgRxTx();
void DbgReset();
void DbgProcessFastCmds();
void DbgExecuteCmd();
void DbgSendLogsToConsole();

void SetLogLevel(int module, int sev);
void GetLogText(int age, char *p, int maxLen);

unsigned char ldrCheckAdr(int type, unsigned int adr, int len);

// logging
void Log(int severity, int module, char *format, ...);
extern int DbgLevel[LOG_MODULES_COUNT];	// debug level for each module
extern char LogText[];			// buffer for creating last log
extern unsigned char dbg_Buf[];
extern unsigned SS_LastLogCounter;						// decremented in low intr, when 0 then we copy any new samples to log buffer
int LogIsBufEmpty();
void LogWaitForSpace();
int LogWaitForSpaceSize(int len, int timeoutMs);

extern volatile unsigned LogWaitForSpaceWaitCounter;// how many times this function had to wait
extern volatile unsigned LogWaitForSpaceTimeouts;	// how many times this function timed out
extern volatile unsigned LogWaitForSpaceWaitTime;	// total accumulated time waited in ms

void ShowCode(unsigned int data, int count);
void EnableDebugRx();
void DisableDebugRx();
int DetectDebugerRequest(char *buf, int rxLen);

// =============================== debug monitor ===============================
// =========================================
// FPB registers
// =========================================

#define nop() __asm volatile ("nop");
//#define GET_SP(dest) __asm("movw	r3, #:lower16:" dest "\n\t"	"movt	r3, #:upper16:" dest "\n\t"	"str	sp, [r3, #0]\n" : : : "cc","r3")	// get current value of sp to global int variable GET_SP("my_sp")

#define halt() brk_dm()
#define brk() brk_dm()
void brk_dm();

void DisableDebugMonitor();
void EnableDebugMonitor();
void TriggerDebugMonitor();
void DebugMon_Handler(void);
int UserBreakpointOnAdr(unsigned int adr);

void show(unsigned groupPin, unsigned value, unsigned onChange);
void show16(unsigned groupPin, unsigned value, unsigned onChange);

#endif //#define _DBG_H_
