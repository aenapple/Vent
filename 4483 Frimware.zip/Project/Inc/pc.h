//***************************************************************************** 
// File:	pc.h
// Descr:	Contains constants, external funct. and protoypes for communication with recipe builder PC
// Rev:	
// Created:	
// Author:	
//*****************************************************************************

#ifndef _PC_H
#define _PC_H

#pragma region command defines, response codes

void PC_ProcessMsgs(char *cmd, char *resp, int log);

#endif	//_PC_H
