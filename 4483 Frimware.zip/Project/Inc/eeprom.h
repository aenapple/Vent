#ifndef EEPROM_H
#define EEPROM_H

// structure for values read from EEPROM
typedef struct
{
	unsigned crc;							// 0: adler32 crc calcuated starting from adr 0x02 till the eeprom end
	char PCB_SN[7];							// 4: PCB serial number, e.g. KAB123
	unsigned char Mode;						// 11: Operation Mode, 1:master, 2:slave
	short TempAdjust[3];					// 12: calibration adjust, 100 counts = 1 degC. This will be added to calculated value
	unsigned short AdcFilter[6];			// 18: adc filter constants, 0:not initialized, 1:no filter, 0xffff:max filter, [0]:Vin, [1]:T3, [2]:MotCurrent, [3]:T1, [4]:T2, [5]:Vref
	unsigned char StationID;				// 30: 0: not set, 1: master, 2-35: slaves
	unsigned char TxPwr;					// 31: 0: min, 8: max
	unsigned short PollPeriod;				// 32: 0: periodic poll disabled, other value:master periodic poll period in ms
	unsigned char FifoLen;					// 34: length of radio Tx and Rx FIFO
	unsigned char RejectMsgsWithCRCError;	// 35: 0: accept rx msgs with CRC error, 1: reject rx msgs with CRC error
	unsigned char HwVer;					// 36: 0:44831001-A7139, 1:44831001-A7129
	unsigned char fill_1;					// 37:
	unsigned short MotStallCurrentMA;		// 38: Motor stall current in mA, must be no more then then 400
	unsigned char fill_2[24];				// 40: fill
											// 64:

} EEPROM;	// size of structure must be 64 bytes 
			// when changes are made, update EE_CheckValues() and EE_Log() functions and ParamData[] in pc.c

void EE_Init(EEPROM *p);
unsigned EE_CalcCRC(EEPROM *p);
void EE_UpdateCRC(EEPROM *p);
int EE_Store(void *p, unsigned len);
int EE_Read(EEPROM *p);
void EE_Log(EEPROM *p);
void EE_CheckValues(EEPROM *p);
int EE_WriteBlock(unsigned ee_adr, char* src, unsigned len);


#endif	//EEPROM_H
