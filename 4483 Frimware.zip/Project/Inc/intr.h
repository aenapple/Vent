#ifndef INTR_H
#define INTR_H

#include "stm32l0xx_hal.h"

// ports
#define PORT_A 0
#define PORT_B 1
#define PORT_C 2
#define PORT_D 3
#define PORT_E 4
#define PORT_F 5
#define PORT_G 6
#define PORT_H 7


#define PORTBIT(port, bit) ((port)<<4 | (bit))		// combine port and pin into one port-pin value
#define PORTBIT_GET_PORT(portbit) ((portbit)>>4)	// extract port value from port-pin value
#define PORTBIT_GET_BIT(portbit) ((portbit) & 0x0f)	// exttract pin value from port-pin value

#define GPIOA_BSSR_ADR (GPIOA_BASE + 0x18)
#define SetPortBit1(portbit,value) *((volatile int *)(GPIOA_BSSR_ADR + ((portbit) >> 4) * 0x400)) = 1 << ( ((portbit) & 0xf) + ((value)==0)*16)
int ReadPortBit1(int portbit);
void ConfPortAsInput(int portbit, int pullups);
void ConfPortAsOutputPP(int portbit, int outputState);

#pragma region functions

void Initialize(void);
void Wait(int microsec);
void Wait1MicroSec();
void Wait200NanoSec();

#pragma region HAL function definitions

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_LPTIM1_Init(void);
static void MX_LPUART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM21_Init(void);
static void MX_TIM22_Init(void);
void _Error_Handler(char* file, int line);
static void MX_DMA_Init(void);
static void MX_ADC_Init(void);
static void MX_SPI1_Init(void);

#pragma endregion

void ConvVerInt2Str(char *dest, int ver);
void PC_Send();
void PC_StartRx();
int PC_IsMsgReady();

void Led1Blink();
void Led2Blink();

int A7129_WriteReg1(unsigned reg, unsigned value, int len);
int A7129_ReadReg1(unsigned reg, unsigned* pValue, int len);
int A7129_Reset();
int A7129_WriteID(unsigned id);
int A7129_ReadID(unsigned* pid);
void A7129_WriteReg(unsigned address, unsigned dataWord);
unsigned A7129_ReadReg(unsigned address);
void A7129_WritePageA(unsigned address, unsigned dataWord);
unsigned A7129_ReadPageA(unsigned address);
void A7129_WritePageB(unsigned address, unsigned dataWord);
unsigned A7129_ReadPageB(unsigned address);
int A7129_Config(void);
int A7129_Cal(void);
int A7129_WriteData(unsigned cmd, unsigned char* p, int dataLen);
int A7129_WriteFifo(unsigned char* p, int dataLen);
int A7129_ReadFifo(unsigned char* p, int dataLen);
int A7129_ReadData(unsigned cmd, unsigned char* pData, int dataLen);
int A7129_Init();
void A7129_LogRegs();
extern const uint16_t A7129Config[];
extern const uint16_t A7129Config_PageA[];
extern const uint16_t A7129Config_PageB[];
const unsigned char A7129_TxPowerSettings[9];
const unsigned char A7139_TxPowerSettings[9];
extern const char* A7129RegNames[];
extern const char* A7129RegNamesPageA[];
extern const char* A7129RegNamesPageB[];
unsigned SPI_ReadByte(void);
void A7129_SetTxPower(unsigned txPowerIndex);
int A7129_Init1();

void Mot_Start(int direction, int travelTimeMs);
void Mot_Stop();
void Mot_Logic();

#pragma endregion
#endif //INTR_H
