#ifndef VARS_H
#define VARS_H

#include "intr.h"
#include "eeprom.h"

#ifndef PIC32MAKE_COMPILE
// defines so visual studio understands basic types
typedef signed char        int8_t;
typedef short              int16_t;
typedef int                int32_t;
typedef long long          int64_t;
typedef unsigned char      uint8_t;
typedef unsigned short     uint16_t;
typedef unsigned int       uint32_t;
typedef unsigned long long uint64_t;
#endif

// status codes

// process defines
// DBG1, DBG2 are disconnected
#define DBG1	PORTBIT(PORT_A, 8)	// also TIM2CH1
#define DBG2	PORTBIT(PORT_B, 3)	// also TIM2CH2
#define GPIO1	PORTBIT(PORT_A, 10)
#define GPIO2	PORTBIT(PORT_A, 11)

#define STAT_LED	PORTBIT(PORT_B, 9) // this is also LED1 and BUTTON
#define BUTTON		PORTBIT(PORT_B, 9) // this is also LED1
#define LED2		PORTBIT(PORT_B, 8)

#define TIM2CH1		PORTBIT(PORT_A, 8)
#define TIM2CH2		PORTBIT(PORT_B, 3)
#define MOT_EN		PORTBIT(PORT_B, 5)

#define VINMEASCTRL PORTBIT(PORT_H, 1)	// connects Vin measurement to ADC when low
#define CTRL PORTBIT(PORT_B, 6)			// power switch for Vs
#define SCS PORTBIT(PORT_B, 12)			// chip select for radio
#define SDIO PORTBIT(PORT_B, 15)		// SPI MOSI
#define SCK PORTBIT(PORT_B, 13)			// SPI CLK

#pragma region interrupt and debug monitor vars
// debug monitor variables
extern volatile unsigned int dm_lr;		// old value of lr when monitor was triggered
extern volatile unsigned int dm_pc;		// old value of pc when monitor was triggered
extern volatile unsigned int dm_old_sp;	// calculated value of sp before monitor was triggered (what was it in original function that was interrupted)
extern volatile unsigned int dm_counter;	// incremented each time debug monitor is executed
extern volatile unsigned int dm_BrkAdr;	// adr of breakpoint used by step commands
extern volatile unsigned int dm_UartRequest;		// set by UART interrupt to request actions from dm
extern volatile unsigned int dm_UartCmd;			// requested cmd
extern volatile unsigned int dm_MainCodeRequest;	// if set my main code then 1ms periodic interrupt with trigger debug monitor
extern volatile unsigned int dm_MainCodeCmd;		// set by main code to request actions from dm
extern volatile unsigned int dm_State;				// dm state machine state
extern volatile unsigned int dm_PendingCmd;			// this cmd will be executed after microstep is done
extern volatile unsigned int dm_SendResponseAfterMicrostep;	// if set then dm will send UART response msg to debugger after misrocstep is finished
extern volatile unsigned int dm_ExecuteMicrosteps;	// if non zero then we need to do specified number of microsteps
extern volatile unsigned int dm_pc1;		// old value of pc when monitor was triggered - this is set by low interrupt code, used when Pic32make is not enabled
extern volatile unsigned int dm_FPB_BreakpointsCount;		// how many breakpoints are supported by this core
extern volatile unsigned int dm_FPB_UserBreakpointsCount;	// how many breakpoints can be used by user
extern volatile unsigned int dm_RangeStart;		// start of range adr
extern volatile unsigned int dm_RangeEnd;		// end of range adr
extern volatile unsigned int dm_RangeSpThreshold;	// max value of stack pointer to stop microstepping
extern volatile unsigned int dm_FuncStartAdr;	// first address in current function, used as additional params for special cases for microstepping code
extern volatile unsigned int dm_FuncStartEnd;	// first address outside current function, used as additional params for special cases for microstepping code
#pragma endregion

#pragma region main vars

// main vars
#define MSG_BUF_LEN 256
extern char msg[MSG_BUF_LEN];		// temp buffer that can be used to compose log messages, etc.
extern volatile int stop;			// used for testing
extern volatile unsigned ErrorHandlerCount;
extern volatile unsigned ErrorHandlerAdr;		// old value of pc when ErrorHandler() was called
extern volatile int ErrorHandlerLine;
extern char SerialNumber[7];		// serial number stored in EEPROM
extern int HwVer;					// board HW version, e.g. BOARD_VER_6001
extern volatile unsigned x1, x2, x3, x4;
extern volatile unsigned char Led1BlinkTimer; // decremented in low interrupt
extern volatile unsigned char Led2BlinkTimer; // decremented in low interrupt
extern volatile unsigned char gpio1;			// pin state
extern volatile unsigned char gpio2;			// pin state
extern volatile unsigned char mode;			// main of operation
extern volatile unsigned char Gpio2Timer;		// decremented in low interrupt
extern volatile unsigned char Rssi;			// last RSSI reading, weakest signal: around 70, strongest signal: around 180
extern volatile unsigned short TxDelayTimer;	// decremented in low interrupt
extern volatile unsigned short PeriodicMsgTimer;// decremented in low interrupt
extern volatile unsigned short Timer1;			// decremented in low interrupt
extern unsigned char LSE_InitFailed;			// set if LSE initialization fails

// interrupt vars
extern volatile unsigned int lowInterruptSP;	// stack pointer when in low interrupt code
extern volatile unsigned long long lowInterruptCounter;
extern volatile unsigned Tim2HighCnt;			// incremented when TIM2 overflows each 65536 us

EEPROM ee;

// status flags
struct _StatusFlags {
	unsigned EEPROM_Error : 1;				// 0.0: set when EEPROM read or write fails
	unsigned DbgRequestActive : 1;			// 0.1: set when debugger sends some request for main code
	unsigned RadioRxActive : 1;				// 0.2: set after we issued Rx CMD to Radio
};
extern volatile struct _StatusFlags StatusFlags;	// system status flags

#pragma endregion

#pragma region HAL driver vars
extern LPTIM_HandleTypeDef hlptim1;

extern UART_HandleTypeDef hlpuart1;
extern DMA_HandleTypeDef hdma_lpuart1_rx;
extern DMA_HandleTypeDef hdma_lpuart1_tx;

extern UART_HandleTypeDef huart2;
extern DMA_HandleTypeDef hdma_usart2_rx;
extern DMA_HandleTypeDef hdma_usart2_tx;

extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim21;
extern TIM_HandleTypeDef htim22;

extern DMA_HandleTypeDef hdma_adc;
extern ADC_HandleTypeDef hadc;

//extern SPI_HandleTypeDef hspi1;

#pragma endregion

#pragma region PC UART vars

#define PC_RX_BUF_LEN 128
#define PC_TX_BUF_LEN 128
#define PC_RX_TIMEOUT_MS 5000 // !!! change to 100 in production		// all msg bytes must come in less the this time
#define MAX_CMDS_COUNT 3
#define MAX_WORDS_COUNT 8

// ! when new ERR_xxx code is created, add entry also to *ErrDescr[]
#define ERR_OK 0
#define ERR_UNRECOGNIZED_CMD 1
#define ERR_INVALID_NUMBER_OF_PARAMS 2
#define ERR_UNKNOWN_ERROR 3
#define ERR_INVALID_VALUE 4
#define ERR_COMMAND_FAILED 5
#define ERR_INTERNAL_HW_ERROR 6				// typically, SPI comm failure with ADC
//#define ERR_TAKE_READING_FAILED 7
#define ERR_INVALID_PARAM_VALUE 8
#define ERR_I2C_WRITE_FAILED 9
#define ERR_I2C_READ_FAILED 10
#define ERR_SET_DAC_FAILED 11
#define ERR_SET_EEPROM_TEST_MISMATCH 12
#define ERR_ACC_NEW_DATA_NOT_READY_YET 13	// accelerometer new data noe ready yet, try again later
#define ERR_CRC_MISMATCH 14					// invalid crc
#define ERR_UNRECOGNIZED_PARAM_NAME 15
#define ERR_INVALID_LENGTH 16
#define ERR_SET_DATE_TIME_FAILED 17
#define ERR_SPI_ERR 18
#define ERR_MANUF_ID_MISMATCH 19
#define ERR_TIMEOUT 20
#define ERR_EEPROM_ERR 21
#define ERR_INVALID_ARRAY_INDEX 22
#define ERR_CALL_FAILED_FBCF 23
#define ERR_CALL_FAILED_VCCF 24
#define ERR_CALL_FAILED_VBCF 25

// !! when new value is added, update ErrDescr[] in service.c


extern char PC_LastCmd[PC_RX_BUF_LEN];			// last comnad will be stored here
extern char PC_RxBuf[PC_RX_BUF_LEN];			// buffer for receiving data from PC filled by DMA
extern char PC_TxBuf[PC_TX_BUF_LEN];			// buffer used for sending messages to PC
extern volatile char PC_TxActive;				// high when tx DMA is in progress
extern volatile int PC_TxTimer;					// used to detect tx timeouts
extern volatile int PC_TxTimeoutsCounter;		// how many times did tx timeout happened
extern volatile int PC_RxTimer;					// used to detect rx timeouts
extern volatile int PC_RxTimeoutsTimer;			// how many times rx timeout happened
extern volatile char PC_RxActive;				// high when we are in the middle of receiving msg from PC
extern volatile int PC_DmaRxLen;				// number of bytes received so far
extern char respDataStr[PC_TX_BUF_LEN];			// response will be composed in this buffer
extern char *cmds[MAX_CMDS_COUNT];				// array of pointers, each points to the begining of command
extern char *cmdWords[MAX_WORDS_COUNT];			// array of pointers, eahc points to the beginning of next word in command, first points to command name
extern int cmdWordsCount;						// number of words in cmdWords[]

#pragma endregion

#pragma region ADC vars
extern volatile unsigned short Adc1DmaBuf[6];		// DMA will store ADC counts in this buffer
extern volatile unsigned short Adc1DmaInterruptCounter;	// incremented in DMA interrupt
extern volatile unsigned short Adc1FilteredCounts[6];	// filter ADC counts scaled to 16 bits, 0xffff = ADCfull range
extern volatile unsigned char Adc1FilterCounter;	// incremented in DMA interrupt, used to initialize filter
extern unsigned short VrefIntCal;					// calibration value from STM manufacturing test read from system memory
extern unsigned short Vdda;							// Vdda voltage in mv calcuated from measuring internal Vref and using STM calibration value from system memory
extern unsigned short t1;							// T1 temperature, 1 count = 0.01 degC
extern unsigned short t2;							// T2 temperature, 1 count = 0.01 degC
extern unsigned short t3;							// T3 temperature, 1 count = 0.01 degC
extern unsigned short Vin;							// Vin voltage in milivolts
extern unsigned short MotCurrentMA;					// Motor current in mA
extern unsigned short MaxMotCurrentMA;				// maximum detected value of Motor current in mA
#pragma endregion

#pragma region Radio
#define R_DEFAULT_ID 0xa34e2b09
extern unsigned char R_TxBuf[64 + 1];					// transmit buffer
extern unsigned char R_RxBuf[64 + 1];					// Rx buffer
extern volatile unsigned R_LastTxTime;				// last time we transmitted
extern volatile unsigned R_TxCount;					// number of msgs transmitted
extern volatile unsigned R_RxCount;					// number of msgs received
extern volatile unsigned R_CrcErrCount;				// number of msgs received with CRC mismatch
extern volatile unsigned R_FecErrCount;			// number of msgs with bit correction
extern volatile unsigned char R_CurrentTxPower;	// currently selected Tx power (0-8)
extern volatile unsigned char R_tbg_tdc_pac;		// current TX2 reg fields TBG+TDC+PAC
#pragma endregion

#pragma region Motor
#define MOT_OVERCURRENT_LIMIT_MA 400
#define MOT_OVERCURRENT_OFF_TIME_MS 20
#define MOT_STALL_TIME_TO_TURN_OFF_MS 100
extern volatile unsigned short MotTimer;					// decremented every ms, motor will be turned off when timer reaches 0
extern volatile unsigned short MotOvercurrOffTimer;		// times off period when we reached overcurent
extern volatile unsigned char MotOvercurrEventCounter;		// incremented when we detected overcurrent
extern volatile unsigned short MotStallTime;				// incremented when motor current is higher then ee.MotStallCurrentMA
extern volatile unsigned short MotOvercurrentTime;			// incremented when motor current is higher then MOT_OVERCURRENT_LIMIT_MA
#pragma endregion

#pragma region Mesh Messages
#define MM_HEADER_LEN 7								// length of MM msg header: '#',SeqNum,Cmd,CycleInd,SlotInd,FromAdr,ToAdr
#define MM_PAYLOAD_LEN_MAX 51						// max length of payload
#define MM_MSG_LEN 58								// radio rx/tx fifo length will be set to this
#define MM_SLOT_TIME_MS 100							// duration of time slot for 1 msg
#define MM_DEFAULT_CYCLES 4							// how many cycles in mesh sequence (this is also max number of hops)
#define MM_SLOTS_COUNT 16							// how many time slots are in sequence, this is also Max StationId + 1
#define MM_MSG_TIME_MS 91							// bits=8*8+(len+2)*14=904 bits. At 10Kbps msg time = 90.4ms

#define MM_CMD_REQUEST 0							// cmd request for particular station
#define MM_CMD_RESPONSE 1							// response to MM_CMD_REQUEST
#define MM_CMD_TEMP_REPORT 2						// cmd to get temperature reading of all stations

#define MM_MIN_TEMP 1020							// minimum temperature we can trasnfer in counts
#define MM_MAX_TEMP 6120							// maximum temperature we can trasnfer in counts

extern volatile unsigned char mmNextSeqNum;			// 0 to 35
extern unsigned char mmRxBuf[MM_MSG_LEN];			// received messages are assembled here
extern volatile unsigned char mmCycleIndex;			// cycle index of last received or sent MM msg
extern volatile unsigned char mmSlotIndex;			// slot index of last received or sent MM msg
extern volatile unsigned char mmTimer;				// timer used to measure one slot time
extern volatile unsigned char mmSeqCompleteFlag;	// set by ingterrupt code when sequence is complete
extern volatile unsigned char mmSendRepeatFlag;		// set by ingterrupt code when main code should send repeat msg
extern volatile unsigned char mmSequenceActive;		// set when sequence is in progress
#pragma endregion

#endif // VARS_H
