#ifndef _MAIN_H
#define _MAIN_H

#include "intr.h"

#define SW_VER_NUMBER 0x022A			// 0x123A = v1.23A

// Board versions
#define BOARD_VER_INVALID			0	// failed to decode version
#define BOARD_VER_6001				1	// 6001
#define BOARD_VER_6002				2	// 6002

// vars
extern int fatalError;					// fatal error code value or 0 if OK

// functions
int DbgUserFunction(int len, char* buf);
void ServicePortSecondaryLogFunction(int len, char* buf);
int WaitForGPIO2(int waitForGpio2GoHighFirst, int timeoutMS);
void SendMsg();
int CheckIfReceivedMsg(int howToProcess);
void StartRx();
unsigned char MM_Value2Char(unsigned val);
unsigned MM_Char2Value(unsigned char c);
void MM_ComposeAndSend(unsigned seqNum, unsigned cmd, unsigned cycleIndex, unsigned from, unsigned to, unsigned dataLen, unsigned char* pData);
void MM_UpdateTimer(unsigned cycleIndex, unsigned slotIndex, unsigned Offset);
void MM_Logic();
void MM_SendRepeatMsg();
void MM_PrepareLog(unsigned char* p);
void MM_CycleComplete();
unsigned char MM_TempCounts2Char(unsigned temp);
unsigned MM_Char2TempCounts(unsigned char c);
int MM_IsValidCharValue(char c, unsigned maxValidVal);
void MM_ProcessRxMsg();



#endif	//_MAIN_H
