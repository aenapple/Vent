#ifndef LIB_H
#define LIB_H

#include "stddef.h"

#define SERIAL_NUMBER_ADR 0x1FF1E800 // stm32h743: 0x1FF1E800

// macros
//typedef void *	va_list[1];
//#define	va_start(ap, parmn)	*ap = (char *)&parmn + sizeof parmn
//#define	va_arg(ap, type)	(*(*(type **)ap)++)
//#define NULL 0
//typedef char FILE;
//#include <stdarg.h>

#define EOL "\n"	// end-of-line string

// typed for Int2StrLookup
typedef struct Int2StrLookupItem {int value; const char *name;} Int2StrLookupItem;

// defines
#define I2IL_SEARCH_KEYS_RETURN_VALUES 0
#define I2IL_SEARCH_VALUES_RETURN_KEYS 1

// these were taken from yagarto gcc stdarg.h file
typedef __builtin_va_list __gnuc_va_list;
typedef __gnuc_va_list va_list;
#define va_start(v,l) __builtin_va_start(v,l)
#define va_end(v) __builtin_va_end(v)
#define va_arg(v,l) __builtin_va_arg(v,l)

// stdio function declarations
int sprintf(char *buf, const char * f, ...);
int snprintf2(char *buf, int size, const char * f, ...);
int vsnprintf2(char *buf, int size, const char * f, va_list ap);

// standard string functions
int isspace(int c);
int islower(int c);
int isupper(int c);
int isalpha(int c);
int isdigit(int c);
void stoupper(char *s);
void stolower(char *s);
void reverse(char *str);
int strcmp(const char *s1, const char *s2);
char *strncpy(char *dest, const char *source, size_t n);
int strncmp(const char *s1, const char *s2, size_t n);
int stricmp(const char *s1, const char *s2);
int strnicmp(const char *s1, const char *s2, size_t n);
long strtol(const char *nptr, char **endptr, int base);
long long strtoll(const char *nptr, char **endptr, int base);
unsigned long strtoul(const char *nptr,	char **endptr, int base);
unsigned long long strtoull(const char *nptr, char **endptr, int base);
double strtod1(char *string, char **endPtr);
float strtof1(char *string, char **endPtr);
int HexCharToValue(char c);
int HexStringToByteArray(char *dest, char *hexStr);
void StrReplace(char *s, char c_old, char c_new);

// other string functions
void trim(char *str);
char *SkipSpace(char *p);
char *GetLine(char *dest, int maxLenToCopy, char *text);
char *GetWord(char *dest, char *text);
int AppendStr(char *dest, char *src, int DestBufLen);
int AppendStrN(char *dest, char *src, int DestBufLen, int maxSrcCharsToAppend);
int CopyStr(char *dest, char *src, int maxSrcCharsToAppend);
int ByteArrayToHexStr(char *dest, char *src, int srcLen, int maxDestLen);
int ByteArrayToHexStrNoSpace(char *dest, char *src, int srcLen, int maxDestLen);

// system functions
void Sleep(int milisec);
unsigned int Rand();
void RandSetSeed(unsigned int seed);
unsigned int Adler32(unsigned char *p, int len);

int lltoa(char *s, long long n, int base);
int ulltoa(char *s, unsigned long long n, int base);
int ltoa(char *s, long n, int base);
int ultoa(char *s, unsigned long n, int base);
int ftoa(char *outbuf, float f, int precision);
float SqrtF(float number);
typedef double calcMedianType;
calcMedianType CalcMedian(calcMedianType arr[], int n);
int split2words(char *text, char separator, int maxWords, char **words);
void trimWords(char **words, int count);
//int strcspn(char *s1, char *s2);
int LookupStrInt(char *table, char *key, int *results, int *keyIndex);
int CheckValueLL(long long n, int numberOfBytes);
int CheckValueULL(unsigned long long, int numberOfBytes);
float CalcAvgF(float *p, int count);
char * Int2StrLookup(Int2StrLookupItem *p, int value);
int Int2IntLookup(int *dictionary, int dictNumberOfLines, int searchMode, int pattern, int notFoundValue, int *result);
float Sin2(float x);
unsigned SuperFastHash(const char * data, int len);
void ReadChipId(char *dest);
unsigned CalcLicenseCode(unsigned project, unsigned licenseType);

#endif //LIB_H
